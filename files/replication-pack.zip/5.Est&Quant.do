/*Estimation for Quantification
This do file provides estimations for preference parameters in a framework that is consistent with the model presented in the paper. It takes Herrendorf, Rogerson and Valentinyi (2013AER, HRV from here on) as starting point. That work estimates beta in a model with three sectors and non-homothetic preferences.

In this do file we show how results change when the structure in the model is modified. The do file is structured as follows:
0-Constructs an expenditure database at the world level following Uy et al (2013JME)
1-Replicates results from HRV using their data and codes
2-Modifies 1- by dropping the service sector
	2.1-Using same US data from HRV
	2.2-Using international expenditure panel from 0-
3-Modifies 1- by adopting a nested structure where the upper tier is a CES choice between services and goods, and the lower tier is another CES choice between agricultural and manufactured goods.
	3.1-Using same US data from HRV
	3.2-Using international expenditure panel from 0-
4-Replicates results from 3 using value added data for the US and Western Europe. For the US, we use data from HRV. For Western Europe we use Data from WIOD.
*/

version 8

*0-Constructs an expenditure database at the world level following Uy et al (2013JME)

import delim "$pc_in\OECD\OECD_expenditures.csv", clear
keep if (measure == "C" | measure == "VOB")
*VOB: constant prices, OECD base year (=2010) | C: current prices
keep if (transact == "P314B" | transact== "P313B" | transact == "P312B" | transact=="P311B" | transact== "P31CP010" | transact == "P31CP020")
*keep only classification codes mentioned in Uy et al. 2013 Appendix
save "$path_out\oecd_data_reduced.dta", replace

*for population data
clear
import delim "$pc_in\OECD\oecd_dp_download _02_06_2019.csv"
rename value Value
keep if (subject=="TOT" & measure=="MLN_PER" ) //we want values for total population
drop indicator subject measure frequency flagcodes
save "$path_out\pop_data.dta", replace

*for PPP data
clear
import delim "$pc_in\OECD\oecd_ppp_download_02_06_2019.csv"
keep if transact=="PPPPRC" //we want values for private consumption PPP (PPPPRC)
rename value PPPprc
keep location time PPPprc
save "$path_out\PPPprc_data.dta", replace

use "$path_out\oecd_data_reduced.dta", clear
levelsof transact, local(cats)

foreach y of local cats{
use "$path_out\oecd_data_reduced.dta", clear
keep  if transact=="`y'"
rename (value transact) (value_`y' transact_`y')
keep location transact_`y' measure year value_`y'
save "$path_out\\`y'.dta" , replace
}

use "$path_out\oecd_data_reduced.dta", clear
drop if transact != "P314B"

foreach y of local cats{
merge 1:1 location measure year using "$path_out\`y'.dta"
keep if _merge ==3
drop _merge
}
drop transact*

*expenditure variables
gen FoodExp = value_P31CP010+value_P31CP020
gen ManuExp = value_P311B+value_P312B+value_P313B-FoodExp
gen ServExp = value_P314B
gen FoodShare = FoodExp/(FoodExp+ManuExp+ServExp)
gen ManuShare = ManuExp/(FoodExp+ManuExp+ServExp)
gen ServShare = ServExp/(FoodExp+ManuExp+ServExp)

label variable ManuShare "Manufacturing Exp. Share"
label variable FoodShare "Food Exp. Share"
label variable ServShare "Service Exp. Share"

merge m:1 location time using "$path_out\pop_data.dta"

rename Value population
label variable population "Population in mio."
keep if _merge == 3
drop _merge
merge m:1 location time using "$path_out\PPPprc_data.dta"
keep if _merge == 3
drop _merge

drop if location=="LVA" //dropping Latvia due to different currency units

**generate nominal total expenditure
gen CE = (FoodExp+ManuExp+ServExp)/(population*PPPprc) if (measure=="C")
gen CE2= (FoodExp+ManuExp)/(population*PPPprc) if (measure=="C")

label variable CE "Aggr. Cons. Exp. per capita in current U.S. dollars"
label variable CE2 "Aggr. Good Exp. per capita in current U.S. dollars"

gen temp1 = PPPprc if (time==2010)
bys country: egen PPP_2010 = max(temp1)

gen food_price_nom = FoodExp/PPPprc if (measure=="C")
gen manu_price_nom = ManuExp/PPPprc if (measure=="C")
gen serv_price_nom = ServExp/PPPprc if (measure=="C")

gen food_price_denom = FoodExp/PPP_2010 if (measure!="C")
gen manu_price_denom = ManuExp/PPP_2010 if (measure!="C")
gen serv_price_denom = ServExp/PPP_2010 if (measure!="C")

*sectoral prices

save "$path_out\temp1.dta", replace
keep if food_price_nom ==.
save "$path_out\temp2.dta", replace
use "$path_out\temp1.dta", clear

keep if food_price_nom !=.
drop food_price_denom manu_price_denom serv_price_denom
merge 1:1 location time using "$path_out\temp2.dta"
keep if _merge==3
drop _merge

gen PriceA=food_price_nom/food_price_denom
gen PriceM=manu_price_nom/manu_price_denom
gen PriceS=serv_price_nom/serv_price_denom
label variable PriceA "Price Food Sector"
label variable PriceS "Price Service Sector"
label variable PriceM "Price Manufacturing Sector"
gen PriceA_rel =PriceA/PriceM
gen PriceS_rel =PriceS/PriceM
gen PriceM_rel =PriceM/PriceM
label variable PriceA_rel "PriceA/PriceM"
label variable PriceS_rel "PriceA/PriceM"
label variable PriceM_rel "PriceM/PriceM"
label variable ManuExp "Manufacturing Expenditures (current prices, domestic currency)"
label variable ServExp "Service Expenditures (current prices, domestic currency)"
label variable FoodExp "Food Expenditures (current prices, domestic currency))"

drop referenceperiodcode temp1 flag* PPP_2010 measure food_price* manu_price* serv_price* value powercode* value_* unit unitcode referenceperiod
rename country country_name
rename location country
save "$path_out\Expenditure_Panel_final.dta", replace

erase "$path_out\oecd_data_reduced.dta"
erase "$path_out\pop_data.dta"
erase "$path_out\PPPprc_data.dta"
erase "$path_out\temp1.dta"
erase "$path_out\temp2.dta"
erase "$path_out\P311B.dta"
erase "$path_out\P312B.dta"
erase "$path_out\P313B.dta"
erase "$path_out\P314B.dta"
erase "$path_out\P31CP010.dta"
erase "$path_out\P31CP020.dta"

*1-Replicates results from HRV using their data and codes

insheet time Agriculture Manufacturing Services PriceA PriceM PriceS PriceSnG using "$pc_in\Herrendorf et al (2013)\STPreferences_data\STPreferences_data\ConsumptionExpenditure.csv", comma double case clear
g CE=Agriculture+Manufacturing+Services
g CE2=Agriculture+Manufacturing
g AgricultureShare=Agriculture/CE
g ManufacturingShare=Manufacturing/CE
g ServicesShare=Services/CE
g rAgriculture=Agriculture/PriceA
g rManufacturing=Manufacturing/PriceM
g rServices=Services/PriceS
g rServicesG=Services/PriceSnG
g rAgricultureIndex=rAgriculture/rAgriculture[1]
g rManufacturingIndex=rManufacturing/rManufacturing[1]
g rServicesIndex=rServices/rServices[1]
g PriceAIndex=PriceA/PriceA[1]
g PriceMIndex=PriceM/PriceM[1]
g PriceSIndex=PriceS/PriceS[1]
g PriceAM=PriceA/PriceM
g PriceSM=PriceS/PriceM
g CEM=CE/PriceM
g CEM2 = CE2/PriceM
/***
*** Correcting the prices for quality bias 
***
gen PriceAIndexQyy=PriceA[_n]/PriceA[_n-1]/(1+0.0031452)
gen PriceMIndexQyy=PriceM[_n]/PriceM[_n-1]/(1+0.0050654)
gen PriceSIndexQyy=PriceS[_n]/PriceS[_n-1]/(1+0.0060582)
gen PriceAIndexQ=1 if _n==1
gen PriceMIndexQ=1 if _n==1
gen PriceSIndexQ=1 if _n==1
replace PriceAIndexQ=PriceAIndexQyy[_n]*PriceAIndexQ[_n-1] if _n>1
replace PriceMIndexQ=PriceMIndexQyy[_n]*PriceMIndexQ[_n-1] if _n>1
replace PriceSIndexQ=PriceSIndexQyy[_n]*PriceSIndexQ[_n-1] if _n>1
gen PriceAQ=PriceAIndexQ/PriceAIndexQ[59]
gen PriceMQ=PriceMIndexQ/PriceMIndexQ[59]
gen PriceSQ=PriceSIndexQ/PriceSIndexQ[59]*/

save "$path_out\hrv_expenditure_data.dta", replace

g Exp = CE
g ManuShare = ManufacturingShare
g AgriShare = AgricultureShare
g ServShare = ServicesShare

nlsur (ManuShare=(exp({t2})/(1+exp({t2})+exp({t3}))*PriceM^(1-exp({betaex}))*(Exp+PriceA*{bc_a}+PriceS*{bc_s}))/(1/(1+exp({t2})+exp({t3}))*PriceA^(1-exp({betaex}))+exp({t2})/(1+exp({t2})+exp({t3}))*PriceM^(1-exp({betaex}))+exp({t3})/(1+exp({t2})+exp({t3}))*PriceS^(1-exp({betaex})))/Exp  )  ///
      (ServShare=(exp({t3})/(1+exp({t2})+exp({t3}))*PriceS^(1-exp({betaex}))*(Exp+PriceA*{bc_a}+PriceS*{bc_s}))/(1/(1+exp({t2})+exp({t3}))*PriceA^(1-exp({betaex}))+exp({t2})/(1+exp({t2})+exp({t3}))*PriceM^(1-exp({betaex}))+exp({t3})/(1+exp({t2})+exp({t3}))*PriceS^(1-exp({betaex})))/Exp-PriceS*{bc_s}/Exp ) , ///
      ifgnls nolog vce(robust) noconstant initial( betaex -0.5 t2 0.4 t3 1.4 bc_a -100 bc_s 100) 
estat ic
matrix S=r(S)
scalar AIC=S[1,5]
predict ManuShare_hat1, equation(#1) yhat
predict ServShare_hat1, equation(#2) yhat
g AgriShare_hat1=1-ManuShare_hat1-ServShare_hat1
egen ManuRMSE1 = mean((ManuShare-ManuShare_hat1)^2)
egen AgriRMSE1 = mean((AgriShare-AgriShare_hat1)^2)
egen ServRMSE1 = mean((ServShare-ServShare_hat1)^2)
replace ManuRMSE1 = ManuRMSE1^0.5
replace AgriRMSE1 = AgriRMSE1^0.5
replace ServRMSE1 = ServRMSE1^0.5
g sumRMSE1 = ManuRMSE1+AgriRMSE1+ServRMSE1

nlcom (beta: exp(_b[/betaex])) (bc_a: _b[/bc_a]) (bc_s: _b[/bc_s]) (omega_a: 1/(1+exp(_b[/t2])+exp(_b[/t3]))) (omega_m: exp(_b[/t2])/(1+exp(_b[/t2])+exp(_b[/t3]))) ///
      (omega_s: exp(_b[/t3])/(1+exp(_b[/t2])+exp(_b[/t3]))), post
estimates store model_1
estadd scalar rmse_a=AgriRMSE1[1]:model_1
estadd scalar rmse_m=ManuRMSE1[1]:model_1
estadd scalar rmse_s=ServRMSE1[1]:model_1
estadd scalar rmse_sum=sumRMSE1[1]:model_1
estadd scalar AIC:model_1

*2-Modifies 1- by dropping the service sector
	*2.1-Using same US data from HRV
g ManuShare2 =ManufacturingShare/(AgricultureShare+ManufacturingShare)
g AgriShare2 =AgricultureShare/(AgricultureShare+ManufacturingShare)

replace Exp = CE2
replace ManuShare = ManuShare2

nlsur (ManuShare2 = (((exp({t2}))/(1+exp({t2})))*PriceM^(1-exp({betaex})))/((((exp({t2}))/(1+exp({t2})))*PriceM^(1-exp({betaex}))) + (((1)/(1+exp({t2})))*PriceA^(1-exp({betaex}))) )*(1+PriceA*{bc_a}/Exp)), vce(robust) noconstant initial( betaex 0.5 t2 0.4  bc_a -100 ) 
estat ic
matrix S=r(S)
scalar AIC=S[1,5]
predict ManuShare_hat2, yhat
g AgriShare_hat2=1-ManuShare_hat2
egen ManuRMSE2 = mean((ManuShare2-ManuShare_hat2)^2)
egen AgriRMSE2 = mean((AgriShare2-AgriShare_hat2)^2)
replace ManuRMSE2 = ManuRMSE2^0.5
replace AgriRMSE2 = AgriRMSE2^0.5
g sumRMSE2 = ManuRMSE2+AgriRMSE2

nlcom (beta: exp(_b[/betaex])) (bc_a: _b[/bc_a]) (omega_a: 1/(1+exp(_b[/t2]))) (omega_m: exp(_b[/t2])/(1+exp(_b[/t2]))), post
estimates store model_2
estadd scalar rmse_a=AgriRMSE2[1]:model_2
estadd scalar rmse_m=ManuRMSE2[1]:model_2
estadd scalar rmse_sum=sumRMSE2[1]:model_2
estadd scalar AIC:model_2


	*2.2-Using international expenditure panel
use "$path_out\Expenditure_Panel_final.dta", clear
	*full sample 3 sectors

nlsur (ManuShare=(exp({t2})/(1+exp({t2})+exp({t3}))*PriceM^(1-exp({betaex}))*(CE+PriceA*{bc_a}+PriceS*{bc_s}))/(1/(1+exp({t2})+exp({t3}))*PriceA^(1-exp({betaex}))+exp({t2})/(1+exp({t2})+exp({t3}))*PriceM^(1-exp({betaex}))+exp({t3})/(1+exp({t2})+exp({t3}))*PriceS^(1-exp({betaex})))/CE  )  ///
      (ServShare=(exp({t3})/(1+exp({t2})+exp({t3}))*PriceS^(1-exp({betaex}))*(CE+PriceA*{bc_a}+PriceS*{bc_s}))/(1/(1+exp({t2})+exp({t3}))*PriceA^(1-exp({betaex}))+exp({t2})/(1+exp({t2})+exp({t3}))*PriceM^(1-exp({betaex}))+exp({t3})/(1+exp({t2})+exp({t3}))*PriceS^(1-exp({betaex})))/CE-PriceS*{bc_s}/CE ) , ///
      ifgnls nolog vce(robust) noconstant initial( betaex -0.5 t2 0.4 t3 1.4 bc_a -100 bc_s 100) 
estat ic

nlcom (beta: exp(_b[/betaex])) (bc_a: _b[/bc_a]) (bc_s: _b[/bc_s]) (omega_a: 1/(1+exp(_b[/t2])+exp(_b[/t3]))) (omega_m: exp(_b[/t2])/(1+exp(_b[/t2])+exp(_b[/t3]))) ///
      (omega_s: exp(_b[/t3])/(1+exp(_b[/t2])+exp(_b[/t3]))), post
estimates store model_3

	*full sample 2 sectors

gen ManuShare2 =ManuShare/(FoodShare+ManuShare)
gen FoodShare2 =FoodShare/(FoodShare+ManuShare)

nlsur (ManuShare2 = (((exp({t2}))/(1+exp({t2})))*PriceM^(1-exp({betaex})))/((((exp({t2}))/(1+exp({t2})))*PriceM^(1-exp({betaex}))) + (((1)/(1+exp({t2})))*PriceA^(1-exp({betaex}))) )*(1+PriceA*{bc_a}/CE2)), vce(robust) noconstant initial( betaex 0.5 t2 0.4  bc_a -100 ) 
estat ic

nlcom (beta: exp(_b[/betaex])) (bc_a: _b[/bc_a]) (omega_a: 1/(1+exp(_b[/t2]))) (omega_m: exp(_b[/t2])/(1+exp(_b[/t2]))), post
estimates store model_4

	*Western Europe 3 sectors

u "$path_out\Expenditure_Panel_final.dta", clear
qui do "$pc\\do\A-regions.do"
keep if (region==4)

nlsur (ManuShare=(exp({t2})/(1+exp({t2})+exp({t3}))*PriceM^(1-exp({betaex}))*(CE+PriceA*{bc_a}+PriceS*{bc_s}))/(1/(1+exp({t2})+exp({t3}))*PriceA^(1-exp({betaex}))+exp({t2})/(1+exp({t2})+exp({t3}))*PriceM^(1-exp({betaex}))+exp({t3})/(1+exp({t2})+exp({t3}))*PriceS^(1-exp({betaex})))/CE  )  ///
      (ServShare=(exp({t3})/(1+exp({t2})+exp({t3}))*PriceS^(1-exp({betaex}))*(CE+PriceA*{bc_a}+PriceS*{bc_s}))/(1/(1+exp({t2})+exp({t3}))*PriceA^(1-exp({betaex}))+exp({t2})/(1+exp({t2})+exp({t3}))*PriceM^(1-exp({betaex}))+exp({t3})/(1+exp({t2})+exp({t3}))*PriceS^(1-exp({betaex})))/CE-PriceS*{bc_s}/CE ) , ///
      ifgnls nolog vce(robust) noconstant initial( betaex -0.5 t2 0.4 t3 1.4 bc_a -100 bc_s 100) 
estat ic
matrix S=r(S)
scalar AIC=S[1,5]
predict ManuShare_hat1, equation(#1) yhat
predict ServShare_hat1, equation(#2) yhat
g AgriShare_hat1=1-ManuShare_hat1-ServShare_hat1
egen ManuRMSE1 = mean((ManuShare-ManuShare_hat1)^2)
egen AgriRMSE1 = mean((FoodShare-AgriShare_hat1)^2)
egen ServRMSE1 = mean((ServShare-ServShare_hat1)^2)
replace ManuRMSE1 = ManuRMSE1^0.5
replace AgriRMSE1 = AgriRMSE1^0.5
replace ServRMSE1 = ServRMSE1^0.5
g sumRMSE1 = ManuRMSE1+AgriRMSE1+ServRMSE1

nlcom (beta: exp(_b[/betaex])) (bc_a: _b[/bc_a]) (bc_s: _b[/bc_s]) (omega_a: 1/(1+exp(_b[/t2])+exp(_b[/t3]))) (omega_m: exp(_b[/t2])/(1+exp(_b[/t2])+exp(_b[/t3]))) ///
      (omega_s: exp(_b[/t3])/(1+exp(_b[/t2])+exp(_b[/t3]))), post
estimates store model_5
estadd scalar rmse_a=AgriRMSE1[1]:model_5
estadd scalar rmse_m=ManuRMSE1[1]:model_5
estadd scalar rmse_s=ServRMSE1[1]:model_5
estadd scalar rmse_sum=sumRMSE1[1]:model_5
estadd scalar AIC:model_5

	*Western Europe 2 sectors

g ManuShare2 =ManuShare/(FoodShare+ManuShare)
g AgriShare2 =FoodShare/(FoodShare+ManuShare)

nlsur (ManuShare2 = (((exp({t2}))/(1+exp({t2})))*PriceM^(1-exp({betaex})))/((((exp({t2}))/(1+exp({t2})))*PriceM^(1-exp({betaex}))) + (((1)/(1+exp({t2})))*PriceA^(1-exp({betaex}))) )*(1+PriceA*{bc_a}/CE2)), vce(robust) noconstant initial( betaex 0.5 t2 0.4  bc_a -100 ) 
estat ic
matrix S=r(S)
scalar AIC=S[1,5]
predict ManuShare_hat2, yhat
g AgriShare_hat2=1-ManuShare_hat2
egen ManuRMSE2 = mean((ManuShare2-ManuShare_hat2)^2)
egen AgriRMSE2 = mean((AgriShare2-AgriShare_hat2)^2)
replace ManuRMSE2 = ManuRMSE2^0.5
replace AgriRMSE2 = AgriRMSE2^0.5
g sumRMSE2 = ManuRMSE2+AgriRMSE2

nlcom (beta: exp(_b[/betaex])) (bc_a: _b[/bc_a]) (omega_a: 1/(1+exp(_b[/t2]))) (omega_m: exp(_b[/t2])/(1+exp(_b[/t2]))), post
estimates store model_6
estadd scalar rmse_a=AgriRMSE2[1]:model_6
estadd scalar rmse_m=ManuRMSE2[1]:model_6
estadd scalar rmse_sum=sumRMSE2[1]:model_6
estadd scalar AIC:model_6

*3-Modifies 1- by adopting a nested structure

*define various locals to put together expenditure share expressions:
local _omega_g = "(1/(1+exp({t2})))"
local _omega_s = "(exp({t2})/(1+exp({t2})))"
local _omega_a = "(1/(1+exp({t3})))"
local _omega_m = "(exp({t3})/(1+exp({t3})))"
local _Lambda = "(`_omega_a'/`_omega_m')*((PriceM)/(PriceA))^(exp({beta}))"
local _Tau = "(`_omega_s'/`_omega_g')*((PriceM)/(PriceS*`_omega_m'^(1/exp({beta}))))^(exp({epsilon}))"
local _Theta = "((`_omega_a'^(1/exp({beta})))*`_Lambda'^((exp({beta})-1)/exp({beta}))+(`_omega_m'^(1/exp({beta}))))^((exp({epsilon})-exp({beta}))/(1-exp({beta})))"
local _c_m = "(CE+PriceS*({bc_s})+PriceA*({bc_a}))/(PriceM+PriceS*`_Theta'*`_Tau'+PriceA*`_Lambda')"


	*3.1-Using same US data from HRV
u "$path_out\hrv_expenditure_data.dta", clear
nlsur (ManufacturingShare= (PriceM/CE)*`_c_m' )  ///
      (     ServicesShare= (PriceS/CE)*((`_c_m')*`_Tau'*`_Theta'-{bc_s}) ) , ///
      ifgnls nolog vce(robust) noconstant initial( beta 0.5 epsilon -0.3 t2 1.4 t3 1.8 bc_a -1000 bc_s 8000) 
estat ic
matrix S=r(S)
scalar AIC=S[1,5]
predict ManuShare_hat1, equation(#1) yhat
predict ServShare_hat1, equation(#2) yhat
g AgriShare_hat1=1-ManuShare_hat1-ServShare_hat1
egen ManuRMSE1 = mean((ManuShare-ManuShare_hat1)^2)
egen AgriRMSE1 = mean((AgricultureShare-AgriShare_hat1)^2)
egen ServRMSE1 = mean((ServShare-ServShare_hat1)^2)
replace ManuRMSE1 = ManuRMSE1^0.5
replace AgriRMSE1 = AgriRMSE1^0.5
replace ServRMSE1 = ServRMSE1^0.5
g sumRMSE1 = ManuRMSE1+AgriRMSE1+ServRMSE1 

nlcom (beta: exp(_b[/beta])) (epsilon: exp(_b[/epsilon]))  (bc_a: _b[/bc_a]) (bc_s: _b[/bc_s]) (omega_a: 1/(1+exp(_b[/t3]))) (omega_g: 1/(1+exp(_b[/t2]))) (omega_m: exp(_b[/t3])/(1+exp(_b[/t3]))) ///
      (omega_s: exp(_b[/t2])/(1+exp(_b[/t2]))), post
estimates store model_7
estadd scalar rmse_a=AgriRMSE1[1]:model_7
estadd scalar rmse_m=ManuRMSE1[1]:model_7
estadd scalar rmse_s=ServRMSE1[1]:model_7
estadd scalar rmse_sum=sumRMSE1[1]:model_7
estadd scalar AIC:model_7

test beta=epsilon

	*3.2-Using international expenditure panel

u "$path_out\Expenditure_Panel_final.dta", clear
qui do "$pc\do\A-regions.do"


	*full sample- only nls estimation due to convergence issue

nlsur (ManuShare= (PriceM/CE)*`_c_m' )  ///
      (     ServShare= (PriceS/CE)*((`_c_m')*`_Tau'*`_Theta'-{bc_s}) ) , ///
      nls nolog vce(robust) noconstant initial( beta 0.5 epsilon -0.5 t2 0.4 t3 1.4 bc_a -100 bc_s 100) 
estat ic

nlcom (beta: exp(_b[/beta])) (epsilon: exp(_b[/epsilon]))  (bc_a: _b[/bc_a]) (bc_s: _b[/bc_s]) (omega_a: 1/(1+exp(_b[/t3]))) (omega_g: 1/(1+exp(_b[/t2]))) (omega_m: exp(_b[/t3])/(1+exp(_b[/t3]))) ///
      (omega_s: exp(_b[/t2])/(1+exp(_b[/t2]))), post
estimates store model_8

test beta=epsilon
	  
	*Western Europe
keep if region == 4 //4 is indicator for Western Europe

nlsur (ManuShare= (PriceM/CE)*`_c_m' )  ///
      (     ServShare= (PriceS/CE)*((`_c_m')*`_Tau'*`_Theta'-{bc_s}) ) , ///
      nls nolog vce(robust) noconstant initial( beta 0.5 epsilon -0.5 t2 0.4 t3 1.4 bc_a -100 bc_s 100) 
estat ic
matrix S=r(S)
scalar AIC=S[1,5]
predict ManuShare_hat1, equation(#1) yhat
predict ServShare_hat1, equation(#2) yhat
g AgriShare_hat1=1-ManuShare_hat1-ServShare_hat1
egen ManuRMSE1 = mean((ManuShare-ManuShare_hat1)^2)
egen AgriRMSE1 = mean((FoodShare-AgriShare_hat1)^2)
egen ServRMSE1 = mean((ServShare-ServShare_hat1)^2)
replace ManuRMSE1 = ManuRMSE1^0.5
replace AgriRMSE1 = AgriRMSE1^0.5
replace ServRMSE1 = ServRMSE1^0.5
g sumRMSE1 = ManuRMSE1+AgriRMSE1+ServRMSE1

nlcom (beta: exp(_b[/beta])) (epsilon: exp(_b[/epsilon]))  (bc_a: _b[/bc_a]) (bc_s: _b[/bc_s]) (omega_a: 1/(1+exp(_b[/t3]))) (omega_g: 1/(1+exp(_b[/t2]))) (omega_m: exp(_b[/t3])/(1+exp(_b[/t3]))) ///
      (omega_s: exp(_b[/t2])/(1+exp(_b[/t2]))), post
estimates store model_9
estadd scalar rmse_a=AgriRMSE1[1]:model_9
estadd scalar rmse_m=ManuRMSE1[1]:model_9
estadd scalar rmse_s=ServRMSE1[1]:model_9
estadd scalar rmse_sum=sumRMSE1[1]:model_9
estadd scalar AIC:model_9

test beta=epsilon

*export a table of results (Table 5 in the text.)
esttab model_1 model_2 model_5 model_6 model_7 model_9 using "$pc\Table_estpref.tex", b(3) se(3) ///
scalar(AIC rmse_a rmse_m rmse_s rmse_sum) ///
noconstant nodepvars nomtitles nogaps nolines coeflabels( epsilon "$\epsilon$" beta "$\beta$" bc_a "$\bar{Q}_A$" bc_s "$\bar{Q}_S$" ///
omega_a "$\omega_A$" omega_m "$\omega_M$" omega_s "$\omega_S$" omega_g "$\omega_G$") order(beta bc* omega* epsilon) replace



*********************************************************************************
*4-Replicates results from 3 using value added data for the US and Western Europe
*********************************************************************************

/*Prepare datasets

***
*US
***
From HRV: ConsumptionValueAdded.csv


*****
*WIOD
*****
u pwt91
keep countrycode year pop
rename countrycode country
save pwt_pop_data, replace

*import wiod expenditure data
import delimited va_data_wiod.csv, clear 
rename ind_country country
rename ind_year year
merge m:1 country year using pwt_pop_data
keep if _merge==3
drop _merge
g CE = tot_exp/pop //get total expenditure per capita
g CE2 = tot_exp_goods/pop //get total expenditure per capita on goods

*get some labels
label var year "Year"
label var country "Country identifier"
label var CE "Consumption expenditure per capita"
label var CE2 "Consumption exp. per capita on goods"
label var tot_exp "Total consumption expenditure in USD"
label var tot_exp_goods "Total consumption expenditure on goods in USD"

save wiod_exp_pc, replace //save intermediate file

*generate dataset with country price indices from WDI
use wiod_exp_pc, clear
merge m:1 country year using wdi_prices_temp
keep if _merge==3
drop _merge
save VA_wiod_wdi_temp, replace

*get data on relative prices

import excel ggdc_prodleveldata.xlsx, sheet("Stata_Import") firstrow clear
drop Country
rename ISOcode country
gen year=2005
merge 1:m country year using VA_wiod_wdi_temp
drop if _merge==1

*generate correct services price index

*rebase price index to 2005

gen temp = PriceS if year==2005
bys country: egen priceS2005 = max(temp)
replace PriceS = PriceS/priceS2005
drop priceS2005 temp
drop if PriceS==. //delete observations from Malta, for which no 2005 value is available
bys country: egen priceS2005 = max(Services)
replace PriceS = PriceS*priceS2005

*generate correct goods price index

*rebase price index to 2005

gen temp = PriceG if year==2005
bys country: egen priceG2005 = max(temp)
replace PriceG = PriceG/priceG2005
drop priceG2005 temp
bys country: egen priceG2005 = max(Goodsproducing)
replace PriceG = PriceG*priceG2005

*generate approximate manufacturing price index

*rebase price index to 2005

gen temp = PriceM if year==2005
bys country: egen priceM2005 = max(temp)
replace PriceM = PriceM/priceM2005
drop priceM2005 temp
bys country: egen priceM2005 = max(Goodsproducing)
replace PriceM = PriceM*priceM2005

*rebase price index to 2005

gen temp = PriceA if year==2005
bys country: egen priceA2005 = max(temp)
replace PriceA = PriceA/priceA2005
drop priceA2005 temp
bys country: egen priceA2005 = max(Goodsproducing)
replace PriceA = PriceA*priceA2005
drop _merge price* GDP Marketeconomy Goodsproducing Manufacturing Othergoods Services Marketservices Nonmarketservices
save VA_wiod_wdi2, replace
*/

*US
u "$path_out\hrv_va_data.dta", clear
local _omega_g = "(1/(1+exp({t2})))"
local _omega_s = "(exp({t2})/(1+exp({t2})))"
local _omega_a = "(1/(1+exp({t3})))"
local _omega_m = "(exp({t3})/(1+exp({t3})))"
local _PriceG = "((`_omega_a'*PriceA^(1-exp({beta}))+`_omega_m'*PriceM^(1-exp({beta})))^(1/(1-exp({beta}))))"
local _sm = "(((`_omega_m'*PriceM^(1-exp({beta})))/((`_omega_a'*PriceA^(1-exp({beta})))+(`_omega_m'*PriceM^(1-exp({beta})))))*((`_omega_g'*`_PriceG'^(1-exp({epsilon})))/(`_omega_g'*`_PriceG'^(1-exp({epsilon}))+`_omega_s'*PriceS^(1-exp({epsilon}))))*(1+(PriceA*{bc_a}+PriceS*{bc_s})/CE))"

nlsur (ManufacturingShare= `_sm')(ServicesShare= (((`_omega_s'*PriceS^(1-exp({epsilon})))/(`_omega_g'*`_PriceG'^(1-exp({epsilon}))+`_omega_s'*PriceS^(1-exp({epsilon}))))*(1+(PriceA*{bc_a}+PriceS*{bc_s})/CE)-PriceS*{bc_s}/CE) ), ifgnls nolog vce(robust) noconstant initial( beta 0.3 epsilon -0.7 t2 1.4 t3 1.8 bc_a -100 bc_s 1000) 
estat ic
matrix S=r(S)
g AIC=S[1,5]
predict ManuShare_hat1, equation(#1) yhat
predict ServShare_hat1, equation(#2) yhat
g  AgriShare_hat1=1-ManuShare_hat1-ServShare_hat1
egen ManuRMSE = mean((ManufacturingShare-ManuShare_hat1)^2)
egen AgriRMSE = mean((AgricultureShare-AgriShare_hat1)^2)
egen ServRMSE = mean((ServicesShare-ServShare_hat1)^2)

replace ManuRMSE = ManuRMSE^0.5
replace AgriRMSE = AgriRMSE^0.5
replace ServRMSE = ServRMSE^0.5
g sumRMSE = ManuRMSE+AgriRMSE+ServRMSE

nlcom (beta: exp(_b[/beta])) (epsilon: exp(_b[/epsilon]))  (bc_a: _b[/bc_a]) (bc_s: _b[/bc_s]) (omega_a: 1/(1+exp(_b[/t3]))) (omega_g: 1/(1+exp(_b[/t2]))) (omega_m: exp(_b[/t3])/(1+exp(_b[/t3])))(omega_s: exp(_b[/t2])/(1+exp(_b[/t2]))), post
estimates store model_USA
estadd scalar rmse_a=AgriRMSE[1]:model_USA
estadd scalar rmse_m=ManuRMSE[1]:model_USA
estadd scalar rmse_s=ServRMSE[1]:model_USA
estadd scalar rmse_sum=sumRMSE[1]:model_USA
estadd scalar AIC=AIC[1]:model_USA

*Western Europe
u "$path_out\VA_wiod_wdi2" , clear
qui do "$pc\MEGA\PhD\4_Div&Div\do\A-regions.do"
keep if (region==4)
/*
rename country location
merge m:1 location  using region_indicator
keep if _merge==3
drop _merge

g region1	= (region==4)   //indicator for region Western Europe
g region2	= (region==5)   //indicator for region Eastern Europe
g region3	= (region==8 | region==9) //indicator for region Asia
g region_id = region1+2*region2+3*region3
egen country_id = group(location)

global number_regions = 3

keep if region1>0 //keep only these regions
*/
local _omega_g = "(1/(1+exp({t2})))"
local _omega_s = "(exp({t2})/(1+exp({t2})))"
local _omega_a = "(1/(1+exp({t3})))"
local _omega_m = "(exp({t3})/(1+exp({t3})))"
local _PriceG = "((`_omega_a'*PriceA^(1-exp({beta}))+`_omega_m'*PriceM^(1-exp({beta})))^(1/(1-exp({beta}))))"
local _sm = "(((`_omega_m'*PriceM^(1-exp({beta})))/((`_omega_a'*PriceA^(1-exp({beta})))+(`_omega_m'*PriceM^(1-exp({beta})))))*((`_omega_g'*`_PriceG'^(1-exp({epsilon})))/(`_omega_g'*`_PriceG'^(1-exp({epsilon}))+`_omega_s'*PriceS^(1-exp({epsilon}))))*(1+(PriceA*{bc_a}+PriceS*{bc_s})/CE))"

nlsur (manushare= `_sm')(servshare= (((`_omega_s'*PriceS^(1-exp({epsilon})))/(`_omega_g'*`_PriceG'^(1-exp({epsilon}))+`_omega_s'*PriceS^(1-exp({epsilon}))))*(1+(PriceA*{bc_a}+PriceS*{bc_s})/CE)-PriceS*{bc_s}/CE) ), ifgnls nolog vce(robust) noconstant initial( beta -0.5 epsilon -0.3 t2 1.4 t3 1.8 bc_a -100 bc_s 100) 
estat ic
matrix S=r(S)
g AIC=S[1,5]
predict ManuShare_hat1, equation(#1) yhat
predict ServShare_hat1, equation(#2) yhat
g  AgriShare_hat1=1-ManuShare_hat1-ServShare_hat1
egen ManuRMSE = mean((manushare-ManuShare_hat1)^2)
egen AgriRMSE = mean((agrishare-AgriShare_hat1)^2)
egen ServRMSE = mean((servshare-ServShare_hat1)^2)

replace ManuRMSE = ManuRMSE^0.5
replace AgriRMSE = AgriRMSE^0.5
replace ServRMSE = ServRMSE^0.5
g sumRMSE = ManuRMSE+AgriRMSE+ServRMSE

nlcom (beta: exp(_b[/beta])) (epsilon: exp(_b[/epsilon]))  (bc_a: _b[/bc_a]) (bc_s: _b[/bc_s]) (omega_a: 1/(1+exp(_b[/t3]))) (omega_g: 1/(1+exp(_b[/t2]))) (omega_m: exp(_b[/t3])/(1+exp(_b[/t3])))(omega_s: exp(_b[/t2])/(1+exp(_b[/t2]))), post
estimates store model_WE
estadd scalar rmse_a=AgriRMSE[1]:model_WE
estadd scalar rmse_m=ManuRMSE[1]:model_WE
estadd scalar rmse_s=ServRMSE[1]:model_WE
estadd scalar rmse_sum=sumRMSE[1]:model_WE
estadd scalar AIC=AIC[1]:model_WE

*export a table of results (Table A.18 in the text.)
esttab model_USA model_WE using "$pc\Table_estprefVA.tex", b(3) se(3) ///
scalar(AIC rmse_a rmse_m rmse_s rmse_sum) ///
noconstant nodepvars nomtitles nogaps nolines coeflabels(epsilon "$\epsilon$" beta "$\beta$" bc_a "$\bar{Q}_A$" bc_s "$\bar{Q}_S$" ///
omega_a "$\omega_A$" omega_m "$\omega_M$" omega_s "$\omega_S$" omega_g "$\omega_G$") order(beta bc* omega* epsilon) replace

