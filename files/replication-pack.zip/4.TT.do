/*****************************
*4.EVOLUTION OF TERMS OF TRADE
******************************

This do-file:
1-Creates a dataset with terms of trade.
	-Runs regressions to evaluate the effect that being A intensive has on the TT trend. We find that:
		-the coef of the time trend is positive meaning that terms of trade improve for most countries
		-the interaction is significant and negative meaning that the trend is lower for A countries
2-Computes extended evolution including the period 1960-1985 using data from Barro and Lee (1993)
3-Contrasts results with Acemoglu and Ventura (2002)
	3.1-Replicates results in AV02 and then I
		3.1.1-point at A-countries in their graph (mostly below the fitted line)
		3.1.2-test whether size is an important determinant of the TTE: it isn't!
	3.2-Extends AV02's methodology using 1 obs per country: Barro and Lee's data until 85 and PWT and WDI since.
*/
version 8
clear

*1-Creates a dataset with terms of trade extracted from WDI: TT.dta
u "$pc\data\WDI\WDI2015\termsoftrade14.dta", clear
forvalues y=1960(1)2015{
rename _`y'__yr`y'_ nbtti`y'
}
rename country_code country
keep if series_name=="Net barter terms of trade index (2000 = 100)"
drop country_name series_name series_code
reshape long nbtti, i(country) j(year)
label var nbtti "Net barter terms of trade index (2000 = 100)"
/*Net barter terms of trade index is calculated as the percentage ratio of the export unit value indexes to the import unit value indexes, 
measured relative to the base year 2000. Unit value indexes are based on data reported by countries that demonstrate consistency under 
UNCTAD quality controls, supplemented by UNCTAD's estimates using the previous year's trade values at the Standard International Trade 
Classification three-digit level as weights. To improve data coverage, especially for the latest periods, UNCTAD constructs a set of 
average prices indexes at the three-digit product classification of the Standard International Trade Classification revision 3 using 
UNCTAD's Commodity Price Statistics, international and national sources, and UNCTAD secretariat estimates and calculates unit value 
indexes at the country level using the current year's trade values as weights.
United Nations Conference on Trade and Development, Handbook of Statistics and data files, and International Monetary Fund, International 
Financial Statistics.*/
sort country year
qui saveold "$path_out/TT_wdi.dta", replace 
erase "$path_out/TT_aux.dta"
merge country year using "$path_out/Divergence.dta"
keep if _merge==3
drop _merge

/*For each A`i', we have 2 types of dummies:
- A`i'_`j'	  =1 when A`i'>`j'/100 over 40 or more yrs	
- A`i'_`j'end=1 when A`i'>`j'/100 in the final year
*/

forvalues i=1(1)3{
	g inter`i'=year*A`i'
	bys country: g AL`i'=A`i'[_n-1]
	g interL`i'=year*AL`i'

	forvalues j=30(10)50{
		g inter`i'_`j'=year*A`i'_`j'
		g inter`i'_`j'_00=year*A`i'_`j'_00
		g inter`i'_`j'end=year*A`i'_`j'end
	}
}
g lnbtti=ln(nbtti)

egen c = group(country)
xtset c year

forvalues i=1(1)3{
eststo clear
forvalues j=30(10)50{
local a1="`i'_`j'"
local a2="`i'_`j'end"
local a3="`i'_`j'_30yr"
local a4="`i'_`j'_00"
	eststo: xtreg lnbtti year inter`a4', fe
	estadd local fixed "Yes", replace
	eststo: xtreg lnbtti year inter`a4' A`i' trade, fe
	estadd local fixed "Yes", replace
}
esttab using "$pc\Table_TT_`i'.tex",  b(3) prehead("Dependant variable: & \multicolumn{6}{c}{Terms of trade 1962-2000}  \\[1em]") ///
booktab fragment star(* 0.10 ** 0.05 *** 0.01) se replace nogap nomtitle order(A* trade) /// nocons indicate("[1em] Constant = _cons")
stats(fixed N r2, fmt(0 0 3) labels(`"Country-FE"' `"Obs."' `"\$R^{2}$"'))
}

*Graphs ploting change in nbtti against Ai
sort country year
g aux2=nbtti if year==1985 & nbtti!=.
g aux3=nbtti if year>=1985 & year<=1990 & nbtti!=.
bys country: egen ttini=mean(aux2)
bys country: egen ttini5=mean(aux3)

g aux4=nbtti if year==2000 & nbtti!=.
g aux5=nbtti if year==2010 & nbtti!=.
bys country: egen ttend00=mean(aux4)
bys country: egen ttend10=mean(aux5)

g dTT00=log(ttend00/ttini)
g dTT500=log(ttend00/ttini5)

g dTT10=log(ttend10/ttini)
g dTT510=log(ttend10/ttini5)

*Graph to use: relationship between A1 and dTT
twoway (lfitci dTT00 A1) (lfit dTT00 A1, lw(medthick) lp(solid) lc(black)) ///
(scatter dTT00 A1, mc(black)) if year==2000 & dTT00!=0, legend(off) ///
xtitle("intensity of A1 exports") ytitle("dTT") ///
graphr(color(white) ilcolor(white) fcolor(white) ifcolor(white) margin(medium))  ///
plotr(icolor(white) ilcolor(white) fcolor(white) ifcolor(white) margin(small))
graph2tex, epsfile("$pc\Figure_TT_1") //Figure A.7a


*Graph showing where are A-countries in TTE
g aux6=rgdpl if year==1962 & rgdpl!=.
g aux7=rgdpl if year==2000 & rgdpl!=.
g aux8=rgdpl if country=="USA"
bys year: egen aux9=mean(aux8)
bys country: egen Rrgdpl62=mean(aux6/aux9)
bys country: egen Rrgdpl00=mean(aux7/aux9)
g dR00=log(Rrgdpl00/Rrgdpl62)

twoway scatter dR00 dTT00 if A1_30==1, xline(0) yline(0)
twoway scatter dR00 dTT00 if A4_30==1, xline(0) yline(0) //Extractives
twoway scatter dR00 dTT00 if A1_30==1 | A4_30==1, xline(0) yline(0) //A+E
twoway (scatter dR00 dTT00) (scatter dR00 dTT00 if A1_30==1), xline(0) yline(0)
twoway (scatter dR00 dTT00) (scatter dR00 dTT00 if A1_30==1 | A4_30==1), xline(0) yline(0)

g aux10=rgdpl if year==2010 & rgdpl!=.
bys country: egen Rrgdpl10=mean(aux10/aux9)
g dR10=log(Rrgdpl10/Rrgdpl62)

twoway scatter dR10 dTT10 if A1_30end==1, xline(0) yline(0)

*2-Computes extended evolution including the period 1960-1985 using data from Barro and Lee (1993)
/* Info in http://admin.nber.org/pub/barro.lee/readme.txt
 
The data set contains variables for the panel estimation. Data are
presented either quinquennially for the years 1960-1985, i.e., 1960, 1965,
1970, 1975, 1980, and 1985, or for averages of five years' sub-periods over
1960-1985. The variables are named, when available, after those in
BARRO-WOLF. The term XX behind a variable denotes a specific year (for
example, P60 is the primary school enrollment ratio in 1960), while the term
X denotes average of a sub-period among the five year sub-periods: 1960-64,
1965-69,  1970-74, 1975-79,and 1980-84 for the averaged variables (e.g. INV3
denotes average investment rate during 1970-74). Some variables are also
available for the subperiod over 1985-1989 and for the year of 1990. Growth
rates are calculated for 1960-65 and so on. The data listed below are
available as ASCII files (see Appendix 2).

                       Appendix 1.  Country List
In "C:\Users\ourensbrocos\Documents\MEGA\data\Barro-Lee growth\shcodes.xls"					 

                       Appendix 2.  How to retrieve data.
The 30 files are found on the enclosed diskette.  Each of the files
contains data as described below.  The files are plain text (ASCII) files. Data
on each variable are listed by the order of SHCODE (see Appendix 1).  The
missing observations are denoted by 'NA'.

ASCII File                   Data
trade.prn        : ex1 ex2 ex3 ex4 ex5 im1 im2 im3 im4 im5 xr60 xr65 xr70 xr75
                 xr80 xr85 tot1 tot2 tot3 tot4 tot5
*/

import excel "$pc\data\Barro-Lee growth\shcodes.xls", sheet("Sheet1") firstrow clear
sort shcode
saveold "$pc\data\Barro-Lee growth\shcodes.dta", replace
import excel "$pc\data\Barro-Lee growth\trade.xls", sheet("Sheet1") firstrow clear
keep tot*
g shcode=_n
drop if shcode==139
sort shcode
merge shcode using "$pc\data\Barro-Lee growth\shcodes.dta"
drop _merge
order shcode country_name country_isocode

*Overall aggregate change 1960-1985
g dTT6585=((1+tot1)*(1+tot2)*(1+tot3)*(1+tot4)*(1+tot5))^5-1

*10-yr aggregate change
g tot_10_1970=((1+tot1)^5)*((1+tot2)^5)-1
g tot_10_1980=((1+tot3)^5)*((1+tot4)^5)-1

*5-yr aggregate change
rename tot1 tot1965
rename tot2 tot1970
rename tot3 tot1975
rename tot4 tot1980
rename tot5 tot1985

rename country_isocode country
sort country
saveold "$path_out/TT_aux1.dta", replace

u "$path_out/TT_wdi.dta", clear
forvalues y=1980(5)2010{
g aux`y'=nbtti if year==`y' & nbtti!=.
bys country: egen tt`y'=mean(aux`y')
}
g tot1990=(tt1990-tt1985)/tt1985
g tot1995=(tt1995-tt1990)/tt1990
g tot2000=(tt2000-tt1995)/tt1995
g tot2005=(tt2005-tt2000)/tt2000
g tot2010=(tt2010-tt2005)/tt2005

g tot_10_1990=(tt1990-tt1980)/tt1980
g tot_10_2000=(tt2000-tt1990)/tt1990
g tot_10_2010=(tt2010-tt2000)/tt2000

g dTT8595=(tt1995-tt1985)/tt1985
g dTT8500=(tt2000-tt1985)/tt1985
g dTT8505=(tt2005-tt1985)/tt1985
g dTT8510=(tt2010-tt1985)/tt1985
keep if year==1985 & nbtti!=.
drop year nbtti aux*
sort country
saveold "$path_out/TT_aux2.dta", replace

u "$path_out/Divergence.dta", clear

forvalues y=1960(5)2010{
g aux`y'=rgdpl if year==`y'
bys country: egen gdp`y'=mean(aux`y')
g aux`y'usa=rgdpl if year==`y' & country=="USA"
egen gdp`y'usa=mean(aux`y'usa)
g r`y'=gdp`y'/gdp`y'usa
}
forvalues y=1965(5)2010{
local j=`y'-5
g ravg`y'=log(r`y'/r`j')
}
forvalues y=1970(10)2010{
local j=`y'-10
g ravg_10_`y'=log(r`y'/r`j')
}
g r6510=log(r2010/r1965)
g r6500=log(r2000/r1965)
g r8510=log(r2010/r1985)

keep if year==2000
drop year
sort country
merge country using "$path_out/TT_aux1.dta"
keep if _merge==3
drop _merge
sort country
merge country using "$path_out/TT_aux2.dta"
keep if _merge==3
drop _merge
g dTT95=(1+dTT6585)*(1+dTT8595)-1
g dTT00=(1+dTT6585)*(1+dTT8500)-1
g dTT05=(1+dTT6585)*(1+dTT8505)-1
g dTT10=(1+dTT6585)*(1+dTT8510)-1
*The previous are aggregated changes. We convert them in average annual changes (as in A&V) by:
g gTT00=(dTT00+1)^(1/41)-1
g gTT10=(dTT10+1)^(1/51)-1
saveold "$path_out/TT_aux3.dta", replace

*Reversed TTE 1965-2000
twoway (scatter r6500 dTT00, mlabel(country) m(none) mlabp(0) mlabc(gs9)) ///
(scatter r6500 dTT00 if A1_30==1, mlabel(country) m(none) mlabp(0) mlabc(black)), ///
legend(off) xline(0, lpattern(dash) lcolor(black)) yline(0, lpattern(dash) lcolor(black)) ///
xtitle("% Change Terms of Trade") ytitle("% Change per capita GDP relative to US") ///
graphr(color(white) ilcolor(white) fcolor(white) ifcolor(white) margin(medium))  ///
plotr(icolor(white) ilcolor(white) fcolor(white) ifcolor(white) margin(small))
graph2tex, epsfile("$pc\Research\4_Div&Div\written\Figure_TT_3") //Figure 5 in the text.

*Reversed TTE 1965-2010
twoway (scatter r6510 dTT10 if A1_30!=1, mc(black) msymbol(X)) (scatter r6510 dTT10 if A1_30==1, mc(black)) (lfit r6510 dTT10, lcolor(gs11)), ///
legend(off) xline(0, lpattern(dash) lcolor(black)) yline(0, lpattern(dash) lcolor(black)) ///
xtitle("change in TT (1965-2010)") ytitle("change in GDPpc relative to US (1965-2010)") ///
graphr(color(white) ilcolor(white) fcolor(white) ifcolor(white) margin(medium))  ///
plotr(icolor(white) ilcolor(white) fcolor(white) ifcolor(white) margin(small))

*Replica of Figure_TT_1 for the entire period 1962-2000
twoway (lfitci dTT00 A1) (lfit dTT00 A1, lw(medthick) lp(solid) lc(black)) ///
(scatter dTT00 A1, mc(black)), legend(off) ///
xtitle("intensity of A1 exports") ytitle("dTT") ///
graphr(color(white) ilcolor(white) fcolor(white) ifcolor(white) margin(medium))  ///
plotr(icolor(white) ilcolor(white) fcolor(white) ifcolor(white) margin(small))
graph2tex, epsfile("$pc\Figure_TT_2") //Figure A.7b

*Same thing for period 1962-2010
twoway (lfitci dTT10 A1) (lfit dTT10 A1, lw(medthick) lp(solid) lc(black)) ///
(scatter dTT10 A1, mc(black)), legend(off) ///
xtitle("intensity of A1 exports") ytitle("dTT") ///
graphr(color(white) ilcolor(white) fcolor(white) ifcolor(white) margin(medium))  ///
plotr(icolor(white) ilcolor(white) fcolor(white) ifcolor(white) margin(small))
graph2tex, epsfile("$pc\Figure_TT_4")


*****************************************************
*3-Contrasts results with Acemoglu and Ventura (2002)
*****************************************************

*Set of A-dummies
u "$path_out\A.dta", clear
rename country_iso country
bys country: g n=_n
keep if n==1
keep country A*
sort country
saveold "$path_out/A_aux1.dta", replace


*3.1-Replicating results in Acemoglu and Ventura 2002
*Barro and Lee data
import excel "$pc\data\Barro-Lee growth\shcodes.xls", sheet("Sheet1") firstrow clear
sort shcode
saveold "$pc\data\Barro-Lee growth\shcodes.dta", replace

import excel "$pc\data\Barro-Lee growth\trade.xls", sheet("Sheet1") firstrow clear
keep tot*
g shcode=_n
drop if shcode==139
sort shcode
merge shcode using "$pc\data\Barro-Lee growth\shcodes.dta"
drop _merge
gen totgr=((1+tot2)*(1+tot3)*(1+tot4)*(1+tot5))^(1/4)-1  //Geometric average of 5yr-tot changes (1965-1985)
rename country_isocode country
keep shcode country totgr
sort shcode
saveold "$path_out/TT_aux1.dta", replace

import excel "$pc\data\Barro-Lee growth\educ.xls", sheet("Sheet1") firstrow clear
g shcode=_n
sort shcode
merge shcode using "$pc\data\Barro-Lee growth\shcodes.dta"
rename country_isocode country
rename syr65 syr
rename hyr65 hyr
rename pyr65 pyr
gen yr=syr+hyr+pyr
keep shcode country sy* hy* py* y*
sort shcode
saveold "$path_out/ED_aux1.dta", replace

import excel "$pc\data\Barro-Lee growth\fert1.xls", sheet("Sheet1") firstrow clear
g shcode=_n
sort shcode
merge shcode using "$pc\data\Barro-Lee growth\shcodes.dta"
rename country_isocode country
rename lifee02 lifee 
gen llifee=log(lifee)
keep shcode country llifee
sort shcode
saveold "$path_out/LI_aux1.dta", replace

import excel "$pc\data\Barro-Lee growth\gdp.xls", sheet("Sheet1") firstrow clear
g shcode=_n
sort shcode
merge shcode using "$pc\data\Barro-Lee growth\shcodes.dta"
tab _merge
drop _merge
rename country_isocode country
gen gdpgr=((1+grsh52)*(1+grsh53)*(1+grsh54)*(1+grsh55))^(1/4)-1
gen loggdp=log(gdpsh565)
keep shcode country gdpgr loggdp
sort shcode
merge shcode using "$path_out/TT_aux1.dta"
tab _merge
keep if _merge==3
drop _merge
sort shcode
merge shcode using "$path_out/ED_aux1.dta"
tab _merge
keep if _merge==3
drop _merge
sort shcode
merge shcode using "$path_out/LI_aux1.dta"
tab _merge
keep if _merge==3
drop _merge
rename shcode id
gen opec=1 if (id==1|id==15|id==32|id==78|id==80|id==87|id==88|id==93|id==96|id==99|id==86) //Opec dummy as generated in A&V02
recode opec .=0
sort country
saveold "$path_out/BarroLee_aux.dta", replace

*to get the exact same results in the paper:
keep if country!="FJI" & country!="ISL" & country!="MOZ"

*to get the exact same results as in the do-file of AV02:
*keep if country!="CYP" & country!="FJI" & country!="ISL" & country!="MOZ"

*Acemoglu and Ventura's program:
** REGRESSION 1: **
ivreg totgr (gdpgr=loggdp) yr llifee opec, first //First column in Table I
reg totgr gdpgr yr llifee opec					 //Panel C of the same table

*The following steps are for the construction of Figure III
reg gdpgr loggdp yr llifee opec		//Eq 21
predict gdpgrhat
reg gdpgrhat yr llifee opec
predict gdpgrres, resid				//Part of residuals from eq 21 that is orthogonal to yr llifee opec
reg totgr yr llifee opec
predict totgrres, resid
twoway (scatter totgrres gdpgrres, mlabel(country) m(none) mlabp(0)) (lfit totgrres gdpgrres)

*3.1.1-Where are A-countries?
sort country
merge country using "$path_out/A_aux1.dta"

twoway (scatter totgrres gdpgrres, mlabel(country) m(none) mlabp(0) mlabc(gs9)) ///
(scatter totgrres gdpgrres if A1_30end==1 & A4_30end!=1, mlabel(country) m(none) mlabp(0) mlabc(black)) ///
(lfit totgrres gdpgrres, lw(medthick) lp(solid) lc(black)), legend(off) ///
xtitle("Residual Terms of Trade Growth") ytitle("Residual GDP Growth") ///
graphr(color(white) ilcolor(white) fcolor(white) ifcolor(white) margin(medium))  ///
plotr(icolor(white) ilcolor(white) fcolor(white) ifcolor(white) margin(small))
graph2tex, epsfile("$pc\Figure_TT_AV1")  //Figure A.6a in the text.

*3.1.2-Testing whether TTE depends on economic size: (I dont use aggregate GDP as that is already inside Z)
u "$pc\data\PWT\PWT8.1\pwt8.1.dta", clear
drop country
rename country_iso country
g lPOP=log(pop)
bys country: egen lPOPini=mean(lPOP) if year>=1960 & year<=1965 //
keep if year==1965
keep country lPOPini
sort country
merge country using "$path_out/BarroLee_aux.dta"
keep if _merge==3
keep if country!="FJI" & country!="ISL" & country!="MOZ"

ivreg totgr (gdpgr=loggdp) yr llifee opec if lPOPini!=., first
*we only have 72 obs instead of 79 as in ACV02 but results still resmble those of the paper

*First I evaluate size as a part of controls Z
ivreg totgr (gdpgr=loggdp) yr llifee opec lPOPini, first
*Size is not signifficant!

*Second, I evaluate whether size matters in the relationship between residual gdp and residual dTT
reg gdpgr loggdp yr llifee opec		//Eq 21
predict gdpgrhat
reg gdpgrhat yr llifee opec
predict gdpgrres, resid				//Part of residuals from eq 21 that is orthogonal to yr llifee opec
reg totgr yr llifee opec
predict totgrres, resid
reg totgrres gdpgrres lPOPini
*Size is not signifficant!


*3.2-Extends AV02's methodology using 1 obs per country: Barro and Lee's data until 85 and PWT and WDI since

u "$path_out/TT_wdi.dta", replace
forvalues y=1980(1)2010{
g aux`y'=nbtti if year==`y' & nbtti!=.
bys country: egen tt`y'=mean(aux`y')
}
forvalues y=1985(5)2010{
local j=`y'-5
g tot`y'A=(tt`y'-tt`j')/(tt`j'*5)-1 //approximation of arithmetic avg yearly change
}
bys country: g n=_n
keep if n==1
g totgr2=(tot1990A+tot1995A+tot2000A+tot2005A)/4-1
keep country totgr
keep if totgr2!=.
sort country
saveold "$path_out/TT_aux2.dta", replace

u "$pc\data\PWT\PWT8.1\pwt8.1.dta", clear
drop country
*rename countrycode country
rename country_isocode country
forvalues y=1985(5)2010{
g aux`y'=log(rgdpe/pop) if year==`y'
bys country: egen lgdp`y'=mean(aux`y')
}
forvalues y=1985(5)2005{
local j=`y'+5
g grsh`j'=(lgdp`y'/lgdp`j')^(1/5)-1 //geometric avg yearly change
}
bys country: g n=_n
keep if n==1
g gdpgr2=((1+grsh1990)*(1+grsh1995)*(1+grsh2000)*(1+grsh2005))^(1/4)-1
keep country gdpgr2
drop if gdpgr2==.
sort country
merge country using "$path_out/TT_aux2.dta"
keep if _merge==3
drop _merge
sort country
merge country using "$path_out/BarroLee_aux.dta"
*tab country if _merge==2 & totgr!=. & gdpgr!=. & loggdp!=. & yr!=. & llifee!=. &  opec!=.
keep if _merge==3
g totgr3=((1+totgr)*(1+totgr2))^(1/2)-1
g gdpgr3=((1+gdpgr)*(1+gdpgr2))^(1/2)-1
keep country gdpgr3 totgr3 id gdpgr totgr yr llifee opec loggdp syr hyr pyr
sort country
merge country using "$path_out/A_aux1.dta"
keep if _merge==3 //not losing valuable obs here
drop _merge

count if totgr3!=. & gdpgr3!=. & loggdp!=. & yr!=. & llifee!=. &  opec!=.
sort country
saveold "$path_out/TT_all1.dta", replace

keep if country!="FJI" & country!="ISL" & country!="MOZ"
ivreg totgr (gdpgr=loggdp) yr llifee opec, first //First column in Table I
reg totgr gdpgr yr llifee opec					 //Panel C of the same table

drop if totgr ==.
drop if gdpgr ==.
drop if loggdp ==.
drop if yr ==.
drop if llifee ==.

reg gdpgr loggdp yr llifee opec		//Eq 21
predict gdpgrhat
reg gdpgrhat yr llifee opec
predict gdpgrres, resid				//Part of residuals from eq 21 that is orthogonal to yr llifee opec
reg totgr yr llifee opec
predict totgrres, resid

twoway (scatter totgrres gdpgrres, mlabel(country) m(none) mlabp(0) mlabc(gs9)) ///
(scatter totgrres gdpgrres if A1_30end==1 & A4_30end!=1, mlabel(country) m(none) mlabp(0) mlabc(black)) ///
(lfit totgrres gdpgrres, lw(medthick) lp(solid) lc(black)), legend(off) ///
xtitle("Residual Terms of Trade Growth") ytitle("Residual GDP Growth") ///
graphr(color(white) ilcolor(white) fcolor(white) ifcolor(white) margin(medium))  ///
plotr(icolor(white) ilcolor(white) fcolor(white) ifcolor(white) margin(small))
graph2tex, epsfile("$pc\Figure_TT_AV2") //Figure A.6b in the text.

*Table we use
u "$path_out/BarroLee_aux.dta", clear
keep if country!="FJI" & country!="ISL" & country!="MOZ"
eststo clear
eststo: ivreg totgr (gdpgr=loggdp) yr llifee opec
eststo: ivreg totgr (gdpgr=loggdp) syr hyr pyr llifee opec, first
u "$path_out/TT_all1.dta", clear
keep if country!="FJI" & country!="ISL" & country!="MOZ"
eststo: ivreg totgr (gdpgr=loggdp) yr llifee opec
eststo: ivreg totgr (gdpgr=loggdp) syr hyr pyr llifee opec, first
sort country
merge country using "$path_out/A_aux1.dta"
eststo: ivreg totgr (gdpgr=loggdp) syr hyr pyr llifee opec A1_30end, first
eststo: ivreg totgr (gdpgr=loggdp) syr hyr pyr llifee opec A1_50end, first
eststo: ivreg totgr (gdpgr=loggdp) syr hyr pyr llifee opec A2_30end, first
eststo: ivreg totgr (gdpgr=loggdp) syr hyr pyr llifee opec A2_50end, first
eststo: ivreg totgr (gdpgr=loggdp) syr hyr pyr llifee opec A3_30end, first
eststo: ivreg totgr (gdpgr=loggdp) syr hyr pyr llifee opec A3_50end, first
esttab using "$pc\Table_TT_AV.tex",  b(3) posthead(" \midrule & \multicolumn{10}{c}{Panel A: 2SLS} \\ \midrule") ///
booktab fragment star(* 0.10 ** 0.05 *** 0.01) se replace nogap nomtitle noobs order(gdpgr yr syr hyr pyr llifee opec A*) // Table A.16 in the text.



