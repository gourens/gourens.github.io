/****************
NATURAL RESOURCES
*****************
This do file:
1-creates database (A.dta) with 
	-different measures of importance in exports of A-goods (A1-3)
	-a measure of importance of export of extractive products (A4)
	-dummies signaling countries that export those products at the end of the period (A`i'_`j'end)
	-dummies signaling countries that export those products at year 2000 (A`i'_`j'00)
	-dummies signaling countries for which A exports are important for 40 years (A`i'_`j')
	-dummies signaling countries for which A exports are important at each country initial year in the sample (A`i'_`j'ini)	
	-variable E (A4) measuring the importance of extractive resources
2-counts how many different categories we have in each of our clasiff (A1, A2, A3, E) according to SITCRev2
3-creates a database (A_Imports.dta) with variables
	-M, and M1-M4: the sum of all imports of each country and the sum of imports in A and E goods
	-A1-4: importance of A and E goods in each country's imports
	-We find that:
		-worldwide trade increases steadly, and even stronger after 2000
		-trade in A also grows
		-the weight of trade in A falls
		-the weight of A trade falls almost for every country: the fall is more evident for industrialized economies
4-Creates map with A-intensity
5-Computes changes in A1 over the whole period. Counts how many countries in each dummy.
6-Compares our A-lists with those for homogeneous goods in Rauch (1999) and compares average elasticities of 
  substitution for each industry (using data from Broda and Weinstein, 2006).
	-We find that:
		-Our lists of A goods do not perfectly match Rauch's classification.
		-Regarding the elasticity of substitution sigma we see that for both the median and the mean:
			-sigma A is larger than sigma M
			-sigma Ai decreases with i and sigma M increases with i for i=1,2,3
7-Computes avg and median proximity by sector using proximity9800 by Hidalgo et al. (2007)
*/

version 8
if c(username)=="Guzman" global pc="C:\Users\Guzman\"
if c(username)=="gourens" global pc="C:\Users\gourens\"


*1 Proportion of exports in food

*Feenstra (1962-2000)
u "$path_in/country compatibility.dta", clear
qui sort country_feenstra
saveold "$path_in/country compatibility.dta", replace
forvalues p=62(1)100 {
	qui if "`p'"!="100" local y="`p'"
	qui if "`p'"=="100" local y="00"
	qui u "$path_in/Feenstra/wtf`y'.dta", clear
	qui keep if importer=="World"
	qui bys  exporter sitc4: egen x=sum(value)
	qui bys  exporter sitc4: g n=_n
	qui keep if n==1
	qui keep  year exporter sitc4 x
	qui rename sitc4 good
	qui rename exporter country_feenstra
	qui sort country_feenstra
	qui merge country_feenstra using "$pc/PhD/1_MR/datasets/country compatibility.dta"	// ads isocodes
	qui drop if _merge!=3
	qui drop _merge num country_feenstra code_comtrade
	qui local j=`p'+1900
	qui keep year good country_isocode x
	qui sort country_isocode year
	qui saveold "$path_out/export_`j'.dta", replace
}

*COMTRADE SITCRev2
forvalues p=2001(1)2014 {
qui import delimited "$path_in\SITCR2_5d\type-C_r-ALL_ps-`p'.csv", clear
qui keep if partner=="World" & tradeflow=="Export"
qui keep if agg==4
qui rename commoditycode good
qui rename reporteriso country_isocode
qui drop if country_iso=="" | good=="TOTAL"
bys country_iso good: egen x=sum(tradevalueus/1000)
qui bys country_iso good: g n=_n
qui keep if n==1
qui keep year good country_isocode x
qui sort country_isocode year
saveold "$path_out/export_`p'.dta", replace
}

forvalues y=1962(1)2014{
	qui u "$path_out/export_`y'.dta", clear
	global class="SITCR2-4d"
	qui do "$path_do\A-Lists.do" // goods classification
	qui bys country_isocode: egen a0=total(x)
	
	forvalues i=1(1)4{
	qui {
	bys country_isocode: egen a4`i'=total(x) if a`i'==1
	bys country_isocode: egen a5`i'=min(a4`i')
	g A`i'=a5`i'/a0
	}
	}
	
	qui bys country_isocode: g a6=_n
	qui keep if a6==1
	qui keep country_isocode year A*
	qui saveold "$path_out/erase_`y'.dta", replace			
}

forvalues y=1962(1)2014{
	qui if ("`y'"=="1962") u "$path_out/erase_`y'.dta", clear
	qui if ("`y'"!="1962") append using "$path_out/erase_`y'.dta"
}

bys country (year): g a10=_n
g iyear=a10 if a10==1
g eyear=1 if year==2014

forvalues i=1(1)4{
forvalues j=30(10)50{
	qui {
	local l=`j'/100
	
	g a6`i'`j'=1 if (eyear==1 & A`i'>`l' & A`i'!=.)
	bys country_isocode: egen A`i'_`j'end=min(a6`i'`j')
	replace A`i'_`j'end=0 if A`i'_`j'end==.
	label var A`i'_`j'end "=1 if A`i'>`l' at the end year"
	
	g a7`i'`j'=1 if (year==2000 & A`i'>`l' & A`i'!=.)
	bys country_isocode: egen A`i'_`j'_00=min(a7`i'`j')
	replace A`i'_`j'_00=0 if A`i'_`j'_00==.
	label var A`i'_`j'_00 "=1 if A`i'>`l' in 2000"
	
	bys country: g a`i'`j'=1 if A`i'>`l'
	bys country: egen a`i'`j'2=total(a`i'`j')
	bys country: g A`i'_`j'=(a`i'`j'2>40)
	replace A`i'_`j'=0 if A`i'_`j'==.
	label var A`i'_`j' "=1 if A`i'>`l' for 40 years or more"
	
	g a8`i'`j'=1 if (iyear==1 & A`i'>`l' & A`i'!=.)
	bys country: egen A`i'_`j'ini=min(a8`i'`j')
	replace A`i'_`j'ini=0 if A`i'_`j'ini==.
	label var A`i'_`j'ini "=1 if A`i'>`l' at the initial year"
	
	bys country: g a`i'`j'3=1 if A`i'>`l' & year<2001
	bys country: egen a`i'`j'4=total(a`i'`j'3)
	bys country: g A`i'_`j'_30yr=(a`i'`j'4>30)
	replace A`i'_`j'_30yr=0 if A`i'_`j'==.
	label var A`i'_`j'_30yr "=1 if A`i'>`l' for 30 years or more until 2000"
}
}
}

qui label var A1 "Importance of non-extractive A exports"
qui label var A2 "Importance of non-extractive A exports (incl all kinds of fertilizers and organic chemicals)"
qui label var A3 "Importance of non-extractive A exports (incl, besides A2, manuf products of A origin)"
qui label var A4 "Importance of extractive exports"

qui drop if country_isocode==""
qui drop a*
qui order country year
qui sort country year
saveold "$path_out/A.dta", replace

forvalues y=1962(1)2014{
	erase "$path_out/erase_`y'.dta"
	erase "$path_out/export_`y'.dta"
}

*2 Counting how many different categories we have in each of our clasiff (A1, A2, A3, E)*****************************************
insheet using "$path_in\Feenstra\SITCRev2.txt", clear
g good= substr(v1,1,4)
drop if _n==1
global class="SITCR2-4d"
qui do "$path_do\A-Lists.do" // goods classification

count if good!="" //1239 in total
count if a1==1 //308 of A1
count if a2==1 //351 of A2
count if a3==1 //401 of A3
count if a4==1 //158 of E


import excel "$path_in\SITCR1_5dzip\SITC Rev1.xls", sheet("SITC Revision 1") clear
rename A good
drop if good=="TOTAL"
g length = length(good)
keep if length==4 | length==5
qui g aux1= substr(good,1,4)
bys aux1: g n=_n
bys aux1: egen m=max(n)
g aux3=1 if m==1 | (m>1 & n!=1)
destring good, replace
replace good=good*10 if length==4
global class="SITCR1-5d"
qui do "$path_do\A-Lists.do" // goods classification
count if good!=. //1659 in total
count if a1==1 //375 of A1
count if a2==1 //461 of A2
count if a3==1 //669 of A3
count if a4==1 //206 of E


u "$path_in\BACI\product_code_baci92.dta", clear
rename code hs6
drop if hs6=="9999AA"
destring hs6, replace
global class="HS0-6d"
qui do "$path_do\A-Lists.do" // goods classification

count if hs6!=. //5038 in total
count if a1==1 //833 of A1
count if a2==1 //1183 of A2
count if a3==1 //1983 of A3
count if a4==1 //1032 of E

*3 Proportion of imports in food*************************************************************************************************

u "$path_in/country compatibility.dta", clear
qui sort country_feenstra
saveold "$path_in/country compatibility.dta", replace

*Feenstra
forvalues p=62(1)100 {
qui if "`p'"!="100" local y="`p'"
qui if "`p'"=="100" local y="00"
qui {
u "$path_in/Feenstra/wtf`y'.dta", clear
keep if exporter=="World"
bys importer sitc4: g n=_n
keep if n==1
keep  year importer sitc4 value
rename sitc4 good
rename value m
rename importer country_feenstra
sort country_feenstra
merge country_feenstra using "$path_in/country compatibility.dta"	// ads isocodes
drop if _merge!=3
drop _merge num country_feenstra code_comtrade
keep year good country_isocode m
drop if country==""
order country year good
global class="SITCR2-4d"
qui do "$path_do\A-Lists.do" // goods classification
bys country: egen I=total(m)
forvalues i=1(1)4{
	bys country: egen a4`i'=total(m) if a`i'==1
	bys country: egen I`i'=min(a4`i')
	g A`i'=I`i'/I
	label var I`i' "total imported in A`i' goods"
	label var A`i' "importance of A`i' goods in imports"
}
label var I "total imported"
rename A4 E
label var I4 "total imported in E goods"
label var E "importance of E goods in imports"
	
bys country: g a6=_n
keep if a6==1
keep country year A* E I*
local j=`p'+1900
sort country year
}
saveold "$path_out/import_`j'.dta", replace
}

*COMTRADE SITCRev2
forvalues p=2001(1)2014 {
import delimited "$path_in\SITCR2_5d\type-C_r-ALL_ps-`p'.csv", clear
keep if partner=="World" & tradeflow=="Import"
keep if agg==4
rename commoditycode good
rename reporteriso country_isocode
drop if country_iso=="" | good=="TOTAL"
bys country_iso good: egen m=sum(tradevalueus/1000)
qui bys country_iso good: g n=_n
keep if n==1
global class="SITCR2-4d"
qui do "$path_do\A-Lists.do" // goods classification
bys country: egen I=total(m)
forvalues i=1(1)4{
	bys country: egen a4`i'=total(m) if a`i'==1
	bys country: egen I`i'=min(a4`i')
	g A`i'=I`i'/I
	label var I`i' "total imported in A`i' goods"
	label var A`i' "importance of A`i' goods in imports"
	}
label var I "total imported"
rename A4 E
label var I4 "total imported in E goods"
label var E "importance of E goods in imports"

bys country: g a6=_n
keep if a6==1
keep country year A* E I*
sort country year
saveold "$path_out/import_`p'.dta", replace
}

forvalues y=1962(1)2014{
	qui if ("`y'"=="1962") u "$path_out/import_`y'.dta", clear
	qui if ("`y'"!="1962") append using "$path_out/import_`y'.dta"
	qui	erase "$path_out/import_`y'.dta"
}

bys year: egen totI=sum(I)
forvalues i=1(1)4{
bys year: egen totI`i'=sum(I`i')
g totA`i'=totI`i'/totI
label var totI`i' "worldwide trade in A`i' goods"
label var totA`i' "importance of A`i' goods in worldwide trade"
}
label var totI "worldwide trade"

sort country year
saveold "$path_out/A_Imports.dta", replace

twoway scatter totI year
twoway scatter totI1 year
twoway scatter totI1 year
twoway scatter totI2 year
twoway scatter totI3 year

/*We find that:
-worldwide trade increases steadly, and even stronger after 2000
-trade in A also grows
-the weight of trade in A falls
-the weight of A trade falls almost for every country: the fall is more evident for industrialized economies*/

label var totA1 "A1"
label var totA2 "A2"
label var totA3 "A3"

twoway (line totA1 year if country=="ARG", lw(medthick) lp(solid) lc(black)) /// I write ARG because I need only one set of obs
(line totA2 year if country=="ARG" , lw(medium) lp(solid) lc(black)) ///
(line totA3 year if country=="ARG", lw(medium) lp(dash) lc(black)), xtitle("year") ytitle("share") legend(cols(3)) ///
graphr(color(white) ilcolor(white) fcolor(white) ifcolor(white) margin(medium))  ///
plotr(icolor(white) ilcolor(white) fcolor(white) ifcolor(white) margin(small))
graph export "$path_in\Figure_A_1.pdf"  //Figure A.3 in the text


foreach j in ARG AUS BEL CHN GBR IND JPN USA URY {
twoway (line A1 year if country=="`j'", lw(medium) lc(black)), ///
xtitle("year") ytitle("share") legend(off) ///
graphr(color(white) ilcolor(white) fcolor(white) ifcolor(white) margin(medium)) ///
plotr(icolor(white) ilcolor(white) fcolor(white) ifcolor(white) margin(small))
graph export "$path_in\Figure_A_2_`j'.pdf" //Figure A.4 in the text
}


*5*************************************************************************************************

u "$path_out/A.dta", clear
keep if year==2000 | (year==2001 & (country=="NAM" | country=="BWA"))
keep country_iso A*
sort country_isocode
saveold "$path_out/A_aux.dta", replace

u "$pc/Dropbox\data\world_countries/world_countries", clear
drop if wb_a3=="-99"
keep sov_a3 country_c
replace sov_a3="AUS" if sov_a3=="AU1"
replace sov_a3="CHN" if sov_a3=="CH1"
replace sov_a3="DNK" if country_c==44
replace sov_a3="GRL" if country_c==66
replace sov_a3="FIN" if sov_a3=="FI1"
replace sov_a3="FRA" if country_c==56
replace sov_a3="NCL" if country_c==114
replace sov_a3="GBR" if sov_a3=="GB1"
replace sov_a3="NLD" if sov_a3=="NL1"
replace sov_a3="NZL" if sov_a3=="NZ1"
replace sov_a3="USA" if country_c==169
replace sov_a3="PRI" if country_c==129
replace sov_a3="SDS" if sov_a3=="SSD"
rename sov_a3 country_isocode
merge m:m country_isocode using "$path_out/A_aux.dta"
drop _merge
drop if country_c==7 //Antarctica

colorpalette viridis, n(12) nograph reverse
local color `r(p)'
spmap A1 using "$path_out/worldcoord", id(country_c) fcolor("`color'") clmethod(quantile) clnumber(9) legend(pos(7) size(large)) ocolor(white ..) osize(0.05 ..) legtitle("A-intensity") legstyle(2) legend(pos(7) size(2.8))
graph2tex, epsfile("$path_in\Figure_A1_intensity") //Figure 1 in the text

erase "$path_out/A_aux.dta"

*5*************************************************************************************************

u "$path_out\A.dta", clear
keep if year==2000
collapse (sum) A*


*6-Compares our A-lists with those for homogeneous goods in Rauch (1999) and compares average elasticities of substitution for each industry (using data from Broda and Weinstein, 2006: 72-88).

import excel "$pc\Broda-Weinstein\ElasticitiesBrodaWeinstein72-88_SITCRev2_4-digit.xls", sheet("Sheet1") cellrange(A4:B11044) firstrow clear
rename SITCRev24digit sitc2_T4
rename Sigma19721988 sigma
*sigma for good g is the elasticity of substitution among varieties of good g, and is assumed to be above unity (B&W06, p.557).
drop if sitc2_T4==.
sort sitc2_T4
saveold "$pc\Broda-Weinstein\ElasticitiesBrodaWeinstein72-88_SITCRev2_4-digit.dta", replace

***********************from Rauch1999**************************
import delimited "$pc\Rauch_1999\sitc_r2.txt", delimiter(space) clear
*Clean
egen descrip=concat(description-v16), punct(" ")
drop bea-v16
gen lastdig=substr(sitc2,-1,.)
gen lasttwodig=substr(sitc2,-2,.)
gen Tier=4
replace Tier=3 if lastdig=="X" & lasttwodig~="XX"
replace Tier=2 if lasttwodig=="XX"
destring sitc2, gen(sitcnum) ignore("XX X A")
drop if lastdig=="A"

*Create Tier variables
gen sitc2_T4=sitcnum if Tier==4
replace sitc2_T4=sitcnum*10 if Tier==3

gen sitc2_T3=sitcnum if Tier==3
replace sitc2_T3=int(sitcnum/10) if Tier==4

gen sitc2_T2=sitcnum if Tier==2
replace sitc2_T2=int(sitcnum/10) if Tier==3
replace sitc2_T2=int(sitcnum/100) if Tier==4
 
sort sitc2_T2 sitc2_T3 sitc2_T4

*Only keep those that are Tier 3 or 4
drop if sitc2_T4==. & sitc2_T3==.

*Merge in 4-digit classification
merge m:1 sitc2_T4 using "$pc\Rauch_1999\Rauch_classification_revised.dta", gen(_merge_revclas)
gen con_4=con
gen lib_4=lib

*Merge in 3-digit classification
merge m:1 sitc2_T3 using "$pc\Rauch_1999\Rauch_classification_revised_T3.dta", gen(_merge_revclasT3) update
rename con con_34
rename lib lib_34
/*Coding Scheme
    w=goods traded on an organized exchange (homogeneous goods)
    r=reference priced
    n=differentiated products
The "conservative" clasiffication maximizes the number of n while the "liberal" maximizes w and r (See Rauch 1999, p.15).*/
***********************from Rauch1999**************************

***********************My clasification************************
rename sitc2 good
global class="SITCR2-4d"
qui do "$path_do\A-Lists.do" // goods classification

replace a1=0 if a1==.
replace a2=0 if a2==.
replace a3=0 if a3==.
replace a4=0 if a4==.
drop aux*
qui label var a1 "Non-extractive A exports"
qui label var a2 "Non-extractive A exports (incl all kinds of fertilizers and organic chemicals)"
qui label var a3 "Non-extractive A exports (incl, besides A2, manuf products of A origin)"
qui label var a4 "Extractive exports"
***********************My clasification************************

*Comparison between my classification and Rauch's
g R_con1=(con_34=="w")
g R_con2=(con_34=="w" | con_34=="r")
g R_lib1=(lib_34=="w")
g R_lib2=(lib_34=="w" | lib_34=="r")
corr R* a*
/*
             |   R_con1   R_con2   R_lib1   R_lib2       a1       a2       a3       a4
-------------+------------------------------------------------------------------------
      R_con1 |   1.0000
      R_con2 |   0.4449   1.0000
      R_lib1 |   0.7991   0.5568   1.0000
      R_lib2 |   0.4166   0.9363   0.5213   1.0000
          a1 |   0.3110   0.3311   0.3527   0.3369   1.0000
          a2 |   0.2722   0.3936   0.3160   0.3941   0.9207   1.0000
          a3 |   0.2319   0.3689   0.2811   0.3682   0.8411   0.9136   1.0000
          a4 |   0.1177   0.2709   0.2064   0.2898  -0.1575  -0.1710  -0.1872   1.0000 Correlations with a4 are low due to a4=0 so many times
*/

*Comparison between my classification and B&W's sigmas
*We expect homogeneous goods to have highly sustitutable varieties so they should present a large sigma
sort sitc2_T4
merge m:1 sitc2_T4 using "$pc\Desktop\data\Broda-Weinstein (2006)\ElasticitiesBrodaWeinstein72-88_SITCRev2_4-digit.dta"

mat drop _all
matrix A=J(3,8,.)
forvalues k=1(1)3{
sum sigma if a`k'==1, d
mat A[`k',1]=r(mean)
mat A[`k',2]=r(p50)
mat A[`k',3]=r(sd)
mat A[`k',4]=r(N)
sum sigma if a`k'!=1 & a4!=1 , d
mat A[`k',5]=r(mean)
mat A[`k',6]=r(p50)
mat A[`k',7]=r(sd)
mat A[`k',8]=r(N)
}
matlist A
/*
             |        c1         c2         c3         c4         c5         c6         c7         c8 
-------------+----------------------------------------------------------------------------------------
          r1 |    9.8507   3.508963   20.71326        184   5.596455    2.52695   13.24487        491 
          r2 |  8.954313   3.442322   19.39764        213   5.742683    2.52695   13.62839        462 
          r3 |  8.335152   3.389648   18.13416        248   5.839042    2.52695   14.09997        427 

We see that for both the median and the mean:
-sigma A is larger than sigma M
-sigma Ai decreases with i and sigma M increases with i for i=1,2,3*/

frmttable using "$pc\Table_A_sigmas7288_aux1", statmat(A) ///
rtitles("1" \ "2" \ "3") ctitles("" "mean" "median" "sd" "Obs." "mean" "median" "sd" "Obs.") ///
sdec(3,3,3,0,3,3,3,0) replace tex plain fragment nocenter hline(0100) spacebef(0100)
filefilter "$pc\Table_A_sigmas_aux1.tex" "$pc\Table_A_sigmas7288_aux2.tex", from ("\BSbegin{tabular}{lcccccccc}" ) to ("k & \BSmulticolumn{4}{c}{Ak}  & \BSmulticolumn{4}{c}{Mk} \BS\BS") replace
filefilter "$pc\Table_A_sigmas_aux2.tex" "$pc\Table_A_sigmas7288.tex", from ("\BSend{tabular}\BS\BS") to ("") replace
forvalues i=1(1)2{
rm "$pc\Table_A_sigmas7288_aux`i'.tex" //Table 3 in the text.
}

*Same using ByW's sigmas for the period 90-01
import excel "$path_in\SITC3 to SITC2 Conversion and Correlation Tables.xls", sheet("Conversion Table") cellrange(D8:F3128) clear
g sitc2_T4=substr(E,1,4)
g sitc3_T4=substr(D,1,4)
bys sitc3_T4: g aux=_n
destring sitc2_T4, replace
destring sitc3_T4, replace
keep if aux==1
count if sitc2_T4!=sitc3_T4
keep sitc2_T4 sitc3_T4
sort sitc3_T4
saveold "$path_out\eraseAux.dta", replace
import excel "$path_in\Broda-Weinstein (2006)\ElasticitiesBrodaWeinstein90-01_SITCRev3_4-digit.xls", sheet("Sheet1") cellrange(A4:B13979) firstrow clear
rename Sigma sigma
rename SITCRev34digit sitc3_T4
sort sitc3_T4
merge sitc3_T4 using "$path_out\eraseAux.dta"
drop _merge sitc3_T4
sort sitc2_T4
saveold "$path_in\Broda-Weinstein (2006)\ElasticitiesBrodaWeinstein90-01_SITCRev3_4-digit.dta", replace

rename sitc2 good
global class="SITCR2-4dDestring"
qui do "$path_do\A-Lists.do" // goods classification

replace a1=0 if a1==.
replace a2=0 if a2==.
replace a3=0 if a3==.
replace a4=0 if a4==.
qui label var a1 "Non-extractive A exports"
qui label var a2 "Non-extractive A exports (incl all kinds of fertilizers and organic chemicals)"
qui label var a3 "Non-extractive A exports (incl, besides A2, manuf products of A origin)"
qui label var a4 "Extractive exports"

mat drop _all
matrix A=J(3,8,.)
forvalues k=1(1)3{
sum sigma if a`k'==1, d
mat A[`k',1]=r(mean)
mat A[`k',2]=r(p50)
mat A[`k',3]=r(sd)
mat A[`k',4]=r(N)
sum sigma if a`k'!=1 & a4!=1 , d
mat A[`k',5]=r(mean)
mat A[`k',6]=r(p50)
mat A[`k',7]=r(sd)
mat A[`k',8]=r(N)
}
matlist A
/*

             |        c1         c2         c3         c4         c5         c6         c7         c8 
-------------+----------------------------------------------------------------------------------------
          r1 |  7.759409   3.176904   18.11646        227   5.129073   2.292018   12.78299        625 
          r2 |  7.159434   2.943266   17.18017        255   5.261978   2.334322   13.06141        597 
          r3 |  6.524989   2.785963    16.0484        364   5.311395   2.235244   13.09366        488 

We see that for both the median and the mean:
-sigma A is larger than sigma M
-sigma Ai decreases with i and sigma M increases with i for i=1,2,3*/
frmttable using "$pc\Table_A_sigmas9001_aux1", statmat(A) ///
rtitles("1" \ "2" \ "3") ctitles("" "mean" "median" "sd" "Obs." "mean" "median" "sd" "Obs.") ///
sdec(3,3,3,0,3,3,3,0) replace tex plain fragment nocenter hline(0100) spacebef(0100)
filefilter "$pc\Table_A_sigmas9001_aux1.tex" "$pc\Table_A_sigmas9001_aux2.tex", from ("\BSbegin{tabular}{lcccccccc}" ) to ("k & \BSmulticolumn{4}{c}{Ak}  & \BSmulticolumn{4}{c}{Mk} \BS\BS") replace
filefilter "$pc\Table_A_sigmas9001_aux2.tex" "$pc\Table_A_sigmas9001.tex", from ("\BSend{tabular}\BS\BS") to ("") replace
forvalues i=1(1)2{
rm "$pc\Table_A_sigmas9001_aux`i'.tex"
}

*7-Computes avg and median proximity by sector using proximity9800 by Hidalgo et al. (2007)
set matsize 1000
infile goodi goodj prox using "$pc\Desktop\data\Hidalgo-Hausmann\proximity9800.txt", clear
keep goodj
bys goodj: g n=_n
keep if n==1
set obs 775
replace goodj = 9710 in 775
sort goodj
drop n
g n=_n
sort n
saveold "$path_out/eraseProx.dta", replace

infile goodi goodj prox using "$pc\Desktop\data\Hidalgo-Hausmann\proximity9800.txt", clear
*there are 775 unique goods
reshape wide prox, i(goodi) j(goodj)
set obs 775
replace goodi = 11 in 775
replace prox11 = 1 in 775
sort goodi
g prox9710=.
replace prox9710=1 if _n==775
sort goodi
mkmat prox*, matrix(P)
forvalues y=1(1)775{
mat P[`y',`y']=1
}
local dim (`= rowsof(P)',`=colsof(P)')
di "`dim'"			//checking the matrix is 775x775
mata
P = st_matrix("P")	//transforms stata matrix P into a mata matrix
_makesymmetric(P)	//replaces matrix P by its symmetric version duplicating everything below the main diagonal above it
st_matrix("P", P)	//transforms mata matrix P back into a stata matrix
end
clear
svmat P, names(prox)
g n=_n
sort n
merge n using "$path_out/eraseProx.dta"
rename goodj good
drop _merge n
order good
forvalues y=1(1)775{
replace prox`y'=0 if prox`y'==.		//replacing all . for zeros
}
*Avg prox by good
egen meanp=rowmean(prox*)
egen medianp=rowmedian(prox*)

*Avg prox by sector
global class="SITCR2-4dDestring"
qui do "$path_do\A-Lists.do" // goods classification
replace a1=0 if a1==.
replace a2=0 if a2==.
replace a3=0 if a3==.
replace a4=0 if a4==.
forvalues o=1(1)3{
g m`o'=(a`o'!=1 & a4!=1)
replace m`o'=0 if m`o'==.
}

mat drop _all
matrix Q=J(3,6,.)
forvalues o=1(1)3{
sum meanp if a`o'==1
mat Q[`o',1]=r(mean)
mat Q[`o',2]=r(sd)
mat Q[`o',3]=r(N)
sum meanp if m`o'==1
mat Q[`o',4]=r(mean)
mat Q[`o',5]=r(sd)
mat Q[`o',6]=r(N)
}
frmttable using "$pc\Table_A_prox_aux1", statmat(Q) ///
rtitles("1" \ "2" \ "3") ctitles("" "mean" "sd" "Obs." "mean" "sd" "Obs.") ///
sdec(3,3,0,3,3,0) replace tex plain fragment nocenter hline(0100) spacebef(0100)
filefilter "$pc\Table_A_prox_aux1.tex" "$pc\Table_A_prox_aux2.tex", from ("\BSbegin{tabular}{lcccccc}" ) to ("k & \BSmulticolumn{3}{c}{Ak}  & \BSmulticolumn{3}{c}{Mk} \BS\BS") replace
filefilter "$pc\Table_A_prox_aux2.tex" "$pc\Table_A_prox.tex", from ("\BSend{tabular}\BS\BS") to ("") replace
forvalues i=1(1)2{
rm "$pc\Table_A_prox_aux`i'.tex"
} //Table A.3 in the text.

*compute also avg prox within A alone and within M alone.

infile goodi goodj prox using "$path_in\Hidalgo-Hausmann\proximity9800.txt", clear
*there are 775 unique goods
reshape wide prox, i(goodi) j(goodj)
set obs 775
replace goodi = 11 in 775
replace prox11 = 1 in 775
sort goodi
g prox9710=.
replace prox9710=1 if _n==775
sort goodi
global class="SITCR2-4dDestring"
qui do "$path_do\A-Lists.do" // goods classification
replace a1=0 if a1==.
replace a2=0 if a2==.
replace a3=0 if a3==.
replace a4=0 if a4==.
forvalues o=1(1)3{
g m`o'=(a`o'!=1 & a4!=1)
replace m`o'=0 if m`o'==.
}

mat drop _all
matrix QW=J(3,6,.)
foreach k in m a{
forvalues i=1(1)3{
	preserve

	keep if `k'`i'==1 //delete all rows that don't belong to the group: the group is well defined in rows but not columns
	mkmat prox*, matrix(P1)
	mata: P1 = st_matrix("P1")
	mata: P1p=P1'		//the group is now well defined in columns but not rows
	mata: st_matrix("P1p", P1p)
	clear
	svmat P1p, names(prox)
	g n=_n
	sort n
	merge n using "$path_out/eraseProx.dta"
	drop n _merge
	sort good
global class="SITCR2-4dDestring"
qui do "$path_do\A-Lists.do" // goods classification
	replace a1=0 if a1==.
	replace a2=0 if a2==.
	replace a3=0 if a3==.
	replace a4=0 if a4==.
	forvalues o=1(1)3{
		g m`o'=(a`o'!=1 & a4!=1)
		replace m`o'=0 if m`o'==.
	}
	keep if `k'`i'==1 //the group is now well defined in columns AND rows

	mkmat prox*, matrix(P1)
	mata: P1 = st_matrix("P1")	//transforms stata matrix P into a mata matrix
	mata: P1=P1'				//traspose so everything above the diagonal goes below it
	mata: _makesymmetric(P1)	//replaces matrix P by its symmetric version duplicating everything below the main diagonal above it
	mata: st_matrix("P1", P1)	//transforms mata matrix P back into a stata matrix
	local N=_N
	forvalues y=1(1)`N'{
		mat P1[`y',`y']=1
	}
	clear
	svmat P1, names(prox)
	forvalues y=1(1)`N'{
		replace prox`y'=0 if prox`y'==.		//replacing all . for zeros
	}

	egen meanp=rowmean(prox*)
	egen medianp=rowmedian(prox*)
	sum meanp
	if ("`k'"=="a") mat QW[`i',1]=r(mean)
	if ("`k'"=="a") mat QW[`i',2]=r(sd)
	if ("`k'"=="a") mat QW[`i',3]=`N'	
	if ("`k'"=="m")  mat QW[`i',4]=r(mean)
	if ("`k'"=="m")  mat QW[`i',5]=r(sd)
	if ("`k'"=="m")  mat QW[`i',6]=`N'	
	restore
}
}
frmttable using "$pc\Table_A_proxW_aux1", statmat(QW) ///
rtitles("1" \ "2" \ "3") ctitles("" "mean" "sd" "Obs." "mean" "sd" "Obs.") ///
sdec(3,3,0,3,3,0) replace tex plain fragment nocenter hline(0100) spacebef(0100)
filefilter "$pc\Table_A_proxW_aux1.tex" "$pc\Table_A_proxW_aux2.tex", from ("\BSbegin{tabular}{lcccccc}" ) to ("k & \BSmulticolumn{3}{c}{Ak}  & \BSmulticolumn{3}{c}{Mk} \BS\BS") replace
filefilter "$pc\Table_A_proxW_aux2.tex" "$pc\\Table_A_proxW.tex", from ("\BSend{tabular}\BS\BS") to ("") replace
forvalues i=1(1)2{
rm "$pc\Table_A_proxW_aux`i'.tex" //Table 4 in the text
}

erase "$path_out/eraseProx.dta"
