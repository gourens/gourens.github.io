/**********
*3.PRODUCTS
***********
This do-file:
1-Gives a dataset with 10-year growth rates of A and M at 4-digits (Products1.dta). We find that:
-gA<gM

2-I show the same thing with BACI92 at 6-digits for the period 1995-2007 (same result!)

3-I show the same thing with SITCRev1 5-digits for the period 1962-2014.

4-I show the same thing with BACI02 at 6-digits for the period 2003-2012 (the result is slightly weaker, but still there!)

5-I show the same thing but averaging 2-digit g's (using 4d, 5d and 6d datasets)

6-I show the same thing but counting varieties (i.e. pairs product-origin) for the whole world at both 4 and 6 digits

7-I show the same thing but using production instead of exports (i.e. counting firms for countries in the EU)

8-computes the average occupation of bins within A and within M. 

9-*9-I show that changes in TT are correlated positively to changes in nX and negatively to changes in nM
*/
version 8


*********
*1
*********

forvalues p=62(1)100 {
qui {
if "`p'"!="100" local x="`p'"
if "`p'"=="100" local x="00"
if "`p'"!="100" local y="19`p'"
if "`p'"=="100" local y="2000"
u "$pc\data\Trade\Feenstra\wtf`x'.dta", clear
keep if importer=="World"
bys exporter sitc4: g n=_n
keep if n==1
bys exporter: g a0=_n
bys exporter: egen x=max(a0)
rename sitc4 good
label var x "# of products exported"
global class="SITCR2-4d"
qui do "$path_do\A-Lists.do" // goods classification
	
forvalues o=1(1)4{
	bys exporter: egen x`o'=sum(a`o')
	label var x`o' "# of A`o' products exported"
}
label var x4 "# of E products exported"
forvalues o=1(1)3{
	g M`o'=x-x`o'-x4
	label var M`o' "# of M`o' products exported"
}
rename exporter country_feenstra
sort country_feenstra
merge country_feenstra using "$pc/country compatibility.dta"	// ads isocodes
keep if _merge==3
rename country_isocode country
bys country: g aux3=_n
keep if aux3==1
keep country year x* M*
keep if country!=""
order country year
}
saveold "$path_out\erase7_`y'.dta", replace
}

forvalues y=2001(1)2014 {
import delimited "$pc\data\Trade\SITCR2_5d\type-C_r-ALL_ps-`y'.csv", clear
keep if tradeflow=="Export"
keep if agg==4
rename commoditycode good
rename reporteriso country
drop if country=="" | good=="TOTAL"
bys country good: g n=_n
keep if n==1
bys country: g a0=_n
bys country: egen x=max(a0)
label var x "# of products exported"
global class="SITCR2-4d"
qui do "$path_do\A-Lists.do" // goods classification
forvalues o=1(1)4{
	bys country: egen x`o'=sum(a`o')
	label var x`o' "# of A`o' products exported"
}
label var x4 "# of E products exported"
forvalues o=1(1)3{
	g M`o'=x-x`o'-x4
	label var M`o' "# of M`o' products exported"
}
bys country: g aux3=_n
keep if aux3==1
keep country year x* M*
keep if country!=""
order country year
saveold "$path_out\erase7_`y'.dta", replace
}

forvalues y=1962(1)2014{
	qui if ("`y'"=="1962") u "$path_out/erase7_`y'.dta", clear
	qui if ("`y'"!="1962") append using "$path_out/erase7_`y'.dta"
	qui erase "$path_out\erase7_`y'.dta"
}

sort country year
forvalues o=1(1)3{
	bys country: g gA`o'=(x`o'[_n+9]-x`o')/x`o'
	label var gA`o' "10yr growth rate of A`o' products exported"
	bys country: g gM`o'=(M`o'[_n+9]-M`o')/M`o'
	label var gM`o' "10yr growth rate of M`o' products exported"
}
sort country year
saveold "$path_out\Products1.dta", replace


*Graphs and first part of the Table I use (matrices are ensambled togehter with section 8 and 9, so to get the table we need to run them all)
mat drop _all
matrix A=J(8,9,.)
matrix B=J(8,9,.)
forvalues j=1(1)3{
twoway (scatter gM`j' gA`j' if gM`j'<7 & gA`j'<7 & (year==1962 | year==1972 | year==1982 | year==1991), mc(black)) ///
(function y=x,  range(-2 8) lw(medium) lp(dash) lc(gs5)), ///
xtitle("gA") ytitle("gM") legend(off) xscale(r(0 8)) xtick(0(2)8) ///
graphr(color(white) ilcolor(white) fcolor(white) ifcolor(white) margin(medium)) ///
plotr(icolor(white) ilcolor(white) fcolor(white) ifcolor(white) margin(small))
graph2tex, epsfile("$pc\\Figure_P_4d_`j'") //Figure 2 in the text.
ttest gM`j' == gA`j' if year==1962 | year==1972  | year==1982  | year==1990
mat A[1,`j']=r(mu_1)
mat A[2,`j']=r(sd_1)
mat A[3,`j']=r(mu_2)
mat A[4,`j']=r(sd_2)
mat A[5,`j']=r(N_1)
mat A[6,`j']=r(p_l) 
mat A[7,`j']=r(p)
mat A[8,`j']=r(p_u)
ttest gM`j' == gA`j'  if year==1962 | year==1972  | year==1982  | year==1990 & gM`j'<7 & gA`j'<7
mat B[1,`j']=r(mu_1)
mat B[2,`j']=r(sd_1)
mat B[3,`j']=r(mu_2)
mat B[4,`j']=r(sd_2)
mat B[5,`j']=r(N_1)
mat B[6,`j']=r(p_l) 
mat B[7,`j']=r(p)
mat B[8,`j']=r(p_u)
}

*********
*2-I show the same thing with BACI92 at 6-digits for the period 1995-2007
*********

forvalues y=1995(1)2007 {
if (`y'==1995) u "$pc\data\Trade\BACI\baci92\baci92_`y'.dta", clear
if (`y'!=1995) append using "$pc\data\Trade\BACI\baci92\baci92_`y'.dta"
}
capture destring hs6 i j, replace
global class="HS0-6d"
qui do "$path_do\A-Lists.do" // goods classification
	
bys t hs6 i: g n=_n
keep if n==1
drop n q v j

bys t i: egen x=count(hs6)

forvalues o=1(1)4{
	bys t i: egen A`o'=sum(a`o')
	label var A`o' "# of A`o' products exported"
}
label var A4 "# of E products exported"

forvalues o=1(1)3{
	g M`o'=x-A`o'-A4
	label var M`o' "# of M`o' products exported"
}

bys t i: g n=_n
keep if n==1
drop n hs6 a*

forvalues o=1(1)3{
	g aux`o'1=A`o' if t==1995
	bys i: egen A`o'95=mean(aux`o'1)
	g aux`o'2=A`o' if t==2007
	bys i: egen A`o'07=mean(aux`o'2)
	g gA`o'=(A`o'07-A`o'95)/A`o'95
	
	g maux`o'1=M`o' if t==1995
	bys i: egen M`o'95=mean(maux`o'1)
	g maux`o'2=M`o' if t==2007
	bys i: egen M`o'07=mean(maux`o'2)
	g gM`o'=(M`o'07-M`o'95)/M`o'95
}
keep if t==1995
drop aux* maux* A* M* x t
drop if gA1==.
sort i
saveold "$path_out\Products2.dta", replace
 
*Graphs with six-digits and completing Table started in section 7 (and finishing in section 9)
forvalues j=1(1)3{
local i=`j'+6
twoway (scatter gM`j' gA`j' if gM`j'<7 & gA`j'<7 , mc(black)) ///
(function y=x,  range(-2 8) lw(medium) lp(dash) lc(gs5)), ///
xtitle("gA") ytitle("gM") legend(off) xscale(r(0 8)) xtick(0(2)8) ///
graphr(color(white) ilcolor(white) fcolor(white) ifcolor(white) margin(medium)) ///
plotr(icolor(white) ilcolor(white) fcolor(white) ifcolor(white) margin(small))
graph2tex, epsfile("$pc\Figure_P_6d_`j'") //Figure 2 in the text.
ttest gM`j' == gA`j'
mat A[1,`i']=r(mu_1)
mat A[2,`i']=r(sd_1)
mat A[3,`i']=r(mu_2)
mat A[4,`i']=r(sd_2)
mat A[5,`i']=r(N_1)
mat A[6,`i']=r(p_l) 
mat A[7,`i']=r(p)
mat A[8,`i']=r(p_u)
ttest gM`j' == gA`j' if gM`j'<7 & gA`j'<7
mat B[1,`i']=r(mu_1)
mat B[2,`i']=r(sd_1)
mat B[3,`i']=r(mu_2)
mat B[4,`i']=r(sd_2)
mat B[5,`i']=r(N_1)
mat B[6,`i']=r(p_l) 
mat B[7,`i']=r(p)
mat B[8,`i']=r(p_u)
}

*********
*3-I show the same thing with SITCRev1 5-digits for the period 1962-2014
*********

forvalues y=1962(1)2014{
import delimited "$pc\SITCR1_5d\type-C_r-ALL_ps-`y'.csv", clear
keep if isleafcode==1		//this keeps 5-digit goods (or 4-digits if there is no further disaggregation after 4-d)
keep if tradeflow=="Export"
keep if partner=="World"
rename commoditycode good
rename reporteriso i
drop if i==""
drop if good=="TOTAL"
destring good, replace
replace good=good*10 if aggregatelevel==4
keep year i good

global class="SITCR1-5d"
qui do "$path_do\A-Lists.do" // goods classification

bys year i: egen x=count(good)

forvalues o=1(1)4{
	bys i: egen x`o'=sum(a`o')
	label var x`o' "# of A`o' products exported"
}
label var x4 "# of E products exported"
forvalues o=1(1)3{
	g M`o'=x-x`o'-x4
	label var M`o' "# of M`o' products exported"
}
bys i: g aux3=_n
keep if aux3==1
keep i year x* M*
keep if i!=""
order i year
saveold "$pc\output\erase_`y'.dta", replace
}

forvalues y=1962(1)2014 {
qui if ("`y'"=="1962") u "$pc\output\erase_`y'.dta", clear
qui if ("`y'"!="1962") append using "$pc\output\erase_`y'.dta"
qui erase "$pc\output\erase_`y'.dta"
}

sort i year
forvalues o=1(1)3{
	bys i: g gA`o'=(x`o'[_n+9]-x`o')/x`o'
	label var gA`o' "10yr growth rate of A`o' products exported"
	bys i: g gM`o'=(M`o'[_n+9]-M`o')/M`o'
	label var gM`o' "10yr growth rate of M`o' products exported"
}
sort i year
saveold "$path_out\Products3.dta", replace

forvalues j=1(1)3{
local i=`j'+3
twoway (scatter gM`j' gA`j' if gM`j'<30 & gA`j'<30, mc(black)) ///
(function y=x,  range(-2 30) lw(medium) lp(dash) lc(gs5)), ///
xtitle("gA") ytitle("gM") legend(off) xscale(r(0 8)) xtick(0(2)8) ///
graphr(color(white) ilcolor(white) fcolor(white) ifcolor(white) margin(medium)) ///
plotr(icolor(white) ilcolor(white) fcolor(white) ifcolor(white) margin(small))
graph2tex, epsfile("$pc\Figure_P_5d_`j'") //Figure 2 in the text.
ttest gM`j' == gA`j'
mat A[1,`i']=r(mu_1)
mat A[2,`i']=r(sd_1)
mat A[3,`i']=r(mu_2)
mat A[4,`i']=r(sd_2)
mat A[5,`i']=r(N_1)
mat A[6,`i']=r(p_l) 
mat A[7,`i']=r(p)
mat A[8,`i']=r(p_u)
ttest gM`j' == gA`j' if gM`j'<7 & gA`j'<7
mat B[1,`i']=r(mu_1)
mat B[2,`i']=r(sd_1)
mat B[3,`i']=r(mu_2)
mat B[4,`i']=r(sd_2)
mat B[5,`i']=r(N_1)
mat B[6,`i']=r(p_l) 
mat B[7,`i']=r(p)
mat B[8,`i']=r(p_u)
}

*Table without outliers
frmttable using "$pc\Table_P_gMgA_aux1", statmat(B) ///
rtitles("mean(gM)" \ "sd(gM)" \ "mean(gA)" \ "sd(gA)" \ "Obs." \ "\$ Ha:gM<gA$" \ "\$ Ha:gM \neq gA$" \ "\$ Ha:gM>gA$") ///
ctitles("\$ gMk=gAk$" "\$ k=1$" "\$ k=2$" "\$ k=3$" "\$ k=1$" "\$ k=2$" "\$ k=3$" "\$ k=1$" "\$ k=2$" "\$ k=3$") ///
sdec(3\3\3\3\0\3\3\3) replace tex ///
plain fragment nocenter hline(010000100) spacebef(010000000)
filefilter "$pc\Table_P_gMgA_aux1.tex" "$pc\Table_P_gMgA_aux2.tex", from ("\BSbegin{tabular}{lccccccccc}" ) to ("& \BSmulticolumn{3}{c}{4-digits} & \BSmulticolumn{3}{c}{5-digits} & \BSmulticolumn{3}{c}{6-digits} \BS\BS") replace
filefilter "$pc\Table_P_gMgA_aux2.tex" "$pc\Table_P_gMgA.tex", from ("\BSend{tabular}\BS\BS") to ("") replace
forvalues i=1(1)2{
rm "$pc\Table_P_gMgA_aux`i'.tex"
} //Table 1 and A.4 in the text.

*Table with all obs
frmttable using "$pc\Table_P_gMgA_aux1", statmat(A) ///
rtitles("mean(gM)" \ "sd(gM)" \ "mean(gA)" \ "sd(gA)" \ "Obs."\ "\$ Ha:gM<gA$"  \ "\$ Ha:gM \neq gA$" \ "\$ Ha:gM>gA$") ///
ctitles("\$ gMk=gAk$" "\$ k=1$" "\$ k=2$" "\$ k=3$" "\$ k=1$" "\$ k=2$" "\$ k=3$" "\$ k=1$" "\$ k=2$" "\$ k=3$") ///
sdec(3\3\3\3\0\3\3\3) replace tex ///
plain fragment nocenter hline(010000100) spacebef(010000000)
filefilter "$pc\Table_P_gMgA_aux1.tex" "$pc\Table_P_gMgA_aux2.tex", from ("\BSbegin{tabular}{lccccccccc}" ) to ("& \BSmulticolumn{3}{c}{4-digits} & \BSmulticolumn{3}{c}{5-digits} & \BSmulticolumn{3}{c}{6-digits} \BS\BS") replace
filefilter "$pc\Table_P_gMgA_aux2.tex" "$pc\Table_P_gMgA2.tex", from ("\BSend{tabular}\BS\BS") to ("") replace
forvalues i=1(1)2{
rm "$pc\Table_P_gMgA_aux`i'.tex"
}

*Test whether this holds at any moment in time (it does)
forvalues j=1(1)3{
forvalues y=1962(5)2002{
di in red `j'_`y'
ttest gM`j' == gA`j' if year==`y'
}
}

*****
*4-I show the same thing with BACI02 at 6-digits for the period 2003-2012
*****

u "$pc\data\Trade\BACI\baci02\baci02_0312.dta", clear

global class="HS0-6d"
qui do "$path_do\A-Lists.do" // goods classification
	
bys t hs6 i: g n=_n
keep if n==1
drop n q v j

bys t i: egen x=count(hs6)

forvalues o=1(1)4{
	bys t i: egen A`o'=sum(a`o')
	label var A`o' "# of A`o' products exported"
}
label var A4 "# of E products exported"

forvalues o=1(1)3{
	g M`o'=x-A`o'-A4
	label var M`o' "# of M`o' products exported"
}

bys t i: g n=_n
keep if n==1
drop n hs6 a*

forvalues o=1(1)3{
	g aux`o'1=A`o' if t==2003
	bys i: egen A`o'03=mean(aux`o'1)
	g aux`o'2=A`o' if t==2012
	bys i: egen A`o'12=mean(aux`o'2)
	g gA`o'=(A`o'12-A`o'03)/A`o'03
	
	g maux`o'1=M`o' if t==2003
	bys i: egen M`o'03=mean(maux`o'1)
	g maux`o'2=M`o' if t==2012
	bys i: egen M`o'12=mean(maux`o'2)
	g gM`o'=(M`o'12-M`o'03)/M`o'03
}
keep if t==2003
drop aux* maux* A* M* x t
drop if gA1==.

ttest gM1 == gA1
/*Paired t test
------------------------------------------------------------------------------
Variable |     Obs        Mean    Std. Err.   Std. Dev.   [95% Conf. Interval]
---------+--------------------------------------------------------------------
     gM1 |     228    .5075563    .0654605    .9884324    .3785683    .6365443
     gA1 |     228    .3824412    .0680965    1.028234    .2482591    .5166232
---------+--------------------------------------------------------------------
    diff |     228    .1251151    .0658585    .9944413    -.004657    .2548873
------------------------------------------------------------------------------
     mean(diff) = mean(gM1 - gA1)                                 t =   1.8998
 Ho: mean(diff) = 0                              degrees of freedom =      227

 Ha: mean(diff) < 0           Ha: mean(diff) != 0           Ha: mean(diff) > 0
 Pr(T < t) = 0.9706         Pr(|T| > |t|) = 0.0587          Pr(T > t) = 0.0294*/

ttest gM2 == gA2
/*Paired t test
------------------------------------------------------------------------------
Variable |     Obs        Mean    Std. Err.   Std. Dev.   [95% Conf. Interval]
---------+--------------------------------------------------------------------
     gM2 |     228    .5045819    .0662141    .9998114     .374109    .6350548
     gA2 |     228    .3915521    .0616762    .9312897    .2700211    .5130831
---------+--------------------------------------------------------------------
    diff |     228    .1130298     .056463    .8525726    .0017712    .2242884
------------------------------------------------------------------------------
     mean(diff) = mean(gM2 - gA2)                                 t =   2.0018
 Ho: mean(diff) = 0                              degrees of freedom =      227

 Ha: mean(diff) < 0           Ha: mean(diff) != 0           Ha: mean(diff) > 0
 Pr(T < t) = 0.9768         Pr(|T| > |t|) = 0.0465          Pr(T > t) = 0.0232*/

ttest gM3 == gA3
/*Paired t test
------------------------------------------------------------------------------
Variable |     Obs        Mean    Std. Err.   Std. Dev.   [95% Conf. Interval]
---------+--------------------------------------------------------------------
     gM3 |     228    .5130232    .0645851    .9752131    .3857603    .6402861
     gA3 |     228    .4070785    .0677176    1.022514     .273643     .540514
---------+--------------------------------------------------------------------
    diff |     228    .1059447    .0522186    .7884843    .0030495      .20884
------------------------------------------------------------------------------
     mean(diff) = mean(gM3 - gA3)                                 t =   2.0289
 Ho: mean(diff) = 0                              degrees of freedom =      227

 Ha: mean(diff) < 0           Ha: mean(diff) != 0           Ha: mean(diff) > 0
 Pr(T < t) = 0.9782         Pr(|T| > |t|) = 0.0436          Pr(T > t) = 0.0218*/


twoway (scatter gM2 gA2, mc(black)) ///
(function y=x,  range(-2 8) lw(medium) lp(dash) lc(gs5)), ///
xtitle("gA") ytitle("gM") legend(off) xscale(r(0 8)) xtick(0(2)8) ///
graphr(color(white) ilcolor(white) fcolor(white) ifcolor(white) margin(medium)) ///
plotr(icolor(white) ilcolor(white) fcolor(white) ifcolor(white) margin(small))

*****
*5-I show the same thing but averaging 2-digit g's
*****
*5.1 At 4-digits

forvalues p=62(1)100 {
qui {
if "`p'"!="100" local x="`p'"
if "`p'"=="100" local x="00"
if "`p'"!="100" local y="19`p'"
if "`p'"=="100" local y="2000"
u "$pc\data\Trade\Feenstra\wtf`x'.dta", clear
keep if importer=="World"
bys exporter sitc4: g n=_n
keep if n==1
rename sitc4 good
global class="SITCR2-4d"
qui do "$path_do\A-Lists.do" // goods classification	

bys exporter aux1: g aux0=_n
bys exporter aux1: egen x=max(aux0)
label var x "# of products exported of each 2-d good"
qui keep if aux0==1
keep if exporter!=""
rename exporter country_feenstra
sort country_feenstra
merge country_feenstra using "$pc/country compatibility.dta"	// ads isocodes
keep if _merge==3
rename country_isocode country
keep country year x aux1 a1 a2 a3 a4
order country year
}
saveold "$path_out\erase10_`y'.dta", replace
}

forvalues y=1962(1)2000{
	qui if ("`y'"=="1962") u "$path_out/erase10_`y'.dta", clear
	qui if ("`y'"!="1962") append using "$path_out/erase10_`y'.dta"
	qui erase "$path_out/erase10_`y'.dta"
}

forvalues i=1962(10)1992 {
local j=`i'-1
g ax`i'=x if year==`i'
g ax`j'=x if year==`j'
bys country aux1: egen x`i'=mean(ax`i')
bys country aux1: egen x`j'=mean(ax`j')
}
g ax2000=x if year==2000
bys country aux1: egen x2000=mean(ax2000)

g g1962=(x1971-x1962)/x1962		//diversification rate for any product-country
g g1972=(x1981-x1972)/x1972
g g1982=(x1991-x1982)/x1982
g g1991=(x2000-x1991)/x1991

by country aux1: g n=_n
keep if n==1
drop n ax* x* year

forvalues i=1(1)4 {
forvalues j=1962(10)1982 {
bys country: egen auxA`i'`j'=mean(g`j') if a`i'==1
bys country: egen auxM`i'`j'=mean(g`j') if a`i'==. & a4==.
bys country: egen gA`i'`j'=mean(auxA`i'`j')
bys country: egen gM`i'`j'=mean(auxM`i'`j')
}
bys country: egen auxA`i'1991=mean(g1991) if a`i'==1
bys country: egen auxM`i'1991=mean(g1991) if a`i'==. & a4==.
bys country: egen gA`i'1991=mean(auxA`i'1991)
bys country: egen gM`i'1991=mean(auxM`i'1991)
}
by country: g n=_n
keep if n==1
drop n a* g1962 g1972 g1982 g1991
drop if country==""

forvalues i=1(1)3 {
preserve
keep country gA`i'*
reshape long gA`i', i(country) j(year)
sort country year
saveold "$path_out\erase10_A`i'.dta", replace
restore
preserve
keep country gM`i'*
reshape long gM`i', i(country) j(year)
sort country year
saveold "$path_out\erase10_M`i'.dta", replace
restore
}

u "$path_out\erase10_A1.dta", clear
forvalues i=1(1)3 {
merge country year using "$path_out\erase10_A`i'.dta"
drop _merge
sort country year
merge country year using "$path_out\erase10_M`i'.dta"
drop _merge
erase "$path_out\erase10_A`i'.dta"
erase "$path_out\erase10_M`i'.dta"
sort country year
}

sort country year
saveold "$path_out\Ex4d2d.dta", replace

mat drop _all
matrix A=J(8,9,.)
forvalues j=1(1)3{
twoway (scatter gM`j' gA`j' if gM`j'<7 & gA`j'<7 & (year==1962 | year==1972 | year==1982  | year==1991), mc(black)) ///
(function y=x,  range(-2 8) lw(medium) lp(dash) lc(gs5)), ///
xtitle("gA") ytitle("gM") legend(off) xscale(r(0 8)) xtick(0(2)8) ///
graphr(color(white) ilcolor(white) fcolor(white) ifcolor(white) margin(medium)) ///
plotr(icolor(white) ilcolor(white) fcolor(white) ifcolor(white) margin(small))
graph2tex, epsfile("$pc\\Figure_P_4d2d_`j'")
ttest gM`j' == gA`j' if year==1962 | year==1972  | year==1982  | year==1991
mat A[1,`j']=r(mu_1)
mat A[2,`j']=r(sd_1)
mat A[3,`j']=r(mu_2)
mat A[4,`j']=r(sd_2)
mat A[5,`j']=r(N_1)
mat A[6,`j']=r(p_l) 
mat A[7,`j']=r(p)
mat A[8,`j']=r(p_u)
}

*5.2 At 5-digits

forvalues y=1962(1)2012 {
import delimited "$pc\SITCR1_5d\type-C_r-ALL_ps-`y'.csv", clear
keep if isleafcode==1		//this keeps 5-digit goods (or 4-digits if there is no further disaggregation after 4-d)
keep if tradeflow=="Export"
keep if partner=="World"
rename commoditycode good
rename reporteriso country
drop if country=="" | good=="TOTAL"
qui g aux1= substr(good,1,2)
destring good, replace
replace good=good*10 if aggregatelevel==4
global class="SITCR1-5d"
qui do "$path_do\A-Lists.do" // goods classification
bys country aux1: g aux0=_n
bys country aux1: egen x=max(aux0)
label var x "# of products exported of each 2-d good"
qui keep if aux0==1
keep if country!=""
keep country year x aux1 a1 a2 a3 a4
order country year aux1
saveold "$path_out\erase11_`y'.dta", replace
}

forvalues y=1962(1)2012{
	qui if ("`y'"=="1962") u "$path_out/erase11_`y'.dta", clear
	qui if ("`y'"!="1962") append using "$path_out/erase11_`y'.dta"
	qui erase "$path_out\erase11_`y'.dta"
}

forvalues i=1962(10)2012 {
local j=`i'-1
g ax`i'=x if year==`i'
g ax`j'=x if year==`j'
bys country aux1: egen x`i'=mean(ax`i')
bys country aux1: egen x`j'=mean(ax`j')
}
g g1962=(x1971-x1962)/x1962		//diversification rate for any product-country
g g1972=(x1981-x1972)/x1972
g g1982=(x1991-x1982)/x1982
g g1992=(x2001-x1992)/x1992
g g2002=(x2011-x2002)/x2002

by country aux1: g n=_n
keep if n==1
drop n ax* x* year

forvalues i=1(1)4 {
forvalues j=1962(10)2002 {
bys country: egen auxA`i'`j'=mean(g`j') if a`i'==1
bys country: egen auxM`i'`j'=mean(g`j') if a`i'==. & a4==.
bys country: egen gA`i'`j'=mean(auxA`i'`j')
bys country: egen gM`i'`j'=mean(auxM`i'`j')
}
}
by country: g n=_n
keep if n==1
drop n a* g1962 g1972 g1982 g1992 g2002
drop if country==""

forvalues i=1(1)3 {
preserve
keep country gA`i'*
reshape long gA`i', i(country) j(year)
sort country year
saveold "$path_out\erase11_A`i'.dta", replace
restore
preserve
keep country gM`i'*
reshape long gM`i', i(country) j(year)
sort country year
saveold "$path_out\erase11_M`i'.dta", replace
restore
}

u "$path_out\erase11_A1.dta", clear
forvalues i=1(1)3 {
merge country year using "$path_out\erase11_A`i'.dta"
drop _merge
sort country year
merge country year using "$path_out\erase11_M`i'.dta"
drop _merge
erase "$path_out\erase11_A`i'.dta"
erase "$path_out\erase11_M`i'.dta"
sort country year
}

sort country year
saveold "$path_out\Ex5d2d.dta", replace

forvalues j=1(1)3{
local i=`j'+3
twoway (scatter gM`j' gA`j' if year==1962 | year==1972 | year==1982  | year==1990, mc(black)) ///
(function y=x,  range(-2 8) lw(medium) lp(dash) lc(gs5)), ///
xtitle("gA") ytitle("gM") legend(off) xscale(r(0 8)) xtick(0(2)8) ///
graphr(color(white) ilcolor(white) fcolor(white) ifcolor(white) margin(medium)) ///
plotr(icolor(white) ilcolor(white) fcolor(white) ifcolor(white) margin(small))
graph2tex, epsfile("$pc\Figure_P_5d2d_`j'")
ttest gM`j' == gA`j' if year==1962 | year==1972 | year==1982 | year==1992 | year==2002
mat A[1,`i']=r(mu_1)
mat A[2,`i']=r(sd_1)
mat A[3,`i']=r(mu_2)
mat A[4,`i']=r(sd_2)
mat A[5,`i']=r(N_1)
mat A[6,`i']=r(p_l) 
mat A[7,`i']=r(p)
mat A[8,`i']=r(p_u)
}

*5.3 At 6-digits

forvalues y=1995(1)2007 {
if (`y'==1995) u "$pc\data\Trade\BACI\baci92\baci92_`y'.dta", clear
if (`y'!=1995) append using "$pc\data\Trade\BACI\baci92\baci92_`y'.dta"
}
qui g aux1= substr(hs6,1,2)
capture destring hs6 i j, replace
global class="HS0-6d"
qui do "$path_do\A-Lists.do" // goods classification
rename i country
rename t year
bys country aux1 year: g aux0=_n
bys country aux1 year: egen x=max(aux0)
label var x "# of products exported of each 2-d good"
qui keep if aux0==1
keep if country!=.
forvalues i=1994(1)2007 {
g ax`i'=x if year==`i'
bys country aux1: egen x`i'=mean(ax`i')
}
forvalues i=1995(1)1998 {
local k=`i'+9
g g`i'=(x`k'-x`i')/x`i' 		//diversification rate for any product-country
}
bys country aux1: g n=_n
keep if n==1
drop n ax* x* year

forvalues i=1(1)4 {
forvalues j=1995(1)1998 {
bys country: egen auxA`i'`j'=mean(g`j') if a`i'==1
bys country: egen auxM`i'`j'=mean(g`j') if a`i'==. & a4==.
bys country: egen gA`i'`j'=mean(auxA`i'`j')
bys country: egen gM`i'`j'=mean(auxM`i'`j')
}
}
by country: g n=_n
keep if n==1
drop n a* g1995 g1996 g1997 g1998
drop if country==.
forvalues i=1(1)3 {
preserve
keep country gA`i'*
reshape long gA`i', i(country) j(year)
sort country year
saveold "$path_out\erase12_A`i'.dta", replace
restore
preserve
keep country gM`i'*
reshape long gM`i', i(country) j(year)
sort country year
saveold "$path_out\erase12_M`i'.dta", replace
restore
}
u "$path_out\erase12_A1.dta", clear
forvalues i=1(1)3 {
merge country year using "$path_out\erase12_A`i'.dta"
drop _merge
sort country year
merge country year using "$path_out\erase12_M`i'.dta"
drop _merge
sort country year
erase "$path_out\erase12_A`i'.dta"
erase "$path_out\erase12_M`i'.dta"
}

sort country year
saveold "$path_out\Ex6d2d.dta", replace

forvalues j=1(1)3{
local i=`j'+6
twoway (scatter gM`j' gA`j' if gM`j'<20 & gA`j'<20, mc(black)) ///
(function y=x,  range(-2 8) lw(medium) lp(dash) lc(gs5)), ///
xtitle("gA") ytitle("gM") legend(off) xscale(r(0 8)) xtick(0(2)8) ///
graphr(color(white) ilcolor(white) fcolor(white) ifcolor(white) margin(medium)) ///
plotr(icolor(white) ilcolor(white) fcolor(white) ifcolor(white) margin(small))
graph2tex, epsfile("$pc\Figure_P_6d2d_`j'")
ttest gM`j' == gA`j'
mat A[1,`i']=r(mu_1)
mat A[2,`i']=r(sd_1)
mat A[3,`i']=r(mu_2)
mat A[4,`i']=r(sd_2)
mat A[5,`i']=r(N_1)
mat A[6,`i']=r(p_l) 
mat A[7,`i']=r(p)
mat A[8,`i']=r(p_u)
}
frmttable using "$pc\Table_P_gMgA_2d_aux1", statmat(A) ///
rtitles("mean(gM)" \ "sd(gM)" \ "mean(gA)" \ "sd(gA)" \ "Obs." \ "\$ Ha:gM<gA$" \ "\$ Ha:gM \neq gA$" \ "\$ Ha:gM>gA$") ///
ctitles("\$ gMk=gAk$" "\$ k=1$" "\$ k=2$" "\$ k=3$" "\$ k=1$" "\$ k=2$" "\$ k=3$" "\$ k=1$" "\$ k=2$" "\$ k=3$") ///
sdec(3\3\3\3\0\3\3\3) replace tex ///
plain fragment nocenter hline(010000100) spacebef(010000000)
filefilter "$pc\Table_P_gMgA_2d_aux1.tex" "$pc\Table_P_gMgA_2d_aux2.tex", from ("\BSbegin{tabular}{lccccccccc}" ) to ("& \BSmulticolumn{3}{c}{4-digits} & \BSmulticolumn{3}{c}{5-digits} & \BSmulticolumn{3}{c}{6-digits} \BS\BS") replace
filefilter "$pc\Table_P_gMgA_2d_aux2.tex" "$pc\Table_P_gMgA_2d.tex", from ("\BSend{tabular}\BS\BS") to ("") replace
forvalues i=1(1)2{
rm "$pc\Table_P_gMgA_2d_aux`i'.tex"
} // Table 2 and A.6 in the text.

*erase "$path_out\Ex4d2d.dta"
*erase "$path_out\Ex5d2d.dta"
*erase "$path_out\Ex6d2d.dta"

*6-I show the same thing but counting varieties (i.e. pairs product-origin) for the whole world at both 4 and 6 digits

*6.1 At 4-digit
forvalues p=62(1)100 {
qui if "`p'"!="100" local x="`p'"
qui if "`p'"=="100" local x="00"
qui if "`p'"!="100" local y="19`p'"
qui if "`p'"=="100" local y="2000"
qui u "$pc\data\Trade\Feenstra\wtf`x'.dta", clear
qui drop if exporter=="World"
qui keep if importer=="World"
bys importer sitc4: g n=_n
keep if n==1
rename sitc4 good
global class="SITCR2-4d"
qui do "$path_do\A-Lists.do" // goods classification

egen nTOT=count(year)
forvalues o=1(1)4{
g m`o'=1 if a`o'!=1 & a4!=1
egen nA`o'=sum(a`o')
egen nM`o'=sum(m`o')
}
keep year n*
keep if _n==1
saveold "$path_out\erase11_`y'.dta", replace
}
forvalues y=2001(1)2014 {
import delimited "$pc\SITCR2_5d\type-C_r-ALL_ps-`y'.csv", clear
keep if tradeflow=="Export"
keep if partner=="World"
keep if agg==4
rename commoditycode good
rename reporteriso country
drop if country=="" | good=="TOTAL"
global class="SITCR2-4d"
qui do "$path_do\A-Lists.do" // goods classification

bys country a1: g a0=_n
bys country a1: egen x=max(a0)
label var x "# of products exported of each 2-d good"
qui keep if a0==1

keep if country!=""
egen nTOT=count(year)
forvalues o=1(1)4{
g m`o'=1 if a`o'!=1 & a4!=1
egen nA`o'=sum(a`o')
egen nM`o'=sum(m`o')
}
keep year n*
drop netw
keep if _n==1
order year
sort year
saveold "$path_out\erase11_`y'.dta", replace
}

forvalues y=1962(1)2014{
	qui if ("`y'"=="1962") u "$path_out/erase11_`y'.dta", clear
	qui if ("`y'"!="1962") append using "$path_out/erase11_`y'.dta"
	qui erase "$path_out/erase11_`y'.dta"
}
sort year
forvalues o=1(1)3{
	g gA`o'=(nA`o'[_n+9]-nA`o')/nA`o'
	label var gA`o' "10yr growth rate of A`o' products exported"
	g gM`o'=(nM`o'[_n+9]-nM`o')/nM`o'
	label var gM`o' "10yr growth rate of M`o' products exported"
}
*There is a large jump downward in the # of varieties exported in 2001 due to the change in database

sort year
saveold "$path_out\Productsworld_4d.dta", replace

mat drop _all
matrix A=J(8,3,.)
forvalues j=1(1)3{
twoway (scatter gM`j' gA`j' if year<1991, mc(black)) ///
(function y=x,  range(-1 1) lw(medium) lp(dash) lc(gs5)), ///
xtitle("gA") ytitle("gM") legend(off) ///
graphr(color(white) ilcolor(white) fcolor(white) ifcolor(white) margin(medium)) ///
plotr(icolor(white) ilcolor(white) fcolor(white) ifcolor(white) margin(small))
graph2tex, epsfile("$pc\Figure_P_world_`j'")
ttest gM`j' == gA`j'
mat A[1,`j']=r(mu_1)
mat A[2,`j']=r(sd_1)
mat A[3,`j']=r(mu_2)
mat A[4,`j']=r(sd_2)
mat A[5,`j']=r(N_1)
mat A[6,`j']=r(p_l) 
mat A[7,`j']=r(p)
mat A[8,`j']=r(p_u)
}
frmttable using "$pc\Table_P_world_aux1", statmat(A) ///
rtitles("mean(gM)" \ "sd(gM)" \ "mean(gA)" \ "sd(gA)" \ "Obs." \ "\$ Ha:gM<gA$" \ "\$ Ha:gM \neq gA$" \ "\$ Ha:gM>gA$") ///
ctitles("" "\$ gM1=gA1$" "\$ gM2=gA2$" "\$ gM3=gA3$") ///
sdec(3\3\3\3\0\3\3\3) replace tex ///
plain fragment nocenter hline(010000100) spacebef(010000000)
filefilter "$pc\Table_P_world_aux1.tex" "$pc\Table_P_world_aux2.tex", from ("\BSbegin{tabular}{lccc}" ) to ("& \BSmulticolumn{3}{c}{4-digits} \BS\BS") replace
filefilter "$pc\Table_P_world_aux2.tex" "$pc\Table_P_world.tex", from ("\BSend{tabular}\BS\BS") to ("") replace
forvalues i=1(1)2{
rm "$pc\Table_P_world_aux`i'.tex"
} //Table A.5 in the text

*6.2 At 6-digit
forvalues y=1995(1)2007 {
u "$pc\data\Trade\BACI\baci92\baci92_`y'.dta", clear
bys t hs6 i: g s=_n
keep if s==1
destring hs6, replace
global class="HS0-6d"
qui do "$path_do\A-Lists.do" // goods classification
	
forvalues o=1(1)4{
g m`o'=1 if a`o'!=1 & a4!=1
egen nA`o'=sum(a`o')
egen nM`o'=sum(m`o')
}
keep t n*
keep if _n==1
saveold "$path_out\erase1_`y'.dta", replace
}
forvalues y=1995(1)2007{
	qui if ("`y'"=="1995") u "$path_out/erase1_`y'.dta", clear
	qui if ("`y'"!="1995") append using "$path_out/erase1_`y'.dta"
	qui erase "$path_out/erase1_`y'.dta"
}
sort t
forvalues o=1(1)3{
	g gA`o'=(nA`o'[_n+9]-nA`o')/nA`o'
	label var gA`o' "10yr growth rate of A`o' products exported"
	g gM`o'=(nM`o'[_n+9]-nM`o')/nM`o'
	label var gM`o' "10yr growth rate of M`o' products exported"
}

*I'm not including mean tests in the A matrix because I only have 4 obs.
*Still looking at the resulting rates is somewhat informative.
sum g*
/*
    Variable |        Obs        Mean    Std. Dev.       Min        Max
-------------+---------------------------------------------------------
         gA1 |          4    .0940072     .022125   .0770845   .1262234
         gM1 |          4    .1193389    .0238451   .0971948   .1519312
         gA2 |          4    .0954882    .0235238   .0789187   .1303258
         gM2 |          4    .1193389    .0238451   .0971948   .1519312
         gA3 |          4    .0856936    .0262513   .0676189   .1241806
         gM3 |          4    .1330699    .0215443   .1136632   .1625815*/


****
*7-I show the same thing but using production instead of exports (i.e. counting firms for countries in the EU)
****
*US: data from the Census Bureau's Statistics of US Businesses (SUSB)
import excel "$pc\data\SUSB\us_6digitnaics_1998.xls", sheet("us98") cellrange(A8:M8516) firstrow clear
rename CODE naics97
label var naics97 "1997 North American Industry Classification System (NAICS) codes"
rename NAICSDESCRIPTION naics97_desc
rename TOTAL firms
keep if DATATYPE=="Firms"
g length = length(naics97)
drop if length<6
	global class="NAICS97"
	qui do "$path_do\A-Lists.do" // goods classification
destring firms, replace
forvalues j=1(1)3{
g auxA`j'=firms if a`j'==1
egen A`j'=sum(auxA`j')
g auxM`j'=firms if a`j'==. & a4==. & a5==.
egen M`j'=sum(auxM`j')
}
keep if _n==1
keep A* M*
g time=1998
g geo="US"
sort geo
saveold "$path_out\erase0.dta", replace

import excel "$pc\data\SUSB\us_6digitnaics_2015.xlsx", sheet("U.S., all industries") cellrange(A9:J18102) clear
rename A naics12
label var naics12 "2012 North American Industry Classification System (NAICS) codes"
rename B naics12_desc
rename D firms
rename E establishments
keep if C=="01:  Total"
g length = length(naics12)
drop if length<6
	global class="NAICS12"
	qui do "$path_do\A-Lists.do" // goods classification
forvalues j=1(1)3{
g auxA`j'=firms if a`j'==1
egen A`j'=sum(auxA`j')
g auxM`j'=firms if a`j'==. & a4==. & a5==.
egen M`j'=sum(auxM`j')
}
keep if _n==1
keep A* M*
g time=2015
g geo="US"
g geo_label="United States of America"
sort geo
append using "$path_out\erase0.dta"
foreach i in A M{
forvalues j=1(1)3{
g aux1`i'`j'=`i'`j' if time==1998
egen `i'`j'ini=mean(aux1`i'`j')
g aux2`i'`j'=`i'`j' if time==2015
egen `i'`j'end=mean(aux2`i'`j')
}
}
foreach i in A M{
forvalues j=1(1)3{
g g`i'`j'=(`i'`j'end-`i'`j'ini)/`i'`j'ini
}
}
keep geo g*
keep if _n==1
saveold "$path_out\erase1.dta", replace

*EU
import excel "$pc\data\Eurostat\Production\Agriculture (agr)\Farm structure (ef)\ef_mptrainman_extract.xls", sheet("Sheet1") firstrow clear
rename B A2005
rename C A2010
rename D A2013
rename GEO geo_label
sort geo_label
saveold "$path_out\erase2.dta", replace

import delimited "$pc\data\Eurostat\Structural business statistics\sbs_na_sca_r2_1_Data.csv", clear
replace value="" if value==":"
destring value, replace

	global class="NACER2"
	qui do "$path_do\A-Lists.do" // goods classification

forvalues j=1(1)3{
bys geo time: egen Aaux`j'=sum(value) if a`j'==1
bys geo time: egen A`j'=mean(Aaux`j')
g aux`j'=1 if a`j'==. & a4==. & a5==.
bys geo time: egen Maux`j'=sum(value) if aux`j'==1
bys geo time: egen M`j'=mean(Maux`j')
drop aux`j' Aaux`j' Maux`j'
}

bys geo time: g num=_n
keep if num==1

foreach i in A M{
forvalues j=1(1)3{
g z`i'`j'08=`i'`j' if time==2008
bys geo: egen i`i'`j'=mean(z`i'`j'08)
g z`i'`j'13=`i'`j' if time==2013
bys geo: egen e`i'`j'=mean(z`i'`j'13)
}
}
keep time geo geo_label i* e*
bys geo: g num=_n
keep if num==1
sort geo_label
merge geo_label using "$path_out\erase2.dta"
drop if _merge!=3
forvalues j=1(1)3{
g A`j'ini=iA`j'+A2005
g A`j'end=eA`j'+A2013
rename iM`j' M`j'ini
rename eM`j' M`j'end
}

foreach i in A M{
forvalues j=1(1)3{
g g`i'`j'=(`i'`j'end-`i'`j'ini)/`i'`j'ini
}
}
keep geo geo_label g*
append using "$path_out\erase1.dta"

mat drop _all
matrix A=J(8,3,.)
forvalues j=1(1)3{
twoway (scatter gM`j' gA`j' if gM`j'<2, mc(black)) ///
(function y=x,  range(-1 1) lw(medium) lp(dash) lc(gs5)), ///
xtitle("gA") ytitle("gM") legend(off) ///
graphr(color(white) ilcolor(white) fcolor(white) ifcolor(white) margin(medium)) ///
plotr(icolor(white) ilcolor(white) fcolor(white) ifcolor(white) margin(small))
graph2tex, epsfile("$pc\Figure_P_dom_`j'") //Figure 4 in the text.
ttest gM`j' == gA`j'
mat A[1,`j']=r(mu_1)
mat A[2,`j']=r(sd_1)
mat A[3,`j']=r(mu_2)
mat A[4,`j']=r(sd_2)
mat A[5,`j']=r(N_1)
mat A[6,`j']=r(p_l) 
mat A[7,`j']=r(p)
mat A[8,`j']=r(p_u)
}
frmttable using "$pc\Table_P_gMgA_dom", statmat(A) ///
rtitles("mean(gM)" \ "sd(gM)" \ "mean(gA)" \ "sd(gA)" \ "Obs." \ "\$ Ha:gM<gA$" \ "\$ Ha:gM \neq gA$" \ "\$ Ha:gM>gA$") ///
ctitles("\$ gMk=gAk$" "\$ k=1$" "\$ k=2$" "\$ k=3$") sdec(3\3\3\3\0\3\3\3) replace tex plain fragment nocenter hline(010000100) spacebef(01000)
erase "$path_out\erase0.dta"
erase "$path_out\erase1.dta"
erase "$path_out\erase2.dta"


******
*8-computes the average occupation of bins within A and within M
******
forvalues p=62(1)100 {
qui {
if "`p'"!="100" local x="`p'"
if "`p'"=="100" local x="00"
if "`p'"!="100" local y="19`p'"
if "`p'"=="100" local y="2000"
u "$pc\data\Trade\Feenstra\wtf`x'.dta", clear
qui keep if importer=="World"
bys exporter sitc4: g n=_n
keep if n==1
qui rename (exporter sitc4) (country_feenstra good)
qui sort country_feenstra
qui merge country_feenstra using "$pc/country compatibility.dta"	// ads isocodes
keep if _merge==3
drop _merge
rename country_isocode country
drop if country==""
global class="SITCR2-4d"
qui do "$path_do\A-Lists.do" // goods classification
bys country: egen xA1=sum(a1)
bys country: egen xA2=sum(a2)
bys country: egen xA3=sum(a3)
bys country: egen xE =sum(a4)
g aux=1
bys country: egen tot =sum(aux)
g xM1=tot-(xA1+xE)
g xM2=tot-(xA2+xE)
g xM3=tot-(xA3+xE)
g ocupA1=xA1/308
g ocupA2=xA2/351
g ocupA3=xA3/401
g ocupM1=xM1/(1239-158-308)
g ocupM2=xM2/(1239-158-351)
g ocupM3=xM3/(1239-158-401)
sum ocup*
rename country country_isocode
qui sort country_iso
qui merge country_iso using "$path_out/A.dta"	// ads country specialization
keep country_iso year x* ocup* A*
saveold "$path_out/ocup_aux`y'.dta", replace
}
}

qui u "$path_out\ocup_aux1962.dta", clear
forvalues y=1963(1)2000 {
append using "$path_out\ocup_aux`y'.dta"
erase "$path_out\ocup_aux`y'.dta"
}
erase "$path_out\ocup_aux1962.dta"
saveold "$path_out/ocup_tot.dta", replace

sum ocupA1 ocupM1
twoway (histogram ocupA1, bin(18) color(red%30)) (histogram ocupM1, bin(20) color(green%30)), ///   
legend(order(1 "Bin occup A" 2 "Bin occup M" )) graphr(color(white) ilcolor(white) fcolor(white) ifcolor(white) margin(medium)) ///
plotr(icolor(white) ilcolor(white) fcolor(white) ifcolor(white) margin(small))
graph export "$pc\\Figure_P_Occup_all.pdf" // Figure 3.a in the text.

twoway (histogram ocupA1 if A1>50, bin(11) color(red%30)) (histogram ocupM1 if A3<30 & A4<30, bin(20) color(green%30)), ///   
legend(order(1 "Bin occup A" 2 "Bin occup M" )) graphr(color(white) ilcolor(white) fcolor(white) ifcolor(white) margin(medium)) ///
plotr(icolor(white) ilcolor(white) fcolor(white) ifcolor(white) margin(small))
graph export "$pc\\Figure_P_Occup_AnM.pdf" // Figure 3.b in the text.

******************
*9-I show that changes in TT are correlated positively to changes in nX and negatively to changes in nM
******************
forvalues p=62(1)100 {
qui if "`p'"!="100" local x="`p'"
qui if "`p'"=="100" local x="00"
qui if "`p'"!="100" local y="19`p'"
qui if "`p'"=="100" local y="2000"
qui u "$pc\data\Trade\Feenstra\wtf`x'.dta", clear
g aux1=1 if importer!="World"
bys exporter: g aux2=sum(aux1)
bys exporter: egen nXv=max(aux2)
label var nXv "# of varieties (good-destination) exported"
qui keep if importer=="World"
bys exporter: g aux3=_n
bys exporter: egen nXg=max(aux3)
label var nXg "# of products exported"
qui rename exporter country_feenstra
qui sort country_feenstra
qui merge country_feenstra using "$pc//country compatibility.dta"	// ads isocodes
keep if _merge==3
rename country_isocode country
bys country: g aux4=_n
keep if aux4==1
keep if country!=""
keep country year nX*
sort country
saveold "$path_out\erase1_`y'.dta", replace

qui u "$pc\data\Trade\Feenstra\wtf`x'.dta", clear
g aux1=1 if exporter!="World"
bys importer: g aux2=sum(aux1)
bys importer: egen nMv=max(aux2)
label var nMv "# of varieties (good-origin) imported"
qui keep if exporter=="World"
bys importer: g aux3=_n
bys importer: egen nMg=max(aux3)
label var nMg "# of products imported"
rename importer country_feenstra
qui sort country_feenstra
qui merge country_feenstra using "$pc/country compatibility.dta"	// ads isocodes
keep if _merge==3
rename country_isocode country
drop _merge
sort country
merge country using "$path_out\erase1_`y'.dta"
tab _merge
keep if _merge==3
bys country: g aux4=_n
keep if aux4==1
keep if country!=""
keep country year nM*
saveold "$path_out\erase2_`y'.dta", replace
}

forvalues y=2001(1)2010 {
import delimited "$pc\type-C_r-ALL_ps-`y'.csv", clear
keep if tradeflow=="Export"
keep if agg==4
rename commoditycode good
rename reporteriso country
drop if country=="" | good=="TOTAL"
g aux1=1 if partner!="World"
bys country: g aux2=sum(aux1)
bys country: egen nXv=max(aux2)
label var nXv "# of varieties (good-destination) exported"
qui keep if partner=="World"
bys country: g aux3=_n
bys country: egen nXg=max(aux3)
label var nXg "# of products exported"
bys country: g aux4=_n
keep if aux4==1
keep if country!=""
keep country year nX*
sort country
saveold "$path_out\erase1_`y'.dta", replace

import delimited "$pc\type-C_r-ALL_ps-`y'.csv", clear
keep if tradeflow=="Import"
keep if agg==4
rename commoditycode good
rename partneriso country
drop if country=="" | good=="TOTAL"
g aux1=1 if reporter!="World"
bys country: g aux2=sum(aux1)
bys country: egen nMv=max(aux2)
label var nMv "# of varieties (good-origin) imported"
bys country good: g aux3=_n
keep if aux3==1
bys country: g aux4=_n
bys country: egen nMg=max(aux4)
label var nMg "# of products imported"
bys country: g aux5=_n
keep if aux4==1
keep if country!=""
keep country year nM*
sort country
saveold "$path_out\erase2_`y'.dta", replace
}

forvalues y=1962(1)2010 {
u "$path_out\erase1_`y'.dta", clear
merge country using "$path_out\erase2_`y'.dta"
drop _merge
saveold "$path_out\erase3_`y'.dta", replace
}

qui u "$path_out\erase3_1962.dta", clear
forvalues y=1963(1)2010 {
append using "$path_out\erase3_`y'.dta"
}
sort country year
merge country year using "$path_out/Divergence.dta"
keep if _merge==3
drop _merge
drop if country==""
order country year
sort country year
saveold "$path_out\Products1-2.dta", replace

forvalues y=1962(1)2010 {
forvalues i=1(1)3{
erase "$path_out\erase`i'_`y'.dta"
}
}

*Barro and Lee
import excel "$pc\data\Barro-Lee growth\trade.xls", sheet("Sheet1") firstrow clear
keep tot*
g shcode=_n
drop if shcode==139
sort shcode
merge shcode using "$pc\data\Barro-Lee growth\shcodes.dta"
drop _merge
order shcode country_name country_isocode

	*5-yr aggregate change
rename tot1 tot1965
rename tot2 tot1970
rename tot3 tot1975
rename tot4 tot1980
rename tot5 tot1985

rename country_isocode country
keep country tot*
sort country
saveold "$path_out/TT_aux1.dta", replace

*WDI nbtti
u "$path_out/TT_wdi.dta", clear
forvalues y=1980(5)2010{
g aux`y'=nbtti if year==`y' & nbtti!=.
bys country: egen tt`y'=mean(aux`y')
}
g tot1990=(tt1990-tt1985)/tt1985
g tot1995=(tt1995-tt1990)/tt1990
g tot2000=(tt2000-tt1995)/tt1995
g tot2005=(tt2005-tt2000)/tt2000
g tot2010=(tt2010-tt2005)/tt2005

g dTT8595=(tt1995-tt1985)/tt1985
g dTT8500=(tt2000-tt1985)/tt1985
g dTT8505=(tt2005-tt1985)/tt1985
g dTT8510=(tt2010-tt1985)/tt1985
keep if year==1985 & nbtti!=.
drop tta year nbtti aux*
sort country
saveold "$path_out/TT_aux2.dta", replace

u "$path_out/TT_aux1.dta", clear
keep country tot1*
rename tot1980 tot19802
rename tot1985 tot19852
sort country
merge country using "$path_out/TT_aux2.dta"
replace tot1980=tot19802 if tot1980==.
replace tot1985=tot19852 if tot1985==.
g tot_1960=((1+tot1965)^5)*((1+tot1970)^5)-1 // rates of future change in TT
g tot_1970=((1+tot1975)^5)*((1+tot1980)^5)-1
g tot_1980=((1+tot1985)^5)*((1+tot1990)^5)-1
g tot_1990=((1+tot1995)^5)*((1+tot2000)^5)-1
g tot_2000=((1+tot2005)^5)*((1+tot2010)^5)-1
keep country tot_*
reshape long tot_, i(country) j(year)
rename tot_ tot
drop if tot==.
sort country year
saveold "$path_out/TT_aux72.dta", replace

u "$path_out\Products1-2.dta", clear
sort country year
foreach v in nXg nXv nMg nMv rgdpl openk {
bys country: g g`v'=(`v'[_n+9]-`v')/`v'
replace g`v'=g`v'[_n+1] if year==2000
replace `v'=`v'[_n+1] if year==2000
*I don't want to use changes in n's for the period 2000-2009 since there are large jump in n's due to changing data sources.
*Therefore I place the obs of 2001 at the year 2000. 
}
sort country year
merge country year using "$path_out/TT_aux72.dta"
keep if _merge==3
sort country year
g lrgdp=log(rgdpl)
egen c = group(country)
xtset c year

*Table we use
label var gnXg "\# of exports (10yr growth rate)"
label var gnMg "\# of imports (10yr growth rate)"
label var nXg "\# of exports (initial level)"
label var nMg "\# of imports (initial level)"
label var lrgdp "GDPpc (logs)"
label var openk "Openness (initial level)"
label var gopenk "Openness (10yr growth rate)"
eststo clear
eststo: reg tot gnXg gnMg nXg nMg
eststo: reg tot gnXg gnMg nXg nMg lrgdp
eststo: reg tot gnXg gnMg nXg nMg lrgdp openk
eststo: reg tot gnXg gnMg nXg nMg lrgdp openk gopenk
eststo: xtreg tot gnXg gnMg nXg nMg lrgdp openk gopenk, fe r
estadd local fixed "Yes", replace
esttab using "$pc\Table_P_TT.tex",  b(3) ///
prehead("Dependant variable: 10yr change in Terms of Trade \\") ///
booktab fragment star(* 0.10 ** 0.05 *** 0.01) se replace nomtitle label ///
stats(fixed N r2, fmt(0 0 3) labels(`"Country-FE"' `"Obs."' `"\$R^{2}$"')) //Table A.17 in the text.

erase "$path_out/TT_aux1.dta"
erase "$path_out/TT_aux2.dta"
erase "$path_out/TT_aux72.dta"