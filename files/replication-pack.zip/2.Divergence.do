/***********
2.DIVERGENCE
************
This do file:
1-creates database Divergence.dta with
	-data on gdp and pop from PWT
	-indicator on whether countries were rich in 1962 (among the top 30%)
	-variable on intensity of exports in A
	-selected vars from WDI
	-Easterly and Levine (1997) database
	-Gallup (2001) database
	-Sala-i-Martin (1997) database
This database contains all 21 variables identified in Sala-i-Martin et al(2004) as robust growth regressors. 
2-creates divergence graphs
	-graphs evolution of per capita gdp of countries specializad in A to all countries.
	-graphs evolution of per capita gdp of countries specializad in A (among the rich) to all rich.
3-creates a database with the countries that were rich in 1962 AND have a large specialization in A (greater than 30%) in 2000
4-runs growth regressions to see whhow A1-countries perform (both with real and nominal income)
5-robustness checks:
	5.1-same as 4 but with all A dummies
	5.2-increasing the number of obs
	5.3-considering initial specialization
6-Runs probit to characterize A-countries
*/
version 8

*Easterly and Levine
u "$pc\data\Easterly-Levine\Africa_Growth_Tragedy_dataset\othervar.dta", clear
rename  _0 country_isocode
sort country_isocode
saveold "$path_out\EnL_aux.dta", replace

*Gallup data
u "$pc\data\Geography Datasets, Gallup, Mellinger and Sachs\geodata.dta", clear
rename wbcode country_isocode
sort country_isocode
saveold "$path_out\gallup_aux.dta", replace
u "$pc\data\Geography Datasets, Gallup, Mellinger and Sachs\malaria.dta", clear
rename wbcode country_isocode
sort country_isocode
merge country_isocode using "$path_out\gallup_aux.dta"
tab _merge
drop _merge
sort country_isocode
saveold "$path_out\gallup_aux2.dta", replace //169 countries

*Sala-i-Martin (1997) data
u "$pc\data\Sala-i-Martin (1997)\millions_2.dta", clear
rename x1 GDPSH60
rename x2 LIFEE060
rename x4  safrica 
rename x5  laam
rename x23  YrsOpen
rename x41  RERD
rename x50  SPAIN
rename x51  BUDDHA
rename x53  CONFUC
rename x56  MUSLIM
rename x59  Mining
rename code country_isocode
drop __ gamma
sort country_isocode
saveold "$path_out\sala_aux.dta", replace //134 countries

*Rich countries (top 30%) in 1962 (1st year with trade data)
import delimited "$pc\data\PWT\PWT7.1\pwt71_wo_country_names_wo_g_vars.csv", clear
rename isocode country_isocode
*u "$pc\data\PWT\PWT6.3\pwt6.3.dta", clear
*drop country
sort country_isocode year
saveold "$path_out\pwt_aux.dta", replace
keep if year==1962
drop if rgdpl==.
xtile g = rgdpl, nq(100)
g rich62=1 if g>=70
replace rich62=0 if rich62==.
qui label var rich62 "Dummy country is rich in 1962"
keep country_isocode rich62
sort country_isocode
saveold "$path_out\rich_countries.dta", replace //35 countries (URY and NZL included)

*Gathers together all relevant datasets
u "$path_out\A.dta", clear
sort country_iso
merge country_iso using "$path_out\EnL_aux.dta"
drop _merge
sort country_iso
merge country_iso using "$path_out\sala_aux.dta"
drop _merge
sort country_iso
merge country_iso using "$path_out\gallup_aux2.dta"
drop _merge
sort country_iso year
merge country_iso year using "$path_out\pwt_aux.dta"
drop _merge
sort country_isocode
merge country_isocode using "$path_out\rich_countries.dta"
drop _merge
sort country_iso year
*merge country_isocode year using "$pc\PhD\1_MR\datasets\WDI_ready.dta"
merge country_isocode year using "$pc\data\WDI\WDI2015\WDI2015_ready.dta"
drop _merge
drop if country_iso=="" | rgdpl==. | A1==.

*East Asian country dummy: according to https://en.wikipedia.org/wiki/East_Asia
g east_asian=1 if country_iso=="CHN" | country_iso=="HKG" | country_iso=="MAC" | country_iso=="JPN" ///
| country_iso=="PRK" | country_iso=="KOR" | country_iso=="MNG" | country_iso=="TWN"
replace east_asian=0 if east_asian==.

/*
sort A1
browse country_isocode A1 A2 A3 A4 if year==2000 & rich62==1
country_isocode	A1	A2	A3	A4
JPN	.0074384	.0299872	.0358827	.0312564
VEN	.0197257	.0375559	.0409866	.9020895
SGP	.0231626	.0547571	.0601094	.1323124
CHE	.0314703	.0837384	.1038345	.1138816
TTO	.0354183	.157298		.1598805	.7598719
ISR	.0446535	.0886095	.092875		.3107668
MEX	.0519153	.0595875	.0667432	.1244186
GBR	.0589521	.0927401	.107116		.147985
ITA	.0703698	.0884529	.1285956	.0501248
SWE	.0712878	.0790426	.170204		.073169
NOR	.0729132	.0905266	.1179566	.7180814
FIN	.0784357	.093647		.3105863	.0740824
AUT	.0857462	.1002566	.1796383	.0546089
USA	.0875178	.1159751	.1352016	.0509425
IRL	.0946364	.3837515	.3884633	.0201449
BEL	.1005835	.1475588	.1733821	.1791584
PRT	.1058647	.1186245	.1955035	.0401126
FRA	.1195834	.1495496	.1741493	.0629384
CAN	.1335666	.1501535	.2099274	.1774673
ESP	.1563645	.1766973	.2039381	.0734148
GAB	.1583798	.1601854	.1720136	.8225558
JAM	.166254		.1854663	.1862318	.3801124
NLD	.1755696	.2241943	.2452133	.1576599
DNK	.2482922	.2685427	.2926222	.0834892
GRC	.2632405	.2739533	.2893849	.2626612
AUS	.2672356	.2696064	.2826578	.4859197
CRI	.3551009	.3605032	.3667047	.0064095
BRB	.4052998	.4206743	.4242962	.087729
ARG	.4653448	.4785112	.5176166	.2237229
URY	.4952891	.5114548	.6243134	.0259832
NZL	.6108842	.6362949	.6916056	.0719453
ISL	.6741279	.6748278	.6791638	.2197672
SYC	.9331673	.9331673	.9331673	.010575
*/

forvalues i=1(1)4{
forvalues j=30(10)50{
	qui {
	local l=`j'/100
	g both`i'_`j'=A`i'_`j'*rich62
	replace both`i'_`j'=0 if both`i'_`j'==.
	label var both`i'_`j' "=1 if rich in 1962 and A`i'>`j' for 40 yrs or more"
	g both`i'_`j'end=A`i'_`j'end*rich62
	replace both`i'_`j'end=0 if both`i'_`j'end==.
	label var both`i'_`j'end "=1 if rich in 1962 and A`i'>`j' in their final year"
	g both`i'_`j'ini=A`i'_`j'ini*rich62
	replace both`i'_`j'ini=0 if both`i'_`j'ini==.
	label var both`i'_`j'ini "=1 if rich in 1962 and A`i'>`j' in their initial year"
	g both`i'_`j'_00=A`i'_`j'_00*rich62
	replace both`i'_`j'_00=0 if both`i'_`j'_00==.
	label var both`i'_`j'_00 "=1 if rich in 1962 and A`i'>`j' in 2000"
	g both`i'_`j'_30yr=A`i'_`j'_30yr*rich62
	replace both`i'_`j'_30yr=0 if both`i'_`j'_30yr==.
	label var both`i'_`j'_30yr "=1 if rich in 1962 and A`i'>`j' for 30yrs until 2000"
}
}
}

g G=pop*rgdpl
bys year: egen AGDP=total(G) //Agg. GDP
bys year: egen APOP=total(pop) //Agg. Pop
g gdppcall=AGDP/APOP
label var gdppcall "Per capita GDP of all countries (constant prices)"

bys rich62 year: egen GDPrich=total(G)
replace GDPrich=. if rich62!=1 //Agg. GDP of countries that were rich in 1962
bys rich62 year: egen POPrich=total(pop)
replace POPrich=. if rich62!=1 //Agg. Pop of all countries that were rich in 1962
g gdppcr=GDPrich/POPrich
label var gdppcr "Per capita GDP of countries that were rich in 1962 (constant prices)"

forvalues i=1(1)4{
forvalues j=30(10)50{
	qui {
	local l=`j'/100
	
bys A`i'_`j' year: egen GDPA`i'_`j'=total(G)
replace GDPA`i'_`j'=. if A`i'_`j'!=1 //Agg. GDP of countries for which A`i'>`j' for 40 yrs or more
bys A`i'_`j' year: egen POPA`i'_`j'=total(pop)
replace POPA`i'_`j'=. if A`i'_`j'!=1 //Agg. GDP of countries for which A`i'>`j' for 40 yrs or more

g gdppcA`i'_`j'=GDPA`i'_`j'/POPA`i'_`j'
label var gdppcA`i'_`j' "Per capita GDP of countries for which A`i'>`j' for 40 yrs or more"
g divA`i'_`j'=gdppcA`i'_`j'/gdppcall
label var divA`i'_`j' "Relative Per capita GDP of countries for which A`i'>`j' for 40 yrs or more"

bys A`i'_`j'_30yr year: egen GDPA`i'_`j'_30yr=total(G)
replace GDPA`i'_`j'_30yr=. if A`i'_`j'_30yr!=1 //Agg. GDP of countries for which A`i'>`j' for 30 yrs or more until 2000
bys A`i'_`j' year: egen POPA`i'_`j'_30yr=total(pop)
replace POPA`i'_`j'_30yr=. if A`i'_`j'_30yr!=1 //Agg. GDP of countries for which A`i'>`j' for 30 yrs or more until 2000

g gdppcA`i'_`j'_30yr=GDPA`i'_`j'_30yr/POPA`i'_`j'_30yr
label var gdppcA`i'_`j'_30yr "Per capita GDP of countries for which A`i'>`j' for 30 yrs or more until 2000"
g divA`i'_`j'_30yr=gdppcA`i'_`j'_30yr/gdppcall
label var divA`i'_`j'_30yr "Relative Per capita GDP of countries for which A`i'>`j' for 30 yrs or more until 2000"

bys A`i'_`j'end year: egen GDPA`i'_`j'end=total(G)
replace GDPA`i'_`j'end=. if A`i'_`j'end!=1 //Agg. GDP of countries for which A`i'>`j' the last year
bys A`i'_`j'end year: egen POPA`i'_`j'end=total(pop)
replace POPA`i'_`j'end=. if A`i'_`j'end!=1 //Agg. GDP of countries for which A`i'>`j' the last year

g gdppcA`i'_`j'end=GDPA`i'_`j'end/POPA`i'_`j'end
label var gdppcA`i'_`j'end "Per capita GDP of countries for which A`i'>`j' the last year"
g divA`i'_`j'end=gdppcA`i'_`j'end/gdppcall
label var divA`i'_`j'end "Relative Per capita GDP of countries for which A`i'>`j' the last year"

bys A`i'_`j'_00 year: egen GDPA`i'_`j'_00=total(G)
replace GDPA`i'_`j'_00=. if A`i'_`j'_00!=1 //Agg. GDP of countries for which A`i'>`j' in 2000
bys A`i'_`j'_00 year: egen POPA`i'_`j'_00=total(pop)
replace POPA`i'_`j'_00=. if A`i'_`j'_00!=1 //Agg. GDP of countries for which A`i'>`j' in 2000

g gdppcA`i'_`j'_00=GDPA`i'_`j'_00/POPA`i'_`j'_00
label var gdppcA`i'_`j'_00 "Per capita GDP of countries for which A`i'>`j' in 2000"
g divA`i'_`j'_00=gdppcA`i'_`j'_00/gdppcall
label var divA`i'_`j'_00 "Relative Per capita GDP of countries for which A`i'>`j' in 2000"

bys A`i'_`j'ini year: egen GDPA`i'_`j'ini=total(G)
replace GDPA`i'_`j'ini=. if A`i'_`j'ini!=1 //Agg. GDP of countries for which A`i'>`j' in their initial year
bys A`i'_`j'ini year: egen POPA`i'_`j'ini=total(pop)
replace POPA`i'_`j'ini=. if A`i'_`j'ini!=1 //Agg. GDP of countries for which A`i'>`j' in their initial year

g gdppcA`i'_`j'ini=GDPA`i'_`j'ini/POPA`i'_`j'ini
label var gdppcA`i'_`j'ini "Per capita GDP of countries for which A`i'>`j' in their initial year"
g divA`i'_`j'ini=gdppcA`i'_`j'ini/gdppcall
label var divA`i'_`j'ini "Relative Per capita GDP of countries for which A`i'>`j' in their initial year"
	
bys both`i'_`j' year: egen GDPb`i'_`j'=total(G)
replace GDPb`i'_`j'=. if both`i'_`j'!=1 //Agg. GDP of countries that were rich in 1962 and A`i'>`j' for 40 yrs or more
bys both`i'_`j' year: egen POPb`i'_`j'=total(pop)
replace POPb`i'_`j'=. if both`i'_`j'!=1 //Agg. GDP of countries that were rich in 1962 and A`i'>`j' for 40 yrs or more

g gdppcb`i'_`j'=GDPb`i'_`j'/POPb`i'_`j'
label var gdppcb`i'_`j' "Per capita GDP of countries that were rich in 1962 and A`i'>`j' for 40 yrs or more"
g div`i'_`j'=gdppcb`i'_`j'/gdppcr
label var div`i'_`j' "Relative Per capita GDP of countries that were rich in 1962 and A`i'>`j' for 40 yrs or more"

bys both`i'_`j'_30yr year: egen GDPb`i'_`j'_30yr=total(G)
replace GDPb`i'_`j'_30yr=. if both`i'_`j'_30yr!=1 //Agg. GDP of countries that were rich in 1962 and A`i'>`j' for 30 yrs or more until 2000
bys both`i'_`j'_30yr year: egen POPb`i'_`j'_30yr=total(pop)
replace POPb`i'_`j'_30yr=. if both`i'_`j'_30yr!=1 //Agg. GDP of countries that were rich in 1962 and A`i'>`j' for 30 yrs or more until 2000

g gdppcb`i'_`j'_30yr=GDPb`i'_`j'_30yr/POPb`i'_`j'_30yr
label var gdppcb`i'_`j'_30yr "Per capita GDP of countries that were rich in 1962 and A`i'>`j' for 30 yrs or more until 2000"
g div`i'_`j'_30yr=gdppcb`i'_`j'_30yr/gdppcr
label var div`i'_`j'_30yr "Relative Per capita GDP of countries that were rich in 1962 and A`i'>`j' for 30 yrs or more until 2000"

bys both`i'_`j'end year: egen GDPb`i'_`j'end=total(G)
replace GDPb`i'_`j'end=. if both`i'_`j'end!=1 //Agg. GDP of countries that were rich in 1962 and A`i'>`j' the last year
bys both`i'_`j'end year: egen POPb`i'_`j'end=total(pop)
replace POPb`i'_`j'end=. if both`i'_`j'end!=1 //Agg. GDP of countries that were rich in 1962 and A`i'>`j' the last year

g gdppcb`i'_`j'end=GDPb`i'_`j'end/POPb`i'_`j'end
label var gdppcb`i'_`j'end "Per capita GDP of countries that were rich in 1962 and A`i'>`j' the last year"
g div`i'_`j'end=gdppcb`i'_`j'end/gdppcr
label var div`i'_`j'end "Relative Per capita GDP of countries that were rich in 1962 and A`i'>`j' the last year"

bys both`i'_`j'_00 year: egen GDPb`i'_`j'_00=total(G)
replace GDPb`i'_`j'_00=. if both`i'_`j'_00!=1 //Agg. GDP of countries that were rich in 1962 and A`i'>`j' in 2000
bys both`i'_`j'_00 year: egen POPb`i'_`j'_00=total(pop)
replace POPb`i'_`j'_00=. if both`i'_`j'_00!=1 //Agg. GDP of countries that were rich in 1962 and A`i'>`j' in 2000

g gdppcb`i'_`j'_00=GDPb`i'_`j'_00/POPb`i'_`j'_00
label var gdppcb`i'_`j'_00 "Per capita GDP of countries that were rich in 1962 and A`i'>`j' in 2000"
g div`i'_`j'_00=gdppcb`i'_`j'_00/gdppcr
label var div`i'_`j'_00 "Relative Per capita GDP of countries that were rich in 1962 and A`i'>`j' in 2000"

bys both`i'_`j'ini year: egen GDPb`i'_`j'ini=total(G)
replace GDPb`i'_`j'ini=. if both`i'_`j'ini!=1 //Agg. GDP of countries that were rich in 1962 and A`i'>`j' in their initial year
bys both`i'_`j'ini year: egen POPb`i'_`j'ini=total(pop)
replace POPb`i'_`j'ini=. if both`i'_`j'ini!=1 //Agg. GDP of countries that were rich in 1962 and A`i'>`j' in their initial year

g gdppcb`i'_`j'ini=GDPb`i'_`j'ini/POPb`i'_`j'ini
label var gdppcb`i'_`j'ini "Per capita GDP of countries that were rich in 1962 and A`i'>`j' in their initial year"
g div`i'_`j'ini=gdppcb`i'_`j'ini/gdppcr
label var div`i'_`j'ini "Relative Per capita GDP of countries that were rich in 1962 and A`i'>`j' in their initial year"
}
}
}

drop country
rename country_iso country
order country year
sort country year
qui saveold "$path_out/Divergence.dta", replace

*2-creates divergence graphs
	*-graphs evolution of per capita gdp of countries specializad in A to all countries.

label var divA1_30ini "initial"
label var divA1_30_30yr "permanent"
label var divA1_30_00 "final"
twoway (line divA1_30ini year if country=="ARG" & year<=2000, lw(medthick) lp(solid) lc(black)) /// I use ARG because I need 1 country which is in both groups
(line divA1_30_30yr year if country=="ARG" & year<=2000, lw(medthick) lp(longdash) lc(black)) ///
(line divA1_30_00 year if country=="ARG" & year<=2000, lw(medthick) lp(shortdash) lc(black)), ///
xtitle("year") ytitle("relative income") legend(cols(3)) ///
graphr(color(white) ilcolor(white) fcolor(white) ifcolor(white) margin(medium))  ///
plotr(icolor(white) ilcolor(white) fcolor(white) ifcolor(white) margin(small))
graph2tex, epsfile("$path_in\written\Figure_D_1")
graph2tex, epsfile("$path_in\written\slides\Figure_D_1") // Figure A.5 in the text.

	*-graphs evolution of per capita gdp of countries specializad in A (among the rich) to all rich.

label var div1_30ini "initial"
label var div1_30_30yr "permanent"
label var div1_30_00 "final"
twoway (line div1_30ini year if country=="ARG" & year<=2000, lw(medthick) lp(solid) lc(black)) /// I use ARG because I need 1 country which is in both groups
(line div1_30_30yr year if country=="ARG" & year<=2000, lw(medthick) lp(longdash) lc(black)) ///
(line div1_30_00 year if country=="ARG" & year<=2000, lw(medium) lp(shortdash) lc(black)), ///
xtitle("year") ytitle("relative income") legend(cols(3)) ///
graphr(color(white) ilcolor(white) fcolor(white) ifcolor(white) margin(medium))  ///
plotr(icolor(white) ilcolor(white) fcolor(white) ifcolor(white) margin(small))
graph2tex, epsfile("$path_in\written\Figure_D_2")
graph2tex, epsfile("$path_in\written\slides\Figure_D_2")
*I tried all other values of i and j and they all diverge except div3_30ini

/*
twoway line div year if country=="ARG" & year<=2000 , title("Divergence of A-intensive rich countries") subtitle("1950-2000") ///
xtitle("year") ytitle("relative gdp (pc)") ///
graphr(color(white)  ilcolor(white) fcolor(white) ifcolor(white) margin(medium)) ///
plotr( icolor(white) ilcolor(white) fcolor(white) ifcolor(white) margin(small)) 
graph2tex, epsfile("$path_in\written\Divergence") //I use ARG because I need 1 country which is in both groups
graph2tex, epsfile("$path_in\written\slides\Divergence")

twoway (line gdppcr year if country=="ARG") (line gdppcb year  if country=="ARG") 
twoway (line gdppcr year if country=="ARG") (line gdppcb year  if country=="ARG") (line rgdpl year  if country=="URY")
twoway (line gdppcr year if country=="ARG") (line gdppcb year  if country=="ARG") (line rgdpl year  if country=="NZL")
twoway (line gdppcr year if country=="ARG") (line gdppcb year  if country=="ARG") (line rgdpl year  if country=="ISL")
twoway (line gdppcr year if country=="ARG") (line gdppcb year  if country=="ARG") (line rgdpl year  if country=="ARG")
twoway (line gdppcr year if country=="ARG") (line gdppcb year  if country=="ARG") (line rgdpl year  if country=="BRB")
twoway (line gdppcr year if country=="ARG") (line gdppcb year  if country=="ARG") (line rgdpl year  if country=="IRL")
The only country that doesn't diverge is ISL, but this is because, despite having a high share of food exports (mostly fishing), it also have lots of
mineral exports.*/

*3-creates a database with the countries that were rich in 1962 AND have a large specialization in A
bys country: g n=_n
keep if n==1
keep country both* rich62 A*
drop A1 A2 A3 A4
sort country
qui saveold "$path_out/A_and_Rich.dta", replace			
erase "$path_out\rich_countries.dta"
erase "$path_out\pwt_aux.dta"
erase "$path_out\sala_aux.dta"
erase "$path_out\gallup_aux.dta"
erase "$path_out\gallup_aux2.dta"
erase "$path_out\EnL_aux.dta"

*4-runs divergence regressions
qui u "$path_out/Divergence.dta", clear			

*Creating growth rate 1965-2000
sort country year
g aux1=log(rgdpl) if year==1965
bys country: egen g65=mean(aux1)
g aux2=log(rgdpl) if year==2000
bys country: egen g00=mean(aux2)
g aux3=log(rgdpl) if year==2010
bys country: egen g10=mean(aux3)
g gr00=g00-g65
g gr10=g10-g65
sort country year
bys country: g aux5=tertiary if year==1975
bys country: egen ter75=mean(aux5)
bys country: g aux4=inflation if year==1975
bys country: egen infl75=mean(aux4)
drop aux*

*For var enrollment there are too many missing values at the beggining of the period so I average the first twenty yrs
g aux=enrollment if year>=1962 & year<=1972
bys country: egen enr6272=mean(aux)
drop aux

*4.1 First we obtain results until 2000

*4.1.1-Regression in Sala-i-Martin et al 2004
order country year gr00 gr10 east_asia enr6272 pi g65 lnd100km dens65c Mal66a LIFEE060 ///
CONFUC safrica laam Mining SPAIN YrsOpen MUSLIM BUDDHA muller gov_C pop_dens RERD

reg gr00 east_asia enr6272 pi g65 lnd100km dens65c Mal66a LIFEE060 CONFUC safrica ///
laam Mining SPAIN YrsOpen MUSLIM BUDDHA muller gov_C pop_dens RERD if year==1965, r

*4.1.2-If I replace all geographical dummies (east_asia safrica laam) for Adummies I get:
reg gr00 enr6272 pi g65 lnd100km dens65c Mal66a LIFEE060 CONFUC Mining SPAIN YrsOpen MUSLIM BUDDHA muller gov_C pop_dens RERD A1_30_00 if year==1965, r // good
reg gr00 enr6272 pi g65 lnd100km dens65c Mal66a LIFEE060 CONFUC Mining SPAIN YrsOpen MUSLIM BUDDHA muller gov_C pop_dens RERD A1_40_00 if year==1965, r // bad
reg gr00 enr6272 pi g65 lnd100km dens65c Mal66a LIFEE060 CONFUC Mining SPAIN YrsOpen MUSLIM BUDDHA muller gov_C pop_dens RERD A1_50_00 if year==1965, r // very good

*or, being more strict (removing east_asia safrica laam + lnd100km Mal66a CONFUC SPAIN MUSLIM BUDDHA):
reg gr00 enr6272 pi g65 dens65c LIFEE060 Mining YrsOpen muller gov_C pop_dens RERD A1_30_00 if year==1965, r //very good
reg gr00 enr6272 pi g65 dens65c LIFEE060 Mining YrsOpen muller gov_C pop_dens RERD A1_40_00 if year==1965, r //good
reg gr00 enr6272 pi g65 dens65c LIFEE060 Mining YrsOpen muller gov_C pop_dens RERD A1_50_00 if year==1965, r //very good

*4.1.3-If I start with full set of vars (including Ad) and remove non-signifficant vars one by one I get:
reg gr00 enr6272 pi g65 lnd100km dens65c Mal66a LIFEE060 CONFUC Mining YrsOpen MUSLIM BUDDHA muller gov_C pop_dens RERD A1_30_00 if year==1965, r
reg gr00 enr6272 pi g65 lnd100km dens65c Mal66a LIFEE060 CONFUC Mining YrsOpen MUSLIM BUDDHA muller gov_C pop_dens A1_30_00 if year==1965, r
reg gr00 enr6272 g65 lnd100km dens65c Mal66a LIFEE060 CONFUC Mining YrsOpen MUSLIM BUDDHA muller gov_C pop_dens A1_30_00 if year==1965, r
reg gr00 enr6272 g65 lnd100km Mal66a LIFEE060 CONFUC Mining YrsOpen MUSLIM BUDDHA muller gov_C pop_dens A1_30_00 if year==1965, r
reg gr00 enr6272 g65 lnd100km Mal66a LIFEE060 CONFUC Mining YrsOpen MUSLIM BUDDHA muller pop_dens A1_30_00 if year==1965, r
reg gr00 g65 lnd100km Mal66a LIFEE060 CONFUC Mining YrsOpen MUSLIM BUDDHA muller pop_dens A1_30_00 if year==1965, r
reg gr00 g65 lnd100km LIFEE060 CONFUC Mining YrsOpen MUSLIM BUDDHA muller pop_dens A1_30_00 if year==1965, r
reg gr00 g65 lnd100km LIFEE060 CONFUC Mining YrsOpen MUSLIM BUDDHA pop_dens A1_30_00 if year==1965, r
reg gr00 g65 lnd100km LIFEE060 CONFUC YrsOpen MUSLIM BUDDHA pop_dens A1_30_00 if year==1965, r
reg gr00 g65 lnd100km LIFEE060 CONFUC YrsOpen MUSLIM BUDDHA A1_30_00 if year==1965, r
reg gr00 g65 LIFEE060 CONFUC YrsOpen MUSLIM BUDDHA A1_30_00 if year==1965, r
*So I've removed all non-sig vars one by one and reached a specification that still contains Ad and it is still signifficant.

*I don't perform regressions with FE: Barro 2012 argues against the use of FE in short-period regs (he argues from 1960 on)

*I make tables out of 4.1.1+4.1.2 and 4.1.3

foreach var of varlist _all {
	label var `var' ""
}
label var east_asia "East-Asia"
label var enr6272 "Primary enrol. rate"
label var pi "Investment price PPP"
label var g65 "GDPpc (logs)"
label var lnd100km "Tropic land"
label var dens65c "Coastal pop."
label var Mal66a "Malaria prevalence"
label var LIFEE060 "Life expectancy"
label var CONFUC "Confucian pop."
label var safrica "S-S Africa"
label var laam "LATAM"
label var Mining "Mining GDP"
label var SPAIN "Frm Spanish colony"
label var YrsOpen "Years open"
label var MUSLIM "Muslim pop."
label var BUDDHA "Buddhist pop."
label var muller "Linguistic diffs."
label var gov_C "Gov. expenditure"
label var pop_dens "Pop. density"
label var RERD "RER distortions"

*4.1.1+4.1.2
foreach v in _00 _30yr {
forvalues j=1(1)3 {
eststo clear
eststo: reg gr00 east_asia enr6272 pi g65 lnd100km dens65c Mal66a LIFEE060 CONFUC safrica laam Mining SPAIN YrsOpen MUSLIM BUDDHA muller gov_C pop_dens RERD if year==1965, r
eststo: reg gr00 enr6272 pi g65 lnd100km dens65c Mal66a LIFEE060 CONFUC Mining SPAIN YrsOpen MUSLIM BUDDHA muller gov_C pop_dens RERD A`j'_30`v' if year==1965, r
eststo: reg gr00 enr6272 pi g65 lnd100km dens65c Mal66a LIFEE060 CONFUC Mining SPAIN YrsOpen MUSLIM BUDDHA muller gov_C pop_dens RERD A`j'_40`v' if year==1965, r
eststo: reg gr00 enr6272 pi g65 lnd100km dens65c Mal66a LIFEE060 CONFUC Mining SPAIN YrsOpen MUSLIM BUDDHA muller gov_C pop_dens RERD A`j'_50`v' if year==1965, r
eststo: reg gr00 enr6272 pi g65 dens65c LIFEE060 Mining YrsOpen muller gov_C pop_dens RERD A`j'_30`v' if year==1965, r
eststo: reg gr00 enr6272 pi g65 dens65c LIFEE060 Mining YrsOpen muller gov_C pop_dens RERD A`j'_40`v' if year==1965, r
eststo: reg gr00 enr6272 pi g65 dens65c LIFEE060 Mining YrsOpen muller gov_C pop_dens RERD A`j'_50`v' if year==1965, r
esttab using "$path_in\written\Table_D_1_`j'`v'.tex",  b(3) prehead("Dependant variable: & \multicolumn{7}{c}{growth rate 1962-2000 }  \\[1em]") ///
booktab fragment label star(* 0.10 ** 0.05 *** 0.01) se replace nogap nomtitle ///
stats(N r2, fmt(0 3) layout("\multicolumn{1}{c}{@}" ) labels(`"Obs."' `"\$R^{2}$"'))
}
} //Tables A.8-A.13 in the text.


*4.1.3-If I start with full set of vars (including Ad) and remove non-signifficant vars one by one I get:
eststo clear
eststo: reg gr00 enr6272 pi g65 lnd100km dens65c Mal66a LIFEE060 CONFUC Mining YrsOpen MUSLIM BUDDHA muller gov_C pop_dens RERD A1_30_00 if year==1965, r
eststo: reg gr00 enr6272 pi g65 lnd100km dens65c Mal66a LIFEE060 CONFUC Mining YrsOpen MUSLIM BUDDHA muller gov_C pop_dens A1_30_00 if year==1965, r
eststo: reg gr00 enr6272 g65 lnd100km dens65c Mal66a LIFEE060 CONFUC Mining YrsOpen MUSLIM BUDDHA muller gov_C pop_dens A1_30_00 if year==1965, r
eststo: reg gr00 enr6272 g65 lnd100km Mal66a LIFEE060 CONFUC Mining YrsOpen MUSLIM BUDDHA muller gov_C pop_dens A1_30_00 if year==1965, r
eststo: reg gr00 enr6272 g65 lnd100km Mal66a LIFEE060 CONFUC Mining YrsOpen MUSLIM BUDDHA muller pop_dens A1_30_00 if year==1965, r
eststo: reg gr00 g65 lnd100km Mal66a LIFEE060 CONFUC Mining YrsOpen MUSLIM BUDDHA muller pop_dens A1_30_00 if year==1965, r
eststo: reg gr00 g65 lnd100km LIFEE060 CONFUC Mining YrsOpen MUSLIM BUDDHA muller pop_dens A1_30_00 if year==1965, r
eststo: reg gr00 g65 lnd100km LIFEE060 CONFUC Mining YrsOpen MUSLIM BUDDHA pop_dens A1_30_00 if year==1965, r
eststo: reg gr00 g65 lnd100km LIFEE060 CONFUC YrsOpen MUSLIM BUDDHA pop_dens A1_30_00 if year==1965, r
eststo: reg gr00 g65 lnd100km LIFEE060 CONFUC YrsOpen MUSLIM BUDDHA A1_30_00 if year==1965, r
eststo: reg gr00 g65 LIFEE060 CONFUC YrsOpen MUSLIM BUDDHA A1_30_00 if year==1965, r
esttab using "$path_in\written\Table_D_2.tex",  b(3) prehead("Dependant variable: & \multicolumn{11}{c}{growth rate 1962-2000 }  \\[1em]") ///
booktab fragment label star(* 0.10 ** 0.05 *** 0.01) p replace nogap nomtitle ///
stats(N r2, fmt(0 3) layout("\multicolumn{1}{c}{@}" ) labels(`"Obs."' `"\$R^{2}$"')) //Table A.14 in the text.


*4.1.4 Same exercise but using nominal income since that's what I have in the model
*To compute nominal income I multiply y (real GDP at current prices in PWT7.1) times p (current price level for GDP in PWT7.1)
g lnominc=log(p*y)
sort country year
g aux1=lnominc if year==1965
bys country: egen nomg65=mean(aux1)
g aux2=lnominc if year==2000
bys country: egen nomg00=mean(aux2)
g aux3=lnominc if year==2010
bys country: egen nomg10=mean(aux3)
g nomgr00=nomg00-nomg65
g nomgr10=nomg10-nomg65
label var lnominc "Nominal GDPpc (log)"

*I start with full set of vars (including Ad) and remove non-signifficant vars one by one I get:
eststo clear
eststo: reg nomgr00 enr6272 pi lnominc lnd100km dens65c Mal66a LIFEE060 CONFUC Mining YrsOpen MUSLIM BUDDHA muller gov_C pop_dens RERD A1_30_00 if year==1965, r
eststo: reg nomgr00 enr6272 pi lnominc lnd100km dens65c Mal66a LIFEE060 CONFUC Mining YrsOpen MUSLIM BUDDHA muller pop_dens RERD A1_30_00 if year==1965, r
eststo: reg nomgr00 enr6272 pi lnominc lnd100km dens65c Mal66a LIFEE060 CONFUC Mining YrsOpen MUSLIM BUDDHA muller pop_dens A1_30_00 if year==1965, r
eststo: reg nomgr00 pi lnominc lnd100km dens65c Mal66a LIFEE060 CONFUC Mining YrsOpen MUSLIM BUDDHA muller pop_dens A1_30_00 if year==1965, r
eststo: reg nomgr00 pi lnominc lnd100km dens65c Mal66a LIFEE060 CONFUC Mining YrsOpen MUSLIM muller pop_dens A1_30_00 if year==1965, r
eststo: reg nomgr00 pi lnominc lnd100km dens65c Mal66a LIFEE060 CONFUC YrsOpen MUSLIM muller pop_dens A1_30_00 if year==1965, r
eststo: reg nomgr00 pi lnominc lnd100km dens65c Mal66a LIFEE060 CONFUC YrsOpen MUSLIM pop_dens A1_30_00 if year==1965, r
eststo: reg nomgr00 pi lnominc lnd100km dens65c LIFEE060 CONFUC YrsOpen MUSLIM pop_dens A1_30_00 if year==1965, r
eststo: reg nomgr00 lnominc lnd100km dens65c LIFEE060 CONFUC YrsOpen MUSLIM pop_dens A1_30_00 if year==1965, r
eststo: reg nomgr00 lnominc lnd100km dens65c LIFEE060 CONFUC YrsOpen pop_dens A1_30_00 if year==1965, r
eststo: reg nomgr00 lnominc dens65c LIFEE060 CONFUC YrsOpen pop_dens A1_30_00 if year==1965, r
esttab using "$path_in\written\Table_D_2_NOM.tex",  b(3) prehead("Dependant variable: & \multicolumn{11}{c}{growth rate 1962-2000 }  \\[1em]") ///
booktab fragment label star(* 0.10 ** 0.05 *** 0.01) p replace nogap nomtitle ///
stats(N r2, fmt(0 3) layout("\multicolumn{1}{c}{@}" ) labels(`"Obs."' `"\$R^{2}$"'))  //Table A.15 in the text.



*5.Robustness checks

	*5.1-If I replace all geographical dummies (east_asia safrica laam) for Adummies I get:
	
forvalues i=1(1)3{
forvalues j=30(10)50{
local a1="`i'_`j'"
local a2="`i'_`j'end"
forvalues k=1(1)2 {
reg gr00 enr6272 pi g65 dens65c LIFEE060 Mining YrsOpen muller gov_C pop_dens RERD A`a`k'' if year==1965, r
*In ALL specifications A dummies are negative and signifficant
}
}
}


*6-Runs probit to characterize A-countries

import delimited "$pc\data\WDI\WDI2015\WDI_Data.csv", varnames(1) clear
keep if indicatorcode=="AG.LND.AGRI.ZS" | indicatorcode=="AG.LND.ARBL.ZS" | indicatorcode=="EA.PRD.AGRI.KD" | indicatorcode=="SE.ADT.1524.LT.ZS" /*
*/ | indicatorcode=="SE.ADT.LITR.ZS" | indicatorcode=="SE.XPD.TOTL.GD.ZS"  | indicatorcode=="AG.LND.AGRI.K2" | indicatorcode=="AG.LND.ARBL.HA.PC" /*
*/ | indicatorcode=="AG.LND.ARBL.HA"

forvalues y=5(1)59{
local j=`y'+1955
rename v`y' year_`j'
}
drop indicatorname
rename countrycode country_isocode
reshape long year_ , i(indicatorcode country_isocode countryname) j(year)

g aux=year_  if  indicatorcode=="AG.LND.AGRI.ZS"
bys country_iso year: egen agric= max(aux)
label var agric "Agricultural land (% of land area)"
drop aux
g aux=year_  if  indicatorcode=="AG.LND.AGRI.K2"
bys country_iso year: egen agricT= max(aux)
label var agricT "Agricultural land (sq. km)"
drop aux
g aux=year_  if  indicatorcode=="AG.LND.ARBL.ZS"
bys country_iso year: egen arable= max(aux)
label var arable "Arable land (% of land area)"
drop aux
g aux=year_  if  indicatorcode=="AG.LND.ARBL.HA.PC"
bys country_iso year: egen arablePP= max(aux)
label var arablePP "Arable land (hectares per person)"
drop aux
g aux=year_  if  indicatorcode=="AG.LND.ARBL.HA"
bys country_iso year: egen arableT= max(aux)
label var arableT "Arable land (hectares)"
drop aux
g aux=year_  if  indicatorcode=="EA.PRD.AGRI.KD"
bys country_iso year: egen agVA= max(aux)
label var agVA "Agriculture value added per worker (constant 2005 US$)"
drop aux
g aux=year_  if  indicatorcode=="SE.ADT.1524.LT.ZS"
bys country_iso year: egen lityouth= max(aux)
label var lityouth "Literacy rate, youth total (% of people ages 15-24)"
drop aux
g aux=year_  if  indicatorcode=="SE.ADT.LITR.ZS"
bys country_iso year: egen litadult= max(aux)
label var litadult "Literacy rate, adult total (% of people ages 15 and above)"
drop aux
g aux=year_  if  indicatorcode=="ASE.XPD.TOTL.GD.ZS"
bys country_iso year: egen GovEd= max(aux)
label var GovEd "Government expenditure on education, total (% of GDP)"
drop aux

drop indicatorcode year_ countryname v60
sort country_iso year
drop if country_iso==country_iso[_n-1] & year==year[_n-1]
rename country_iso country
sort country year
saveold "$pc\data\WDI\WDI2015\WDI2015vars.dta", replace

u "$path_out\Divergence.dta", clear
sort country year
merge country year using "$pc\data\WDI\WDI2015\WDI2015vars.dta"
drop _merge
*erase "$pc\data\WDI\WDI2015\WDI2015vars.dta"

g aux=enrollment if year>=1962 & year<=1972
bys country: egen enr6272=mean(aux)
drop aux
g lrgdpl=log(rgdpl)
global varlist="openk pop_dens arable arableT lrgdpl gov_C"

label var openk "Trade openness"
label var pop_dens "Pop. density"
label var lrgdpl "GDPpc (logs)"
label var gov_C "Gov. expenditure"
label var A1 "exports in A1 (\%)"
label var A2 "exports in A2 (\%)"
label var A3 "exports in A3 (\%)"
label var arable "Arable land (\% of land)"
label var arableT "Arable land (total)"

eststo clear
forvalues k=1(1)3{
forvalues j=30(10)50{
eststo: probit A`k'_`j'end A`k' $varlist if year==1965, r
}
}
esttab using "$path_in\written\Table_D_Prob.tex",  b(3) ///
prehead("Dependant variable: & \multicolumn{9}{c}{Dummy for exporting A\$k>j$\% in 2000} \\ $[k,j]=$ & $[1,30]$ & $[1,40]$ & $[1,50]$ & $[2,30]$ & $[2,40]$ & $[2,50]$ & $[3,30]$ & $[3,40]$ & $[3,50]$ \\") ///
booktab fragment label star(* 0.10 ** 0.05 *** 0.01) p replace nogap nomtitle o(A*) ///
stats(N r2_p, fmt(0 3) layout("\multicolumn{1}{c}{@}" ) labels(`"Obs."' `"Pseudo-\$R^{2}$"')) //Table A.2 in the text.




