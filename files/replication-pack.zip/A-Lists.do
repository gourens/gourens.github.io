****************
*LIST OF A-GOODS
****************
/*This do file creates variables classifying goods in our different lists: A1-A3 and E (A4).
Different classifications have different partitions of products into bins so our do file requires
the specification of the clasiffication to be listed.*/

if "$class"=="SITCR2-4d" {

	qui g aux1= substr(good,1,2)
	forvalues o=0(1)9{
		qui drop if aux1=="`o'A" | aux1=="`o'X"
	}
	qui destring aux1, replace
	g aux2=substr(good,1,3)
	
	qui g a1=1 if (aux1<=26 & aux2!="233") | aux2=="271" | aux1==29 | (aux1>=41 & aux1<=49)
	qui g a2=1 if a1==1 | aux1==51 | aux1==56
	qui g a3=1 if a2==1 | aux1==61 | aux1==63 | aux1==64
	qui g a4=1 if aux2=="233" | (aux1==27 & aux2!="271") | aux1==28 | (aux1>=31 & aux1<=39) | aux1==52  ///
	| aux2=="661" | aux2=="667"  | aux2=="671"  | aux2=="672" | aux1==68 //Extractive
}

if "$class"=="SITCR2-4dDestring" {
	qui g a1=1 if good<2330 | (good>2339 & good<=2699) | (good>=2710 & good<=2719) | (good>=2900 & good<=2999) | (good>=4100 & good<=4999)
	qui g a2=1 if a1==1 | (good>=5100 & good<=5199) | (good>=5600 & good<=5699)
	qui g a3=1 if a2==1 | (good>=6100 & good<=6599)
	qui g a4=1 if (good>=2330 & good<=2339) | (good>=2720 & good<=2899) | (good>=3100 & good<=3999) | (good>=5200 & good<=5299) ///
	| (good>=6610 & good<=6619) | (good>=6670 & good<=6679) | (good>=6720 & good<=6729) | (good>=6800 & good<=6899) //Extractive
}

if "$class"=="SITCR1-5d" {
	qui g a1=1 if good<23120 | (good>=24000 & good<27300) | (good>=29000 & good<30000) | (good>=40000 & good<50000)
	qui g a2=1 if a1==1 | (good>=51200 & good<51300) | (good>=56000 & good<57000) | (good>=59951 & good<59990)
	qui g a3=1 if a2==1 | (good>=61000 & good<66000)
	qui g a4=1 if (good>=23120 & good<24000) | (good>=27300 & good<29000) | (good>=32000 & good<40000) | (good>=52000 & good<53000) ///
	| (good>=66100 & good<66200) | (good>=66700 & good<66800) | (good>=67200 & good<67300) | (good>=68000 & good<69000) //Extractive
}

if "$class"=="HS0-6d" {
	qui g a1=1 if hs6<250000 | hs6==310100 | hs6==310250 | hs6==310410 | (hs6>=410110 & hs6<=410390) | hs6==411000 ///
	| (hs6>=430110 & hs6<=430190) | (hs6>=440110 & hs6<=440399) | (hs6>=440610 & hs6<=440799) | (hs6>=440910 & hs6<=440920) ///
	| (hs6>=450110 & hs6<=450200) | (hs6>=470100 & hs6<=470790) | (hs6>=500100 & hs6<=500390) | (hs6>=510111 & hs6<=510521) /// 
	| (hs6>=510530 & hs6<=510540) | (hs6>=520100 & hs6<=520300) | (hs6>=530110 & hs6<=530599) | (hs6>=550110 & hs6<=550700) ///
	| (hs6>=630900 & hs6<=631090)
	qui g a2=1 if a1==1 | (hs6>=290000 & hs6<320000)
	qui g a3=1 if a2==1 | (hs6>=400510 & hs6<=401490) | (hs6>=401610 & hs6<=401700) | (hs6>=410410 & hs6<=420100) ///
	| hs6==420400 | hs6==420500 | (hs6>=430211 & hs6<=430230) | (hs6>=440410 & hs6<=460199) | (hs6>=480210 & hs6<=482090) ///
	| (hs6>=482210 & hs6<=482390) | (hs6>=500400 & hs6<=600299) | (hs6>=630120 & hs6<=630800)  | (hs6>=640610 & hs6<=650200) ///
	| (hs6>=680100 & hs6<690000)
	qui g a4=1 if (hs6>=250000 & hs6<290000) | (hs6>=240300 & hs6<=340400) | hs6==381600 | (hs6>=720110 & hs6<=722860) ///
	| (hs6>=750110 & hs6<750512) | (hs6>=760110 & hs6<760429) | (hs6>=780110 & hs6<780200) | (hs6>=790111 & hs6<790200) ///
	| (hs6>=800110 & hs6<800200) | (hs6>=810110 & hs6<810191) | (hs6>=810210 & hs6<810291) | hs6==810310 | (hs6>=810411 & hs6<810420) ///
	 | hs6==810510 | hs6==810710 | hs6==810810 | hs6==810910 | hs6==811211 | hs6==811291 //Extractive
}


if "$class"=="NACER2" {
	qui gen length = length(nace_r2)
	qui drop if length!=3
	qui g a0= substr(nace_r2,1,1)
	qui g a1=1 if nace_r2=="C10" | nace_r2=="C11" | nace_r2=="C12"
	qui g a2=1 if a1==1 | nace_r2=="C20"
	qui g a3=1 if a2==1 | nace_r2=="C15" | nace_r2=="C16" | nace_r2=="C17" | nace_r2=="C31"
	qui g a4=1 if a0=="B" | nace_r2=="C19" | nace_r2=="C22" | nace_r2=="C23" | nace_r2=="C24"  //Extractive
	qui g a5=1 if nace_r2=="C33" | nace_r2=="CRA" | a0=="D" | a0=="E" | a0=="F" | a0=="G" | a0=="H" | a0=="I" | a0=="J" | a0=="K" ///
	| a0=="L" | a0=="M" | a0=="N" | a0=="P" | a0=="S" | a0=="T"  //Services
}

if "$class"=="NAICS97" {
	qui g a0= substr(naics97,1,1)
	destring naics97, replace
	destring a0, replace
	qui g a1=1 if (a0==1 & naics97!=115210 & naics97!=115310) | (naics97>=311813 & naics97<=312229) | naics97==321211 | naics97==321212 ///
	 | naics97==322110 | naics97==322121
	qui g a2=1 if a1==1 | (naics97>=325193 & naics97<=325199) | (naics97>=325311 & naics97<=325412) | naics97==325414
	qui g a3=1 if a2==1 | (naics97>=311211 & naics97<=311615) | naics97==311712 | (naics97>=313111 & naics97<=315192) | (naics97>=315212 & naics97<=321113) ///
	 | naics97==321219 | (naics97>=322122 & naics97<=322299) | (naics97>=325211 & naics97<=325412) | naics97==325414 | (naics97>=326140 & naics97<=326199) ///
	 | (naics97>=326220 & naics97<=326299)
	qui g a4=1 if (naics97>=211111 & naics97<=213111) | (naics97>=324121 & naics97<=324199) | naics97==331491 | naics97==331511 | ///
	naics97==331513 | naics97==331525 | naics97==331528  //Extractive
	qui g a5=1 if naics97==115210 | naics97==115310 | (naics97>=213112 & naics97<=235990) | naics97==311711 | (naics97>=311811 & naics97<=311812) ///
	| naics97==315211 | naics97==321114 | (naics97>=421110 & naics97<=928120) //Services
}

if "$class"=="NAICS12" {
	qui g a0= substr(naics12,1,1)
	destring naics12, replace
	destring a0, replace
	qui g a1=1 if (a0==1 & naics12!=115210 & naics12!=115310) | (naics12>=311813 & naics12<=312230) | naics12==321211 | naics12==321212 ///
	 | naics12==322110 | naics12==322121
	qui g a2=1 if a1==1 | (naics12>=325193 & naics12<=325199) | (naics12>=325311 & naics12<=325412) | naics12==325414
	qui g a3=1 if a2==1 | (naics12>=311211 & naics12<=311615) | (naics12>=313110 & naics12<=315190) | (naics12>=315220 & naics12<=321113) ///
	 | naics12==321219 | (naics12>=322130 & naics12<=322299) | (naics12>=325211 & naics12<=325212) | (naics12>=326140 & naics12<=326199) ///
	 | (naics12>=326220 & naics12<=326299)
	qui g a4=1 if (naics12>=211111 & naics12<=213111) | (naics12>=324110 & naics12<=324199) | naics12==331491 | naics12==331511 | ///
	naics12==331513 | naics12==331529  //Extractive
	qui g a5=1 if (naics12==115210 | naics12==115310) | (naics12>=213112 & naics12<=238990) | (naics12>=311710 & naics12<=311812) ///
	| naics12==315210 | naics12==321114 | (naics12>=423110 & naics12<=928120) //Services
}

if "$class"=="SIC4" {
	qui g a0= substr(sic4,1,1)
	destring sic4, replace
	destring a0, replace
	qui g a1=1 if (sic4>=111 & sic4<=724) | (sic4>=912 & sic4<=971) | (sic4>=2011 & sic4<=2141) | sic4==2411 | sic4==2611 ///
	| (sic4>=3111 & sic4<=3131)
	qui g a2=1 if a1==1 | sic4==2813 | sic4==2833 | sic4==2834 | sic4==2836 | sic4==2861 | sic4==2865 | (sic4>=2869 & sic4<=2879)
	qui g a3=1 if a2==1 | (sic4>=2211 & sic4<=2399) | (sic4>=2421 & sic4<=2429) | (sic4>=2435 & sic4<=2436) | (sic4>=2621 & sic4<=2676) ///
	| sic4==2679  | (sic4>=3021 & sic4<=3052) | (sic4>=3061 & sic4<=3069) | (sic4>=3142 & sic4<=3161) | (sic4>=3172 & sic4<=3199)
	qui g a4=1 if (sic4>=1011 & sic4<=1044) | (sic4>=1094 & sic4<=1231) | (sic4>=1311 & sic4<=1321) | (sic4>=1411 & sic4<=1475) ///
	| sic4==1499 | (sic4>=2911 & sic4<=2999) | sic4==3312 | sic4==3321 | sic4==3322 | (sic4>=3325 & sic4<=3339) | (sic4>=3351 & sic4<=3357) ///
	| sic4==3365 //Extractive
	qui g a5=1 if (sic4>=741 & sic4<=851) | sic4==1081 | sic4==1241 | (sic4>=1381 & sic4<=1389) | sic4==1481 | (sic4>=1521 & sic4<=1799) ///
	| sic4==2789 | sic4==2791 | (sic4>=4011 & sic4<=9711) //Services
}
