/********************
QUANTITATIVE RESULTS
********************
This do file uses as input the equilibrium results from 7.Quant_model.m and produces the exhibits in Section 6.3 of the paper.
 */

version 8
set scheme s2color //general look for Figures

use "$path_in\A.dta", clear
keep country_isocode A1_30_00 A4_30_00
duplicates drop
g class="M"
replace class="A" if A1_30_00==1
replace class="E" if A4_30_00==1
keep country class
sort country
saveold "$path_in\class_aux.dta", replace


*Terms of trade results
***********************
import excel "$path_in\TTresults.xlsx", sheet("Sheet1") clear
g num=_n
g dTTmodel_full=(B-A)/abs(A)  //%change in index with base 1=1984
g slopeTT_full=(B-A)/16
drop A B
sort num
saveold "$path_in\TTresults_aux.dta", replace

import excel "$path_in\TTresults_noExt.xlsx", sheet("Sheet1") clear
g num=_n
g dTTmodel_noExt=(B-A)/abs(A)  //change in index with base 1=1984
g slopeTT_noExt=(B-A)/16
drop A B
sort num
merge 1:1 num using "$path_in\TTresults_aux.dta", keep(3) nogen
sort num
merge 1:1 num using "$path_out/countries_quant_fix.dta", keep(3) nogen
order num
rename country country_isocode
sort country
merge m:1 country_iso using "$path_in/TTdata.dta", keep(3) nogen
sort country
merge 1:1 country_iso using "$path_out/class_aux.dta", keep(3) nogen
keep country class slope* dTT*
order country_iso class dTT* slopeTT slopeTT_full
rename slopeTT slopeTTdata

foreach k in full noExt{
g gap_`k'=abs(slopeTTdata-slopeTT_`k')
}
g same_side=((slopeTTdata<slopeTT_full & slopeTTdata<slopeTT_noExt) | (slopeTTdata>slopeTT_full & slopeTTdata>slopeTT_noExt))
 //=0 when full and noExt are at opposite sides of data. In these cases the contribution of Ext is always positive

g contrExt=abs((slopeTT_full-slopeTT_noExt)/gap_noExt) //size of contribution of Ext to close the gap between NoExt and data
replace contrExt=-contrExt if gap_full>gap_noExt & same_side==1
drop gap* same
sort class country_iso
saveold "$path_out/Table_quant_TT.dta", replace
drop if class=="E"
format dTTdata-contrExt %9.3f
export excel using "$path_out/Table_quant_TT", firstrow(variables) replace //35 countries. Table A.20 in the text.

graph bar contrExt, over(country, sort(1)) bargap(15) horizontal ytitle("") ///
graphr(color(white) ilcolor(white) fcolor(white) ifcolor(white) margin(medium)) ///
plotr(icolor(white) ilcolor(white) fcolor(white) ifcolor(white) margin(small)) ///
graphregion(margin(l+3 r+3))
graph display, xsize(15) ysize(20)
graph export "$pc\\Figure_TT_Ext_Contr.pdf", replace //Figure 8 in the text.

sum contrExt //mean=43.4

preserve
drop if dTTmodel_full>10 | dTTmodel_full<-10
twoway scatter dTTmodel_full dTTdata, mlabel(country) m(none) mlabp(0) mlabc(black) ///
|| line dTTdata dTTdata , legend(off) ///
xtitle("% Change TT (data)") ytitle("% Change TT (model)") ///
graphr(color(white) ilcolor(white) fcolor(white) ifcolor(white) margin(medium))  ///
plotr(icolor(white) ilcolor(white) fcolor(white) ifcolor(white) margin(small))
graph2tex, epsfile("$pc\\ModelTT") //Figure 6b in the text.
restore

u "$path_out\TT_wdi.dta", clear
drop if nbtti==. | year<1984 | year>2000
bys country: g count=_N
drop if count<10
g t=year-1983
egen id=group(country)
g slopeTT=.
g nbtti_hat=.
forvalues i=1(1)82{
reg nbtti t if id==`i', r
predict nbtti_hat`i'
matrix i`i'=e(b)
g slopeTT`i'=i`i'[1,1]
replace slopeTT=slopeTT`i' if id==`i'
replace nbtti_hat=nbtti_hat`i' if id==`i'
drop slopeTT`i' nbtti_hat`i'
}
rename country country_isocode
sort country_iso
merge m:1 country_iso using "$path_out/Table_quant_TT.dta", keep(3) nogen
label var nbtti "TT data"

foreach c in ARG SEN TGO CHN TUR USA {
preserve
keep if country=="`c'"
sum nbtti_hat if year==1992
scalar point=r(mean)

sum slopeTT_full
scalar slope_full=r(mean)
scalar b_full=point-slope_full*1992
g trend_model_full=slope_full*year+b_full
label var trend_model_full "Full model"

sum slopeTT_noExt
scalar slope_noExt=r(mean)
scalar b_noExt=point-slope_noExt*1992
g trend_model_noExt=slope_noExt*year+b_noExt
label var trend_model_noExt "No Extensive"

twoway scatter nbtti year, mc(gray) || lfit nbtti year, lc(black) lw(thick) || line trend_model_full year, lc(green) lw(medthick) || line trend_model_noExt year, lc(green) lw(medthick) lp(dash) xtitle("Year") ytitle("TTc") ///
graphr(color(white) ilcolor(white) fcolor(white) ifcolor(white) margin(medium))  ///
plotr(icolor(white) ilcolor(white) fcolor(white) ifcolor(white) margin(small))
graph export "$pc\Figure_TTQuant_`c'.eps", as(eps) replace //Figure 7 in the text.
restore
}

*Export results
**************
u "$path_out/countries_quant_fix.dta", clear
sort country
saveold "$path_in\countries_quant_fix_sort.dta", replace

forvalues p=84(16)100 {
	qui if "`p'"!="100" local y="`p'"
	qui if "`p'"=="100" local y="00"
	qui u "$pc\data/trade/Feenstra/wtf`y'.dta", clear
	qui drop if exporter=="World" | importer=="World"
	qui rename exporter country_feenstra
	qui sort country_feenstra
	qui merge country_feenstra using "$pc/country compatibility.dta"	// ads isocodes
	qui drop if _merge!=3
	qui rename (country_isocode sitc4) (country good)
	qui drop if country==""
	qui global class="SITCR2-4d"
	qui do "$path_do\A-Lists.do" // goods classification
	qui g valueA=value if a1==1
	qui g valueM=value if a1!=1 & a4!=1
	qui collapse (sum) valueA valueM, by(country)
	qui local j=`p'+1900
	qui g year=`j'
	merge 1:1 country year using "$path_out/wdi_aux_erase.dta", nogen keep(3)
	g val`y'=(valueA+valueM)/(yc*Lc)
	qui sort country
	qui saveold "$path_out/Aux_`j'.dta", replace
}
u "$path_out/Aux_1984.dta", clear
merge 1:1 country using "$path_out/Aux_2000.dta", nogen keep(3)
g dXdata=(val00/val84)/abs(val84)  //%change in index with base 1=1984
keep country d
sort country
merge 1:1 country using "$path_in\countries_quant_fix_sort.dta", nogen keep(3)
sort num
saveold "$path_in\export_data.dta", replace
erase "$path_out/Aux_1984.dta"
erase "$path_out/Aux_2000.dta"
erase "$path_in\countries_quant_fix_sort.dta"

import excel "$path_in\yc.xlsx", sheet("Sheet1") clear
rename (A B) (yc84 yc00)
g num=_n
saveold "$path_in\yc_aux_erase.dta", replace
import excel "$path_in\Lc.xlsx", sheet("Sheet1") clear
rename (A B) (Lc84 Lc00)
g num=_n
merge 1:1 num using "$path_in\yc_aux_erase.dta", nogen keep(3)
g Yc84=yc84*Lc84
g Yc00=yc00*Lc00
keep num Yc*
sort num
saveold "$path_in\Yc_erase_aux.dta", replace

import excel "$path_in\export_results.xlsx", sheet("Sheet1") clear
g num=_n
merge 1:1 num using "$path_in\Yc_erase_aux.dta", nogen keep(3)
g Xmodel84=(A+C)/Yc84
g Xmodel00=(B+D)/Yc00
g dXmodel_full=(Xmodel00-Xmodel84)/abs(Xmodel84)  //%change in index with base 1=1984
g slopeX_full=(Xmodel00-Xmodel84)/16
drop A B C D Yc*
sort num
merge 1:1 num using "$path_in\export_data.dta", keep(3) nogen
rename country country_isocode
merge 1:1 country_iso using "$path_out/class_aux.dta", keep(3) nogen
drop if class=="E"

preserve
drop if dXmodel_full<-0.01 | dXmodel_full>.05 | dXdata>.05
twoway scatter dXmodel_full dXdata, mlabel(country) m(none) mlabp(0) mlabc(black) ///
|| line dXdata dXdata, legend(off) ///
xtitle("% Change X/GDP (data)") ytitle("% Change X/GDP (model)") ///
graphr(color(white) ilcolor(white) fcolor(white) ifcolor(white) margin(medium))  ///
plotr(icolor(white) ilcolor(white) fcolor(white) ifcolor(white) margin(small))
graph2tex, epsfile("$pc\\Model_X_Y_zoom") //Figure 6.a in the text.
restore
saveold "$path_in\export_results_aux.dta", replace


erase "$path_in\yc_aux_erase.dta"
erase "$path_in\Yc_erase_aux.dta"


*Alpha results
**************
import excel "$path_in\alpha_results.xlsx", sheet("Sheet1") clear
g num=_n
g slopeAlphaA_full=(B-A)/16
drop A B
sort num
saveold "$path_in\alpha_results_aux.dta", replace

import excel "$path_in\alpha_results_noExt.xlsx", sheet("Sheet1") clear
g num=_n
g slopeAlphaA_noExt=(B-A)/16
drop A B
sort num
saveold "$path_in\alpha_results_aux_noExt.dta", replace

import excel "$path_in\alpha_results_noHom.xlsx", sheet("Sheet1") clear
g num=_n
g slopeAlphaA_noHom=(B-A)/16
drop A B
sort num
merge 1:1 num using "$path_in\alpha_results_aux.dta", keep(3) nogen
sort num
merge 1:1 num using "$path_in\alpha_results_aux_noExt.dta", keep(3) nogen
sort num
merge 1:1 num using "$path_out/countries_quant_fix.dta", keep(3) nogen
drop num
sort country
saveold "$path_in\alpha_results_Tot.dta", replace

*All years available
u "$path_out\Expenditure_Panel_final.dta", clear
drop if country=="USA"
rename FoodShare AgriShare
append using "$path_out\auxUSA.dta"

keep country year AgriShare 
bys country: egen iniyear=min(year)
bys country: egen endyear=max(year)
egen id=group(country) //29 countries

g slopeAlphaA_data=.
forvalues i=1(1)29{
reg AgriShare year if id==`i', r
matrix i`i'=e(b)
g slopeAlphaA_`i'=i`i'[1,1]
replace slopeAlphaA_data=slopeAlphaA_`i' if id==`i'
}
collapse (mean) slopeAlphaA_data, by(country iniyear endyear)
rename country country
sort country //29 countries
merge 1:1 country using "$path_in\alpha_results_Tot.dta", keep(3) nogen //20 countries
order country ini end slopeAlphaA_data slopeAlphaA_full


foreach k in full noExt noHom {
g gap_`k'=abs(slopeAlphaA_data-slopeAlphaA_`k')
}
g same_side_noExt=((slopeAlphaA_data<slopeAlphaA_full & slopeAlphaA_data<slopeAlphaA_noExt) | (slopeAlphaA_data>slopeAlphaA_full & slopeAlphaA_data>slopeAlphaA_noExt))
 //=0 when full and noExt are at opposite sides of data. In these cases the contribution of Ext is always positive
g contrExt=abs((slopeAlphaA_full-slopeAlphaA_noExt)/gap_noExt) //size of contribution of Ext to close the gap between NoExt and data
replace contrExt=-contrExt if gap_full>gap_noExt & same_side_noExt==1
 
g same_side_noHom=((slopeAlphaA_data<slopeAlphaA_full & slopeAlphaA_data<slopeAlphaA_noHom) | (slopeAlphaA_data>slopeAlphaA_full & slopeAlphaA_data>slopeAlphaA_noHom))
g contr_noHom=abs((slopeAlphaA_full-slopeAlphaA_noHom)/gap_noHom) //size of contribution of noHom to close the gap between NoHom and data
replace contr_noHom=-contr_noHom if gap_full>gap_noHom & same_side_noHom==1
sort country
gen strini = string(ini)
gen strend = string(end)
gen period = strini + "-" + strend
order country period slope* contr_no contrExt
keep country period slop* cont*
export excel using "$path_out/Table_quant_AlphaA", firstrow(variables) replace //Table A.21 in the text.

graph bar contrExt, over(country) bargap(15) horizontal ytitle("") ///
graphr(color(white) ilcolor(white) fcolor(white) ifcolor(white) margin(medium)) ///
plotr(icolor(white) ilcolor(white) fcolor(white) ifcolor(white) margin(small))
graph export "$pc\\Figure_alpha_Ext_Contr.pdf", replace //Figure 9.a in the text.

sum contrExt //mean=0.38

graph bar contr_noHom, over(country) bargap(15) horizontal ytitle("") ///
graphr(color(white) ilcolor(white) fcolor(white) ifcolor(white) margin(medium)) ///
plotr(icolor(white) ilcolor(white) fcolor(white) ifcolor(white) margin(small))
graph export "$pc\\Figure_alpha_noHom_Contr.pdf", replace //Figure 9.b in the text.

sum contr_noHom //mean=0.64

*Welfare results
****************
import excel "$path_in\Wel_results.xlsx", sheet("Sheet1") clear
g num=_n
sort num
merge 1:1 num using "$path_out/countries_quant_fix.dta", keep(3) nogen
g auxA=A if country=="USA"
g auxB=B if country=="USA"
egen welUSini=mean(auxA)
egen welUSend=mean(auxB)
g relWelini=A/welUSini
g relWelend=B/welUSend
g dRWel=(relWelend-relWelini)/relWelini
keep country dRWel
sort country
saveold "$path_in\Wel_results_aux.dta", replace

import excel "$path_in\Wel_results_noExt.xlsx", sheet("Sheet1") clear
g num=_n
sort num
merge 1:1 num using "$path_out/countries_quant_fix.dta", keep(3) nogen
g auxA=A if country=="USA"
g auxB=B if country=="USA"
egen welUSini=mean(auxA)
egen welUSend=mean(auxB)
g relWelini=A/welUSini
g relWelend=B/welUSend
g dRWel_noExt=(relWelend-relWelini)/relWelini
keep country dRWel_noExt
sort country
merge 1:1 country using "$path_in\Wel_results_aux.dta", keep(3) nogen
rename country country_isocode
sort country
merge 1:1 country using "$path_in\class_aux.dta", keep(3) nogen
drop if class=="E"
sort class country

graph bar dRWel dRWel_noExt if class=="A", over(country, sort(1)) bargap(15) ///
horizontal legend(order(1 "Full model" 2 "No extensive")) ///
graphr(color(white) ilcolor(white) fcolor(white) ifcolor(white) margin(medium)) ///
plotr(icolor(white) ilcolor(white) fcolor(white) ifcolor(white) margin(small))
graph display, ysize(8) xsize(5)
graph export "$pc\\Figure_Wel_Quant_A.pdf", replace //Figure 10.a in the text.


graph bar dRWel dRWel_noExt if class=="M" & country!="USA", over(country, sort(1)) bargap(15) ///
horizontal legend(order(1 "Full model" 2 "No extensive")) ///
graphr(color(white) ilcolor(white) fcolor(white) ifcolor(white) margin(medium)) ///
plotr(icolor(white) ilcolor(white) fcolor(white) ifcolor(white) margin(small))
graph display, ysize(8) xsize(5)
graph export "$pc\\Figure_Wel_Quant_M.pdf", replace //Figure 10.b in the text.

