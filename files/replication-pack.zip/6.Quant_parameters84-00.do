/******************************
DATA FOR QUANTITATIVE EXERCISES
*******************************
This do file:
1-creates trade weights of each c'cp for cp
2-creates database (tau.dta) with bilateral measures of trade frictions that we call tau. These are estimated following Anderson, Larch and Yotov (2020EJ).
3-creates database (ns.dta) with the number of varieties exported by each country (straight from Products7.dta).
4-creates database (wdi_quant.dta) with aggregates relevant for c.
5-getting data ready for matlab use
All these are reported for years 1984 (first year with info on unit values), and 2000 (China enters WTO).
*/

version 8

******************************
*1-Weights of each c'cp for cp
******************************
forvalues p=84(16)100 {
	if "`p'"!="100" local y="`p'"
	if "`p'"=="100" local y="00"
	u "$path_in/data/trade/Feenstra/wtf`y'.dta", clear
	qui drop if exporter=="World"
	rename sitc4 good
	global class="SITCR2-4d"
	qui do "$path_do\A-Lists.do" // goods classification
	qui g valueA=value if a1==1
	qui g valueM=value if a1!=1 & a4!=1
	rename importer country_feenstra
	sort country_feenstra
	qui merge country_feenstra using "$path_in/country compatibility.dta"	// adds isocodes
	keep if _merge==3
	drop _merge
	rename country_isocode importer
	drop country_feenstra
	rename exporter country_feenstra
	sort country_feenstra
	qui merge country_feenstra using "$path_in/country compatibility.dta"	// adds isocodes
	keep if _merge==3
	drop _merge
	rename country_isocode exporter
	drop if exporter=="" | importer==""
	collapse (sum) valueA valueM value, by(importer exporter)
	qui bys  importer: egen MA=sum(valueA)
	qui bys  importer: egen MM=sum(valueM)
	qui bys  importer: egen Mtot=sum(value)
	qui g weightA=valueA/MA
	qui g weightM=valueM/MM
	qui g weighttot=value/Mtot
	keep importer exporter w*
	qui local j=`p'+1900
	sort importer exporter
	saveold "$path_out/weights_`j'.dta", replace
}
u "$path_out/weights_1984.dta", clear
g year=1984
append using "$path_out/weights_2000.dta"
replace year=2000 if year==.
drop if weightA==. | weightM==. | weighttot==.
sort importer exporter year
qui saveold "$path_out/weights.dta", replace

forvalues j=1984(16)2000 {
erase "$path_out/weights_`j'.dta"
}

*****************************************************************************************
*2-creates database (tau.dta) with bilateral measures of trade frictions that we call tau.
*****************************************************************************************
/*
We follow Anderson et al (2020, pages 23-25 WP version).

We want to capture the effect of an ij relationship, but there is an endogenous part because RTAs are endogenous. By estimating (29) the ij-FE absorves the endogenous part so we get a hat{eta1} that only captures the exogenous effect of the RTA (what we want).

Then we estimate (30) to remove the endogenous part from the ij-FE. All explanatory vars are "exogenous" so the endogenous part goes to the error term. The predicted values of the ij-FE that we obtain from estimating (30) are net of the endogenous part.

Then (32) builds the proper ij effect by adding up the exogenous RTA effect to the exogenous part of the ij-FE. */

*First we compute tau for any c c' in industries A and M
u "$path_in/data/trade/Gravity CEPII\v2021\Gravity_V202102.dta", clear
*create distance intervals
g dist1=dist
replace dist1=2999 if dist>3000
g dist2=dist
replace dist2=6999 if dist>7000
replace dist2=0 if dist<=3000
g dist3=dist
replace dist3=9999 if dist>10000
replace dist3=0 if dist<=7000
g dist4=dist
replace dist4=0 if dist<10000
forvalues i=1(1)4{
g ldist`i'=log(dist`i'+1)
}
keep year iso3_o iso3_d ldist* rta comlang_off comcol contig
sort iso3_o iso3_d year
saveold "$path_out/gravity.dta", replace

*Feenstra (1962-2000)
forvalues p=75(1)100 {
	qui if "`p'"!="100" local y="`p'"
	qui if "`p'"=="100" local y="00"
	qui u "$path_in/data/trade/Feenstra/wtf`y'.dta", clear
	qui drop if exporter=="World" | importer=="World"
	qui rename importer country_feenstra
	qui sort country_feenstra
	qui merge country_feenstra using "$path_in/country compatibility.dta"	// ads isocodes
	qui drop if _merge!=3
	qui rename (country_isocode sitc4) (iso3_d good)
	qui drop country_feenstra _merge
	qui rename exporter country_feenstra
	qui sort country_feenstra
	qui merge country_feenstra using "$path_in/country compatibility.dta"	// ads isocodes
	qui drop if _merge!=3
	qui rename country_isocode iso3_o
	qui drop if iso3_o=="" | iso3_d==""
	qui global class="SITCR2-4d"
	qui do "$path_do\A-Lists.do" // goods classification
	qui g valueA=value if a1==1
	qui g valueM=value if a1!=1 & a4!=1
	qui collapse (sum) valueA valueM, by(iso3_o iso3_d year)
	qui sort iso3_o iso3_d year
	qui local j=`p'+1900
	qui saveold "$path_out/aux_`j'.dta", replace
}

*Build trade frictions at ijpt-level (tau)
forvalues p=1984(16)2000 {
	u "$path_out/aux_`p'.dta", clear
	forvalues k=1(1)9{
	local h=`p'-`k'
	append using "$path_out/aux_`h'.dta"
	}
	qui sort iso3_o iso3_d year
	qui merge iso3_o iso3_d year using "$path_out/gravity.dta"
	qui keep if _merge==3
	qui drop _merge
	egen Fit=group(iso3_o year)
	egen Fjt=group(iso3_d year)
	egen Fij=group(iso3_o iso3_d)
	scalar sigmaA=3.5
	scalar sigmaM=2.5
	foreach i in A M {
		ppmlhdfe value`i' rta, absorb(Fit Fjt Fij, savefe)	d
		mat b`i'=e(b)
		scalar eta`i'=b`i'[1,1]
		g expmuij`i'=exp(__hdfe3__)
		ppml expmuij`i' ldist1 ldist2 ldist3 ldist4 comlang_off comcol
		predict aux1`i'  //this is (t^noRTA)^{1-sigma}
		g double aux2`i'=exp(eta`i'*rta)
		g double tau`i'=(aux1`i'*aux2`i')^(1/(1-sigma`i'))+1
		}
	collapse (max) tau* year, by(iso3_o iso3_d)
	keep if year==`p' //not all obs are for year p
	qui if `p'!=1984 append using "$path_out/taus.dta"
	qui sort iso3_o iso3_d year
	qui saveold "$path_out/taus.dta", replace
}

mat drop _all
matrix A=J(2,11,.)
local k=1
forvalues y=1984(16)2000{
mat A[`k',1]=`y'
sum tauA if year==`y', d
mat A[`k',2]=r(mean)
mat A[`k',3]=r(p50)
mat A[`k',4]=r(sd)
mat A[`k',5]=r(min)
mat A[`k',6]=r(max)
sum tauM if year==`y', d
mat A[`k',7]=r(mean)
mat A[`k',8]=r(p50)
mat A[`k',9]=r(sd)
mat A[`k',10]=r(min)
mat A[`k',11]=r(max)
local k=`k'+1
}
matlist A

frmttable using "$path_in\\Table_taus_aux1", statmat(A) ///
 ctitles("" "mean" "median" "sd" "min" "max" "mean" "median" "sd" "min" "max") ///
sdec(0,3,3,3,3,3,3,3,3,3,3) replace tex plain fragment nocenter hline(0100) spacebef(0100)
filefilter "$path_in\\Table_taus_aux1.tex" "$path_in\\Table_taus_aux2.tex", from ("\BSbegin{tabular}{lcccccccc}" ) to ("year & \BSmulticolumn{5}{c}{$tau^A_{cc't}$}  & \BSmulticolumn{5}{c}{$tau^M_{cc't}$} \BS\BS") replace
filefilter "$path_in\\Table_taus_aux2.tex" "$path_in\\Table_taus.tex", from ("\BSend{tabular}\BS\BS") to ("") replace
forvalues i=1(1)2{
rm "$path_in\\Table_taus_aux`i'.tex"
} //Table A.19 in the text.


forvalues p=1975(1)2000 {
erase "$path_out/aux_`p'.dta"
}

*Aggregate trade frictions for cp with the rest of the world (each trade partner weighted by its importance in trade for cp).
u "$path_out/weights.dta", clear
rename exporter iso3_o
rename importer iso3_d
qui sort iso3_o iso3_d year
merge 1:1 iso3_o iso3_d year using "$path_out/taus.dta"
keep if _merge==3
g auxA=weightA*tauA
g auxM=weightM*tauM
collapse (sum) auxA auxM, by(iso3_d year)
rename auxA tauA
rename auxM tauM
bys iso: egen n=count(_n)
keep if n==2
drop n
rename iso3_d country
sort country year
qui saveold "$path_out/tau_aux.dta", replace
keep country
duplicates drop
sort country
qui saveold "$path_out/countries_quant_aux.dta", replace //140 countries


************************************************************************************************
*3-creates database (ns.dta) with the number of varieties exported and imported by each country.
************************************************************************************************
/*For the number of exporting varieties (nci) we use the count of codes (ignoring destination), while for the number of importing varieties (nfci) we do consider origin. This way the sum gives the total number of varieties available to consumers in c: Nci=nci+nfci.*/

use "$path_out\Products1.dta", clear
rename x1 ncA //# of goods exported to any destination by country c in industry A
rename M1 ncM
sort country
merge m:1 country using "$path_out/countries_quant_aux.dta"
keep if _merge==3 & (year==1984 | year==2000)
keep country year ncA ncM
sort country year
saveold "$path_out/ns_aux.dta", replace
bys country: egen n=count(_n)
keep if n==2
keep country
duplicates drop
qui saveold "$path_out/countries_quant_aux.dta", replace //140 countries


forvalues p=62(1)100 {
qui if "`p'"!="100" local x="`p'"
qui if "`p'"=="100" local x="00"
qui if "`p'"!="100" local y="19`p'"
qui if "`p'"=="100" local y="2000"
qui u "$pc\data\Trade\Feenstra\wtf`x'.dta", clear
	rename sitc4 good
	drop if exporter=="World" | importer=="World"
	qui rename importer country_feenstra
	qui sort country_feenstra
	qui merge country_feenstra using "$pc/country compatibility.dta"	// ads isocodes
	qui keep if _merge==3
	qui drop num exporter icode ecode unit dot value quantity country_comtrade  code_comtrade _merge
	qui rename country_isocode country
	qui drop if country==""
	global class="SITCR2-4d"
	qui do "$path_do\A-Lists.do" // goods classification

	bys country: g a5=_n
	bys country: egen tot=max(a5)
	forvalues i=1(1)4 {
		bys country: egen num`i'=sum(a`i')
	}
	forvalues i=1(1)3 {
		g den`i'=tot-num`i'-num4
	}
	forvalues i=1(1)3 {
		g r`i'=num`i'/den`i'
			label var r`i' "# of imported A`i' varieties (good-origin)"
	}

	bys country year: g a6=_n
	keep if a6==1
	keep year country r* num* den*
	order country year
	sort country year
saveold "$path_out\erase4_`y'.dta", replace
}

forvalues y=2001(1)2014 {
import delimited "$pc\SITCR2_5d\type-C_r-ALL_ps-`y'.csv", clear
keep if tradeflow=="Import"
drop if partner=="World"
keep if agg==4
rename commoditycode good
rename partneriso country
drop if country=="" | good=="TOTAL"
	global class="SITCR2-4d"
	qui do "$path_do\A-Lists.do" // goods classification
	
	bys country: g a5=_n
	bys country: egen tot=max(a5)
	forvalues i=1(1)4 {
		bys country: egen num`i'=sum(a`i')
			label var num`i' "# of imported A`i' varieties (good-origin)"

	}
	forvalues i=1(1)3 {
		g den`i'=tot-num`i'-num4
	}
	forvalues i=1(1)3 {
		g r`i'=num`i'/den`i'
			label var r`i' "ratio of #A`i' varieties/ (#A`i' varieties + #M`i' varieties)"
	}
bys country year: g a6=_n
keep if a6==1
keep year country r* num* den*
drop rep*
order country year
sort country year
saveold "$path_out\erase4_`y'.dta", replace
}

forvalues y=1962(1)2014{
	qui if ("`y'"=="1962") u "$path_out/erase4_`y'.dta", clear
	qui if ("`y'"!="1962") append using "$path_out/erase4_`y'.dta"
	qui erase "$path_out\erase4_`y'.dta"
}
drop if country==""
sort country year
saveold "$path_out\Products4.dta", replace

use "$path_out\Products4.dta", clear
rename num1 nfcA //# of varieties (good-origin) imported by country c in industry A
g nfcM=den1-nfcA
sort country year
merge country year using "$path_out/ns_aux.dta"
keep if _merge==3 & (year==1984 | year==2000)
keep country year nfcA nfcM ncA ncM
sort country year
qui saveold "$path_out/ns_aux.dta", replace


***********************************************************
*4-Database (wdi_quant.dta) with aggregates relevant for c.
***********************************************************
wbopendata, indicator(NY.GDP.PCAP.PP.CD;SP.POP.TOTL;NE.CON.TOTL.ZS;SL.AGR.EMPL.ZS;SL.SRV.EMPL.ZS;SL.IND.EMPL.ZS;NV.AGR.TOTL.ZS;NV.IND.TOTL.ZS;NV.SRV.TOTL.ZS) long year(1984:2014) clear
drop countryname regionname adminregion adminregionname incomelevelname lendingtype lendingtypename
rename (countrycode ny_gdp_pcap_pp_cd sp_pop_totl ne_con_totl_zs sl_agr_empl_zs sl_srv_empl_zs sl_ind_empl_zs nv_agr_totl_zs nv_ind_totl_zs nv_srv_totl_zs)(country gdppc Lc Ec shLcA shLcS shLcM shYcA shYcM shYcS)
keep if year==1984 | year==1994 | year==2000 | year==2004 | year==2014
sort country
qui saveold "$path_out/wdi_aux2_erase.dta", replace

merge m:1 country using "$path_out/countries_quant_aux.dta", keep(3) nogen
drop region incomel* 

g auxyc84=gdppc if year==1984 //gdppcPPP missing in 1984 so we assume a it grew along with gdppc over the period 84-94.
g auxyc94=gdppc if year==1994
bys country: egen aux_y84=mean(auxyc84)
bys country: egen aux_y94=mean(auxyc94)
g changeyc=(aux_y94-aux_y84)/aux_y84
g aux84=gdppcPPP/(1+changeyc) if year==1994
bys country: egen auxy84=mean(aux84)
replace gdppcPPP=auxy84 if year==1984 & gdppcPPP==.
drop aux* chang
rename gdppcPPP yc
replace Lc=Lc/1000000 				//pop in millions
replace Ec=(Ec/100)*yc*Lc

foreach i in A M S { //shares are missing in 1994 so we assume a constant growth rate between 94-04 as that in 04-14.
g shYc`i'04=shYc`i' if year==2004
g shYc`i'14=shYc`i' if year==2014
bys country: egen sh`i't=mean(shYc`i'04)
bys country: egen sh`i't1=mean(shYc`i'14)
g change`i'=(sh`i't1-sh`i't)/sh`i't
g sh`i't_1=sh`i't/(1+change`i')
replace shYc`i'=sh`i't_1 if year==1994 & shYc`i'==.
drop sh`i'* ch* shYc`i'04 shYc`i'14
}

foreach i in A M S { //shares are missing in 1984 so we assume a constant growth rate between 84-94 as that in 94-04.
foreach j in shLc shYc {
replace `j'`i'=`j'`i'/100
g `j'`i'94=`j'`i' if year==1994
g `j'`i'04=`j'`i' if year==2004
bys country: egen sh`i't=mean(`j'`i'94)
bys country: egen sh`i't1=mean(`j'`i'04)
g change`i'=(sh`i't1-sh`i't)/sh`i't
g sh`i't_1=sh`i't/(1+change`i')
replace `j'`i'=sh`i't_1 if year==1984 & `j'`i'==.
drop sh`i'* ch* `j'`i'94 `j'`i'04
}
}
replace shYcA=max(0.00001,1-shYcM-shYcS) if shYcA==. & shYcM!=. & shYcS!=.
replace shYcM=max(0.00001,1-shYcA-shYcS) if shYcA!=. & shYcM==. & shYcS!=.
replace shYcS=max(0.00001,1-shYcA-shYcM) if shYcA!=. & shYcM!=. & shYcS==.

sort country year
qui saveold "$path_out/wdi_aux_erase.dta", replace

*For each country c we compute several vars for its corresponding Rest of the world (f) as the (trade) weighted avg of that var in all trading partners

u "$path_out/weights.dta", clear
rename exporter country
sort country year
merge m:1 country year using "$path_out/wdi_aux_erase.dta", keep(3) nogen
g wf=yc*weighttot/1000
g yf=yc*weighttot
g Lf=Lc*weighttot
g shLfA=shLcA*weighttot
g shLfM=shLcM*weighttot
g shYfA=shYcA*weighttot
g shYfM=shYcM*weighttot
collapse (sum) wf yf Lf shLfA shLfM shYfA shYfM, by(importer year)
rename importer country
sort country year
merge 1:1 country year using "$path_out/wdi_aux_erase.dta", keep(3) nogen
qui saveold "$path_out/wdi_aux_erase.dta", replace
drop if yc==. | Ec==. | shLcA==. | shLcM==. | shLcS==. | shYcA==. | shYcM==. | shYcS==.
bys country: egen n=count(_n)
keep if n==2
keep country
duplicates drop
g num=_n
sort country
saveold "$path_out/countries_quant.dta", replace   //98 countries

*************
*Filter out countries that don't run in matlab.
u "$path_out/countries_quant.dta", clear   //98 countries
drop if num==44 | num==76 | num==98 //no results in quant_model_new2.m
drop if num==19  //no results in quant_model_new2_noExt.m
drop if num==24 | num==43 | num==53  //no results in quant_model_new2_noHom.m

drop num 
g num=_n
sort country
saveold "$path_out/countries_quant_fix.dta", replace   //91 countries
*************


*******************************************************************************************************
*5-Getting data ready for Matlab use:
	*For all the data constructed above we make sure to keep obs for the 91 countries with complete info
	*Format final xslx file with countries are in rows and years in columns
*******************************************************************************************************
u "$path_out/ns_aux.dta", clear
sort country
merge m:1 country using "$path_out/countries_quant_fix.dta", keep(3) nogen
foreach i in nfcA nfcM ncA ncM {
preserve
keep year num `i'
reshape wide `i', i(num) j(year)
drop num
export excel "$path_out/`i'.xlsx", replace
restore
}
*erase "$path_out/ns_aux.dta"


u "$path_out/wdi_aux_erase.dta", clear
sort country
merge m:1 country using "$path_out/countries_quant_fix.dta", keep(3) nogen
foreach i in yc Lc Ec shLcA shLcS shLcM shYcA shYcM shYcS wf yf Lf shLfA shLfM shYfA shYfM {
preserve
keep year num `i'
reshape wide `i', i(num) j(year)
drop num
export excel "$path_out/`i'.xlsx", replace
restore
}
*erase "$path_out/wdi_aux_erase.dta"

u "$path_out/tau_aux.dta", clear
sort country
merge m:1 country using "$path_out/countries_quant_fix.dta", keep(3) nogen
foreach i in tauA tauM {
preserve
keep year num `i'
reshape wide `i', i(num) j(year)
drop num
export excel "$path_out/`i'.xlsx", replace
restore
}
*erase "$path_out/tau_aux.dta"