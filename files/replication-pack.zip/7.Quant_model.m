%urlwrite('https://git.io/matalterna.m', 'matalterna.m');
clear all

%Matrices to save results
TTresults = zeros(91, 2);
alpha_results = zeros(91, 2); 
Wel_results = zeros(91, 2); 
export_results = zeros(91, 4); 

% Parameters from literature
sigmaA = 3.5;       %Median values in Table 3 (estimations from Broda and Weinstein)
sigmaM = 2.5;
nuA=0.3;          %Choice informed by Gouel and Jean (2023EER): sensible range between 0.2 and 0.4. Standard CES at 0.2. 
nuM=0.3;
PcS=10;             %Normalization

%Parameters from data

ncA_values = readtable('C:\Users\gourens\Dropbox\Research\4_Div&Div\databases\ncA.xlsx', 'Range', 'A1:D100', 'ReadRowNames', false);
ncM_values = readtable('C:\Users\gourens\Dropbox\Research\4_Div&Div\databases\ncM.xlsx', 'Range', 'A1:D100', 'ReadRowNames', false);
nfcA_values = readtable('C:\Users\gourens\Dropbox\Research\4_Div&Div\databases\nfcA.xlsx', 'Range', 'A1:D100', 'ReadRowNames', false);
nfcM_values = readtable('C:\Users\gourens\Dropbox\Research\4_Div&Div\databases\nfcM.xlsx', 'Range', 'A1:D100', 'ReadRowNames', false);
Ec_values = readtable('C:\Users\gourens\Dropbox\Research\4_Div&Div\databases\Ec.xlsx', 'Range', 'A1:D100', 'ReadRowNames', false);
shYcA_values = readtable('C:\Users\gourens\Dropbox\Research\4_Div&Div\databases\shYcA.xlsx', 'Range', 'A1:D100', 'ReadRowNames', false);
shYcM_values = readtable('C:\Users\gourens\Dropbox\Research\4_Div&Div\databases\shYcM.xlsx', 'Range', 'A1:D100', 'ReadRowNames', false);
shLcA_values = readtable('C:\Users\gourens\Dropbox\Research\4_Div&Div\databases\shLcA.xlsx', 'Range', 'A1:D100', 'ReadRowNames', false);
shLcM_values = readtable('C:\Users\gourens\Dropbox\Research\4_Div&Div\databases\shLcM.xlsx', 'Range', 'A1:D100', 'ReadRowNames', false);
yc_values = readtable('C:\Users\gourens\Dropbox\Research\4_Div&Div\databases\yc.xlsx', 'Range', 'A1:D100', 'ReadRowNames', false);
Lc_values = readtable('C:\Users\gourens\Dropbox\Research\4_Div&Div\databases\Lc.xlsx', 'Range', 'A1:D100', 'ReadRowNames', false);
shYfA_values = readtable('C:\Users\gourens\Dropbox\Research\4_Div&Div\databases\shYfA.xlsx', 'Range', 'A1:D100', 'ReadRowNames', false);
shYfM_values = readtable('C:\Users\gourens\Dropbox\Research\4_Div&Div\databases\shYfM.xlsx', 'Range', 'A1:D100', 'ReadRowNames', false);
shLfA_values = readtable('C:\Users\gourens\Dropbox\Research\4_Div&Div\databases\shLfA.xlsx', 'Range', 'A1:D100', 'ReadRowNames', false);
shLfM_values = readtable('C:\Users\gourens\Dropbox\Research\4_Div&Div\databases\shLfM.xlsx', 'Range', 'A1:D100', 'ReadRowNames', false);
yf_values = readtable('C:\Users\gourens\Dropbox\Research\4_Div&Div\databases\yf.xlsx', 'Range', 'A1:D100', 'ReadRowNames', false);
Lf_values = readtable('C:\Users\gourens\Dropbox\Research\4_Div&Div\databases\Lf.xlsx', 'Range', 'A1:D100', 'ReadRowNames', false);
wf_values = readtable('C:\Users\gourens\Dropbox\Research\4_Div&Div\databases\wf.xlsx', 'Range', 'A1:D100', 'ReadRowNames', false);
tauA_values = readtable('C:\Users\gourens\Dropbox\Research\4_Div&Div\databases\tauA.xlsx', 'Range', 'A1:D100', 'ReadRowNames', false);
tauM_values = readtable('C:\Users\gourens\Dropbox\Research\4_Div&Div\databases\tauM.xlsx', 'Range', 'A1:D100', 'ReadRowNames', false);

for i = 1:91 %Loop for countries
for j = 1:2  %Loop for years
disp(['Row ', num2str(i), ' and Column ', num2str(j)]);

ncA=ncA_values{i, j};        %# of goods produced on c in industry A (4-digits, SITCRev2). 
ncM=ncM_values{i, j};
nfcA=nfcA_values{i, j};      %# of goods from f that reach c in industry A.
nfcM=nfcM_values{i, j};      %# of goods from f that reach c in industry M.
Ec=Ec_values{i, j};          %Absortion value from PWT
shYcA=shYcA_values{i, j};
shYcM=shYcM_values{i, j};
shLcA=shLcA_values{i, j};
shLcM=shLcM_values{i, j};
yc=yc_values{i, j};
Lc=Lc_values{i, j};
shYfA=shYfA_values{i, j};
shYfM=shYfM_values{i, j};
shLfA=shLfA_values{i, j};
shLfM=shLfM_values{i, j};
yf=yf_values{i, j};
Lf=Lf_values{i, j};
wf=wf_values{i, j};          %Per capita GDP of trading partners weigthed by importance in trade.
NcA=ncA+nfcA;         %total # of goods available in c in industry A.
NcM=ncM+nfcM;         %total # of goods available in c in industry M.

Yc=yc*Lc;
YcA=Yc*shYcA;
phicA=YcA/(Lc*shLcA);
YcM=Yc*shYcM;
phicM=YcM/(Lc*shLcM);
Yf=yf*Lf;
YfA=Yf*shYfA;
phifA=YfA/(Lf*shLfA);
YfM=YfA*shYfM;
phifM=YfM/(Lf*shLfM);

%Parameters from estimations
taufcA = tauA_values{i, j};  %country in row, year in column
taufcM = tauM_values{i, j};
barQA = (-1.13688-1.35826)/2;   %From own estimations
barQS = (8.72538+1.24607)/2;
omegaA = (0.12+0.228)/2;        %From own estimations
omegaM = (0.88+0.772)/2;
omegaS = (0.817+0.719)/2;
omegaG = (0.183+0.281)/2;
beta = (1.621+1.192)/2;         %From own estimations
epsilon=(0.768+0.447)/2;

%Equations for Foreign (Rest of World)
pfA=(wf/phifA)*sigmaA/(sigmaA-1);
pfM=(wf/phifM)*sigmaM/(sigmaM-1);

%Equations for country c
syms pcA shccA shfcA PcA alphaA wc pcM shccM shfcM PcM alphaM PcG Pc;

eq1= pcA==(wc/phicA)*sigmaA/(sigmaA-1);
eq2= shccA==NcA^(nuA*(sigmaA-1)-1)*(PcA/pcA)^(sigmaA-1);
eq3= shfcA==(1-shccA*ncA)/nfcA;
eq4= PcA==ncA*shccA*pcA+nfcA*shfcA*pfA*taufcA;
eq5= alphaA==(PcA^(1-beta))*omegaA*omegaG*(PcG^(beta-epsilon))*(Pc^(epsilon-1))*(1+(PcS*barQS+PcA*barQA)/Ec)-barQA*PcA/Ec;

eq6= pcM==(wc/phicM)*sigmaM/(sigmaM-1);
eq7= shccM==NcM^(nuM*(sigmaM-1)-1)*(PcM/pcM)^(sigmaM-1);
eq8= shfcM==(1-shccM*ncM)/nfcM;
eq9= PcM==ncM*shccM*pcM+nfcM*shfcM*pfM*taufcM;
eq10=alphaM==(PcM^(1-beta))*omegaM*omegaG*(PcG^(beta-epsilon))*(Pc^(epsilon-1))*(1+(PcS*barQS+PcA*barQA)/Ec);

eq11= (alphaA+alphaM)*Ec==YcA*pcA+YcM*pcM;  %TBC
eq12= PcG==(omegaA*PcA^(1-beta)+omegaM*PcM^(1-beta))^(1/(1-beta));
eq13= Pc==(omegaG*PcG^(1-epsilon)+omegaS*PcS^(1-epsilon))^(1/(1-epsilon));

%Solve
sols = vpasolve([eq1, eq2, eq3, eq4, eq5, eq6, eq7, eq8, eq9, eq10, eq11, eq12, eq13], [pcA, shccA, shfcA, PcA, alphaA, wc, pcM, shccM, shfcM, PcM, alphaM, PcG, Pc]);
disp(sols);
alpha_results(i, j)=sols.alphaA;

%Terms of trade and exports
McA=sols.shfcA*nfcA*sols.alphaA*Ec;
McM=sols.shfcM*nfcM*sols.alphaA*Ec;
MshA=McA/(McA+McM);
XcA=YcA*sols.pcA-Ec*sols.alphaA*sols.shccA*ncA;
XcM=YcM*sols.pcM-Ec*sols.alphaM*sols.shccM*ncM;
XshA=XcA/(XcA+XcM);
TTc=(sols.pcA*XshA+sols.pcM*(1-XshA))/(pfA*MshA+pfM*(1-MshA));
TTresults(i, j)=TTc;
disp(TTc);

export_results(i, j)=XcA;
disp(XcA);
export_results(i, j+2)=XcM;
disp(XcM);

%Welfare: Value/Price
Wel_c=Ec/(sols.Pc*Lc);
Wel_results(i, j)=Wel_c;
disp(Wel_c);

end
end
output_file1 = 'C:\Users\gourens\Dropbox\Research\4_Div&Div\databases\TTresults.xlsx';
writematrix(TTresults, output_file1, 'Range', 'A1');
output_file2 = 'C:\Users\gourens\Dropbox\Research\4_Div&Div\databases\alpha_results.xlsx';
writematrix(alpha_results, output_file2, 'Range', 'A1');
output_file3 = 'C:\Users\gourens\Dropbox\Research\4_Div&Div\databases\Wel_results.xlsx';
writematrix(Wel_results, output_file3, 'Range', 'A1');
output_file4 = 'C:\Users\gourens\Dropbox\Research\4_Div&Div\databases\export_results.xlsx';
writematrix(export_results, output_file4, 'Range', 'A1');

